-- phpMyAdmin SQL Dump
-- version 5.1.3-3.red80
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 08 2026 г., 03:22
-- Версия сервера: 10.11.11-MariaDB
-- Версия PHP: 8.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Project_Yfkin`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`admin`@`localhost` PROCEDURE `ChangeUserPassword` (IN `p_UserID` INT, IN `p_NewPassword` VARCHAR(255), IN `p_Unban` TINYINT(1))   BEGIN
    DECLARE v_Exists INT;

    -- Проверяем, существует ли такой пользователь
    SELECT COUNT(*) INTO v_Exists FROM users WHERE ID_U = p_UserID;

    IF v_Exists = 0 THEN
        SELECT 'Ошибка: Пользователь с таким ID не найден' AS Result;
    ELSE
        -- Обновляем пароль, дату смены, сбрасываем счетчик ошибок и, если нужно, снимаем бан
        UPDATE users 
        SET Password = p_NewPassword,
            Last_Password_Change = NOW(),
            Failed_Attempts = 0,
            Ban = IF(p_Unban = 1, '0', Ban)
        WHERE ID_U = p_UserID;
        
        SELECT 'Успех: Пароль изменен, таймер сброшен' AS Result;
    END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `CheckUserLogin` (IN `p_Login` VARCHAR(50), IN `p_Password` VARCHAR(255))   BEGIN
    DECLARE v_UserID INT;
    DECLARE v_Ban ENUM('0', '1');
    DECLARE v_Failed INT;
    DECLARE v_DbPassword VARCHAR(255);

    SELECT ID_U, Ban, Failed_Attempts, Password INTO v_UserID, v_Ban, v_Failed, v_DbPassword
    FROM users WHERE Login = p_Login;

    IF v_UserID IS NULL THEN
        SELECT 'Пользователь не найден' AS Result;
    ELSEIF v_Ban = '1' THEN
        SELECT 'Аккаунт заблокирован. Обратитесь к администратору.' AS Result;
    ELSE
        IF v_DbPassword = p_Password THEN
            UPDATE users SET Failed_Attempts = 0 WHERE ID_U = v_UserID;
            SELECT 'Успешный вход' AS Result;
        ELSE
            -- ИСПРАВЛЕНИЕ: Используем IFNULL, чтобы избежать ошибки с NULL
            SET v_Failed = IFNULL(v_Failed, 0) + 1;
            IF v_Failed >= 3 THEN
                UPDATE users SET Failed_Attempts = v_Failed, Ban = '1' WHERE ID_U = v_UserID;
                SELECT 'Неверный пароль! Аккаунт заблокирован после 3 попыток.' AS Result;
            ELSE
                UPDATE users SET Failed_Attempts = v_Failed WHERE ID_U = v_UserID;
                SELECT CONCAT('Неверный пароль. Осталось попыток: ', 3 - v_Failed) AS Result;
            END IF;
        END IF;
    END IF;
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `LockOldPasswords` ()   BEGIN
    UPDATE users
    SET Ban = '1'
    WHERE Last_Password_Change < DATE_SUB(NOW(), INTERVAL 6 MONTH)
    AND Ban = '0';
END$$

CREATE DEFINER=`admin`@`localhost` PROCEDURE `RegisterUser` (IN `p_Login` VARCHAR(50), IN `p_Password` VARCHAR(255), IN `p_Phone` VARCHAR(20), IN `p_Role` ENUM('Sys_Admin','Admin','User'))   BEGIN
    DECLARE v_LoginExists INT;
    DECLARE v_PhoneExists INT;

    -- Проверяем, существует ли уже такой логин
    SELECT COUNT(*) INTO v_LoginExists FROM users WHERE Login = p_Login;
    
    -- Проверяем, существует ли уже такой номер телефона
    SELECT COUNT(*) INTO v_PhoneExists FROM users WHERE Phone_Number = p_Phone;

    IF v_LoginExists > 0 THEN
        SELECT 'Ошибка: Пользователь с таким логином уже существует' AS Result;
    ELSEIF v_PhoneExists > 0 THEN
        SELECT 'Ошибка: Пользователь с таким номером телефона уже существует' AS Result;
    ELSE
        -- Если всё чисто, добавляем пользователя
        INSERT INTO users (Login, Password, Phone_Number, Role)
        VALUES (p_Login, p_Password, p_Phone, p_Role);
        
        SELECT 'Успех: Пользователь успешно зарегистрирован' AS Result;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `audit_logs`
--

CREATE TABLE `audit_logs` (
  `Log_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Old_Role` varchar(50) NOT NULL,
  `New_Role` varchar(50) NOT NULL,
  `Changed_At` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `ban_logs`
--

CREATE TABLE `ban_logs` (
  `Log_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Old_Ban` varchar(1) NOT NULL,
  `New_Ban` varchar(1) NOT NULL,
  `Changed_At` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `ban_logs`
--

INSERT INTO `ban_logs` (`Log_ID`, `User_ID`, `Old_Ban`, `New_Ban`, `Changed_At`) VALUES
(1, 8, '0', '1', '2026-10-08 10:16:24');

-- --------------------------------------------------------

--
-- Структура таблицы `notifications`
--

CREATE TABLE `notifications` (
  `Notification_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Message` text NOT NULL,
  `Is_Read` tinyint(1) NOT NULL DEFAULT 0,
  `Created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `notifications`
--

INSERT INTO `notifications` (`Notification_ID`, `User_ID`, `Message`, `Is_Read`, `Created_at`) VALUES
(1, 8, 'Добро пожаловать в систему! Пожалуйста, не забудьте сменить пароль, если он был выдан администратором.', 0, '2026-10-08 10:12:31'),
(2, 8, 'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.', 0, '2026-10-08 10:16:24'),
(3, 9, 'Добро пожаловать в систему! Пожалуйста, не забудьте сменить пароль, если он был выдан администратором.', 0, '2026-10-08 10:22:07');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `Role_ID` int(11) NOT NULL,
  `Role_Name` varchar(50) NOT NULL COMMENT 'Название роли'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `ID_U` int(11) NOT NULL COMMENT 'Нужно для создания',
  `Login` varchar(50) NOT NULL COMMENT 'Для авторизации',
  `Password` varchar(255) NOT NULL COMMENT 'Необходим для авторизации (хранит хэш)',
  `Phone_Number` varchar(20) NOT NULL COMMENT 'Хранит номер',
  `Created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Когда был создан',
  `Ban` enum('0','1') NOT NULL DEFAULT '0' COMMENT 'Заблокирован (0 - нет, 1 - да)',
  `Role` enum('System_Admin','Admin','User') NOT NULL DEFAULT 'User' COMMENT 'Роль пользователя',
  `Failed_Attempts` int(11) NOT NULL DEFAULT 0 COMMENT 'Количество неудачных попыток входа',
  `Last_Password_Change` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Дата последней смены пароля'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`ID_U`, `Login`, `Password`, `Phone_Number`, `Created_at`, `Ban`, `Role`, `Failed_Attempts`, `Last_Password_Change`) VALUES
(1, 'sys_admin_1', 'hash_password_1', '79000000001', '2026-10-05 10:54:58', '0', 'System_Admin', 1, '2026-10-07 09:13:55'),
(2, 'sys_admin_2', 'hash_password_2', '79000000002', '2026-10-05 10:54:58', '0', 'System_Admin', 0, '2026-10-07 09:13:55'),
(3, 'admin_1', 'hash_password_3', '79000000003', '2026-10-05 10:54:58', '0', 'Admin', 0, '2026-10-07 09:13:55'),
(4, 'admin_2', 'hash_password_4', '79000000004', '2026-10-05 10:54:58', '0', 'Admin', 0, '2026-10-07 09:13:55'),
(5, 'user_1', 'hash_password_5', '79000000005', '2026-10-05 10:54:58', '0', 'User', 0, '2026-10-07 09:13:55'),
(6, 'user_2', 'hash_password_6', '79000000006', '2026-10-05 10:54:58', '0', 'User', 0, '2026-10-07 09:13:55'),
(7, 'test_user', 'my_secure_hash_123', '79991234567', '2026-10-05 11:14:28', '0', 'User', 0, '2026-10-07 09:13:55'),
(8, 'sosovod', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '79000000099', '2026-10-08 10:12:31', '1', 'User', 3, '2026-10-08 10:12:31'),
(9, 'sosovot', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '79000593567', '2026-10-08 10:22:07', '0', 'User', 0, '2026-10-08 10:22:07');

--
-- Триггеры `users`
--
DELIMITER $$
CREATE TRIGGER `After_User_Ban_Change` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    -- Проверяем, изменилось ли поле Ban
    IF OLD.Ban != NEW.Ban THEN
        -- 1. Записываем в лог аудита
        INSERT INTO ban_logs (User_ID, Old_Ban, New_Ban)
        VALUES (NEW.ID_U, OLD.Ban, NEW.Ban);
        
        -- 2. Если пользователя забанили (Ban стал '1'), отправляем уведомление
        IF NEW.Ban = '1' THEN
            INSERT INTO notifications (User_ID, Message)
            VALUES (NEW.ID_U, 'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.');
        END IF;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After_User_Registration` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    INSERT INTO notifications (User_ID, Message)
    VALUES (NEW.ID_U, 'Добро пожаловать в систему! Пожалуйста, не забудьте сменить пароль, если он был выдан администратором.');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After_User_Role_Change` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    -- Если старая роль не равна новой роли
    IF OLD.Role != NEW.Role THEN
        INSERT INTO audit_logs (User_ID, Old_Role, New_Role)
        VALUES (OLD.ID_U, OLD.Role, NEW.Role);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_profiles`
--

CREATE TABLE `user_profiles` (
  `User_ID` int(11) NOT NULL COMMENT 'Ссылка на таблицу users',
  `Last_Name` varchar(50) NOT NULL COMMENT 'Фамилия',
  `First_Name` varchar(50) NOT NULL COMMENT 'Имя',
  `Middle_Name` varchar(50) DEFAULT NULL COMMENT 'Отчество (может отсутствовать)',
  `Email` varchar(100) DEFAULT NULL COMMENT 'Электронная почта (доп. поле)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_profiles`
--

INSERT INTO `user_profiles` (`User_ID`, `Last_Name`, `First_Name`, `Middle_Name`, `Email`) VALUES
(1, 'Иванов', 'Иван', 'Иванович', 'ivanov@example.com'),
(2, 'Петров', 'Петр', 'Петрович', 'petrov@example.com'),
(3, 'Сидоров', 'Сидор', 'Сидорович', 'sidorov@example.com'),
(4, 'Смирнов', 'Алексей', 'Викторович', 'smirnov@example.com'),
(5, 'Кузнецов', 'Дмитрий', 'Анатольевич', 'kuznetsov@example.com'),
(6, 'Попова', 'Анна', 'Сергеевна', 'popova@example.com'),
(7, 'Тестов', 'Тест', 'Тестович', 'test@example.com');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`Log_ID`);

--
-- Индексы таблицы `ban_logs`
--
ALTER TABLE `ban_logs`
  ADD PRIMARY KEY (`Log_ID`);

--
-- Индексы таблицы `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`Notification_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`Role_ID`),
  ADD UNIQUE KEY `Role_Name_UNIQUE` (`Role_Name`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID_U`),
  ADD UNIQUE KEY `Login_UNIQUE` (`Login`),
  ADD UNIQUE KEY `Phone_Number_UNIQUE` (`Phone_Number`);

--
-- Индексы таблицы `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `Log_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `ban_logs`
--
ALTER TABLE `ban_logs`
  MODIFY `Log_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `notifications`
--
ALTER TABLE `notifications`
  MODIFY `Notification_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `Role_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `ID_U` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Нужно для создания', AUTO_INCREMENT=10;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `fk_user_profile` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE;

DELIMITER $$
--
-- События
--
CREATE DEFINER=`admin`@`localhost` EVENT `Event_PasswordExpiryWarning` ON SCHEDULE EVERY 1 DAY STARTS '2026-10-07 09:14:36' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    INSERT INTO notifications (User_ID, Message)
    SELECT ID_U, 'Внимание! Срок действия вашего пароля истекает через 2 дня. Пожалуйста, смените пароль.'
    FROM users
    WHERE DATE(DATE_ADD(Last_Password_Change, INTERVAL 6 MONTH)) = DATE(DATE_ADD(NOW(), INTERVAL 2 DAY))
    AND Ban = '0';
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
