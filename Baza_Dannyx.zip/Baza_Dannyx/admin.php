<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    header('Location: dashboard.php');
    exit;
}

$sql = "SELECT 
            u.ID_U, u.Login, u.Phone_Number, u.Ban, u.Role, 
            u.Failed_Attempts, u.Last_Password_Change, u.Last_Activity,
            p.Last_Name, p.First_Name, p.Middle_Name
        FROM users u
        LEFT JOIN user_profiles p ON u.ID_U = p.User_ID
        ORDER BY u.ID_U";
$stmt = $pdo->query($sql);
$users = $stmt->fetchAll();

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1400px; margin: 0 auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px; }
        .header h1 { margin: 0; }
        .role-badge { padding: 5px 15px; border-radius: 20px; color: white; font-weight: bold; }
        .role-System_Admin { background: #dc3545; }
        .role-Admin { background: #fd7e14; }
        
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        
        .top-buttons { margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 8px; }
        .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; color: white; text-decoration: none; font-size: 13px; display: inline-block; font-weight: bold; }
        .btn-tools { background: #6f42c1; }
        .btn-msg { background: #007bff; }
        .btn-backup { background: #17a2b8; }
        .btn-ban { background: #dc3545; }
        .btn-unban { background: #28a745; }
        .btn-edit { background: #007bff; }
        .btn-back { background: #343a40; }
        .btn-testing { background: #e83e8c; }
        .btn:hover { opacity: 0.88; }
        
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px; }
        th { background: #343a40; color: white; font-weight: normal; }
        tr:hover { background: #f8f9fa; }
        tr.selected { background: #fff8e1 !important; }
        
        .role-select { padding: 5px; border-radius: 4px; border: 1px solid #ccc; }
        .status-active { color: green; font-weight: bold; }
        .status-banned { color: red; font-weight: bold; }
        .status-online { color: #17a2b8; font-weight: bold; }
        
        .mass-panel { background: #fff3cd; padding: 15px 20px; border-radius: 8px; margin-bottom: 15px; border-left: 5px solid #ffc107; display: none; flex-wrap: wrap; gap: 10px; align-items: center; }
        .mass-panel.active { display: flex; }
        .mass-panel b { margin-right: 10px; }
        
        .checkbox-cell { width: 40px; text-align: center; }
        input[type="checkbox"] { transform: scale(1.3); cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚙️ Панель администратора</h1>
            <div>
                <span class="role-badge role-<?= htmlspecialchars($_SESSION['user_role'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($_SESSION['user_role'], ENT_QUOTES, 'UTF-8') ?></span>
                <a href="dashboard.php" class="btn btn-back" style="margin-left:10px;">← В личный кабинет</a>
                <a href="logout.php" class="btn btn-ban">Выйти</a>
            </div>
        </div>

        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <div class="top-buttons">
            <a href="admin_action_logs.php" class="btn btn-tools">📜 Логи действий</a>
            <a href="admin_messages.php" class="btn btn-msg">✉️ Отправить сообщение</a>
            <a href="admin_backup.php" class="btn btn-backup">💾 Резервные копии БД</a>
            <?php if ($isSystemAdmin): ?>
                <a href="admin_stats.php" class="btn btn-msg" style="background:#17a2b8;">📡 Мониторинг</a>
                <a href="db_tools.php" class="btn btn-tools">🛠️ Управление таблицами</a>
                <a href="admin_testing.php" class="btn btn-testing">🧪 Тестирование</a>
            <?php endif; ?>
        </div>

        <form method="POST" action="admin_mass_actions.php" id="massForm">
            <div class="mass-panel" id="massPanel">
                <b>Выбрано: <span id="selectedCount">0</span></b>
                
                <select name="mass_action" required style="padding:8px; border-radius:4px; border:1px solid #ccc;">
                    <option value="">— выберите действие —</option>
                    <option value="ban">🚫 Забанить выбранных</option>
                    <option value="unban">✅ Разбанить выбранных</option>
                    <option value="change_role_user">🔵 Сменить роль на User</option>
                    <option value="change_role_admin">🟠 Сменить роль на Admin</option>
                    <?php if ($isSystemAdmin): ?>
                        <option value="change_role_sysadmin">🔴 Сменить роль на System_Admin</option>
                        <option value="delete">🗑 Удалить выбранных</option>
                    <?php endif; ?>
                    <option value="send_message">✉️ Отправить сообщение</option>
                </select>
                
                <button type="submit" class="btn btn-ban" onclick="return confirmMassAction()">Применить</button>
                <button type="button" class="btn btn-tools" onclick="clearSelection()">Снять выделение</button>
            </div>

            <table>
                <thead>
                    <tr>
                        <th class="checkbox-cell"><input type="checkbox" id="selectAll" onchange="toggleAll(this)"></th>
                        <th>ID</th>
                        <th>Логин</th>
                        <th>ФИО</th>
                        <th>Телефон</th>
                        <th>Роль</th>
                        <th>Статус</th>
                        <th>Ошибки</th>
                        <th>Смена пароля</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): 
                        // Безопасная проверка времени активности
                        $isOnline = false;
                        if (!empty($u['Last_Activity'])) {
                            $isOnline = (time() - strtotime($u['Last_Activity'])) < 300;
                        }
                    ?>
                    <tr id="row_<?= $u['ID_U'] ?>">
                        <td class="checkbox-cell">
                            <input type="checkbox" name="user_ids[]" value="<?= $u['ID_U'] ?>" 
                                   class="user-checkbox" onchange="updateSelection()"
                                   <?= $u['ID_U'] == $_SESSION['user_id'] ? 'data-self="1"' : '' ?>>
                        </td>
                        <td><?= $u['ID_U'] ?></td>
                        <td><b><?= htmlspecialchars($u['Login'], ENT_QUOTES, 'UTF-8') ?></b></td>
                        <td>
                            <?php 
                                $fio = trim(($u['Last_Name'] ?? '') . ' ' . ($u['First_Name'] ?? '') . ' ' . ($u['Middle_Name'] ?? ''));
                                echo $fio ? htmlspecialchars($fio, ENT_QUOTES, 'UTF-8') : '<i style="color:#aaa;">не заполнено</i>';
                            ?>
                        </td>
                        <td><?= htmlspecialchars($u['Phone_Number'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <form method="POST" action="admin_actions.php" style="display:inline;">
                                <input type="hidden" name="action" value="change_role">
                                <input type="hidden" name="user_id" value="<?= $u['ID_U'] ?>">
                                <select name="role" class="role-select" onchange="this.form.submit()">
                                    <option value="User" <?= $u['Role'] === 'User' ? 'selected' : '' ?>>User</option>
                                    <option value="Admin" <?= $u['Role'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
                                    <?php if ($isSystemAdmin): ?>
                                        <option value="System_Admin" <?= $u['Role'] === 'System_Admin' ? 'selected' : '' ?>>System_Admin</option>
                                    <?php endif; ?>
                                </select>
                            </form>
                        </td>
                        <td>
                            <?php if ($u['Ban'] === '1'): ?>
                                <span class="status-banned">🚫 Забанен</span>
                            <?php elseif ($isOnline): ?>
                                <span class="status-online">🟢 Онлайн</span>
                            <?php else: ?>
                                <span class="status-active">✅ Активен</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $u['Failed_Attempts'] ?></td>
                        <td><?= htmlspecialchars($u['Last_Password_Change'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <a href="admin_messages.php?to=<?= $u['ID_U'] ?>" class="btn btn-msg" style="padding:5px 10px; font-size:12px;">✉️</a>
                            <?php if ($u['Ban'] === '0'): ?>
                                <a href="admin_actions.php?action=ban&user_id=<?= $u['ID_U'] ?>" class="btn btn-ban" style="padding:5px 10px; font-size:12px;" onclick="return confirm('Забанить?')">🚫</a>
                            <?php else: ?>
                                <a href="admin_actions.php?action=unban&user_id=<?= $u['ID_U'] ?>" class="btn btn-unban" style="padding:5px 10px; font-size:12px;">✅</a>
                            <?php endif; ?>
                            <?php if ($isSystemAdmin && $u['ID_U'] != $_SESSION['user_id']): ?>
                                <a href="admin_actions.php?action=delete&user_id=<?= $u['ID_U'] ?>" class="btn btn-ban" style="padding:5px 10px; font-size:12px;" onclick="return confirm('Удалить?')">🗑</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </form>
    </div>

    <script>
        function toggleAll(cb) {
            document.querySelectorAll('.user-checkbox').forEach(c => { c.checked = cb.checked; });
            updateSelection();
        }

        function updateSelection() {
            const checked = document.querySelectorAll('.user-checkbox:checked');
            const count = checked.length;
            document.getElementById('selectedCount').textContent = count;
            
            const panel = document.getElementById('massPanel');
            if (count > 0) panel.classList.add('active');
            else panel.classList.remove('active');
            
            document.querySelectorAll('.user-checkbox').forEach(c => {
                const row = c.closest('tr');
                if (c.checked) row.classList.add('selected');
                else row.classList.remove('selected');
            });
        }

        function clearSelection() {
            document.querySelectorAll('.user-checkbox').forEach(c => c.checked = false);
            document.getElementById('selectAll').checked = false;
            updateSelection();
        }

        function confirmMassAction() {
            const action = document.querySelector('select[name="mass_action"]').value;
            const count = document.querySelectorAll('.user-checkbox:checked').length;
            
            if (!action) { alert('Выберите действие'); return false; }
            if (count === 0) { alert('Выберите хотя бы одного пользователя'); return false; }
            
            const selfSelected = document.querySelector('.user-checkbox[data-self="1"]:checked');
            if (selfSelected && ['ban', 'delete'].includes(action)) {
                return confirm('⚠️ Вы выбрали СЕБЯ! Вы точно хотите это сделать?');
            }
            
            const messages = {
                'ban': 'Забанить',
                'unban': 'Разбанить',
                'delete': 'УДАЛИТЬ',
                'change_role_user': 'Сменить роль на User для',
                'change_role_admin': 'Сменить роль на Admin для',
                'change_role_sysadmin': 'Сменить роль на System_Admin для',
                'send_message': 'Отправить сообщение'
            };
            
            return confirm(messages[action] + ' ' + count + ' пользователей?');
        }
    </script>
</body>
</html>