<?php declare(strict_types=1);

// Включаем ошибки для отладки
ini_set('display_errors', '1');
error_reporting(E_ALL);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

try {
    $total = (int) $pdo->query("SELECT COUNT(*) FROM admin_action_logs")->fetchColumn();
    $pages = ceil($total / $perPage);

    $logs = $pdo->query("
        SELECT l.*, u.Login AS Admin_Login
        FROM admin_action_logs l
        LEFT JOIN users u ON u.ID_U = l.Admin_ID
        ORDER BY l.Created_at DESC
        LIMIT $perPage OFFSET $offset
    ")->fetchAll();
} catch (\PDOException $e) {
    die("Ошибка базы данных: " . $e->getMessage() . ". Убедитесь, что таблица admin_action_logs создана.");
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Логи действий администраторов</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1300px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .top-nav { display: flex; gap: 15px; margin-bottom: 20px; }
        .btn-back { display: inline-block; color: #007bff; text-decoration: none; font-weight: bold; padding: 8px 15px; border: 1px solid #007bff; border-radius: 5px; }
        .btn-back:hover { background: #007bff; color: white; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #eee; }
        table.data th { background: #343a40; color: white; font-weight: normal; }
        table.data tr:hover { background: #f8f9fa; }
        .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-ban { background: #dc3545; color: white; }
        .badge-unban { background: #28a745; color: white; }
        .badge-delete { background: #721c24; color: white; }
        .badge-role { background: #007bff; color: white; }
        .badge-backup { background: #17a2b8; color: white; }
        .badge-msg { background: #6f42c1; color: white; }
        .pagination { text-align: center; margin-top: 20px; }
        .pagination a, .pagination span { display: inline-block; padding: 6px 12px; margin: 2px; background: white; border-radius: 4px; text-decoration: none; color: #007bff; border: 1px solid #ddd; font-size: 13px; }
        .pagination span.active { background: #007bff; color: white; border-color: #007bff; }
    </style>
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        <h1>📜 Логи действий администраторов</h1>
        
        <div class="card">
            <p style="color:#666;">Всего записей: <b><?= $total ?></b>. Страница <?= $page ?> из <?= max(1, (int)$pages) ?>.</p>
            
            <?php if (empty($logs)): ?>
                <p style="text-align:center; color:#999;">Логи пусты.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr><th>Дата</th><th>Администратор</th><th>Действие</th><th>Объект</th><th>Детали</th><th>IP</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $l): 
                            $badge = 'badge-role';
                            if (str_contains($l['Action'], 'ban') && !str_contains($l['Action'], 'unban')) $badge = 'badge-ban';
                            if (str_contains($l['Action'], 'unban')) $badge = 'badge-unban';
                            if (str_contains($l['Action'], 'delete')) $badge = 'badge-delete';
                            if (str_contains($l['Action'], 'backup')) $badge = 'badge-backup';
                            if (str_contains($l['Action'], 'message')) $badge = 'badge-msg';
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($l['Created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><b><?= htmlspecialchars($l['Admin_Login'] ?? '—', ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><span class="badge <?= $badge ?>"><?= htmlspecialchars($l['Action'], ENT_QUOTES, 'UTF-8') ?></span></td>
                            <td><?= htmlspecialchars($l['Target_Type'] ?? '—', ENT_QUOTES, 'UTF-8') ?> <?= htmlspecialchars($l['Target_ID'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($l['Details'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($l['IP_Address'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($pages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>