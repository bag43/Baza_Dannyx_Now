<?php declare(strict_types=1);

// Включаем отображение ошибок для отладки
ini_set('display_errors', '1');
error_reporting(E_ALL);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    header('Location: dashboard.php');
    exit;
}

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$userId = (int) ($_POST['user_id'] ?? $_GET['user_id'] ?? 0);

try {
    switch ($action) {
        case 'change_role':
            $newRole = $_POST['role'] ?? 'User';
            if (!$isSystemAdmin && $newRole === 'System_Admin') {
                die('Недостаточно прав для назначения роли System_Admin');
            }
            
            $stmt = $pdo->prepare("UPDATE users SET Role = ? WHERE ID_U = ?");
            $stmt->execute([$newRole, $userId]);
            
            // Обновляем роль в профиле (если таблица user_profiles имеет колонку Role_ID)
            try {
                $roleStmt = $pdo->prepare("SELECT Role_ID FROM roles WHERE Role_Name = ?");
                $roleStmt->execute([$newRole]);
                $roleData = $roleStmt->fetch();
                if ($roleData) {
                    $updateProfile = $pdo->prepare("UPDATE user_profiles SET Role_ID = ? WHERE User_ID = ?");
                    $updateProfile->execute([$roleData['Role_ID'], $userId]);
                }
            } catch (\PDOException $e) {
                // Игнорируем ошибку, если в user_profiles нет колонки Role_ID
            }
            break;

        case 'ban':
            $stmt = $pdo->prepare("UPDATE users SET Ban = '1' WHERE ID_U = ?");
            $stmt->execute([$userId]);
            break;

        case 'unban':
            // Сбрасываем бан, счетчик ошибок и флаг принудительного выхода
            $stmt = $pdo->prepare("UPDATE users SET Ban = '0', Failed_Attempts = 0, Kick_Flag = 0 WHERE ID_U = ?");
            $stmt->execute([$userId]);
            break;

        case 'delete':
            if (!$isSystemAdmin) {
                die('Недостаточно прав');
            }
            $stmt = $pdo->prepare("DELETE FROM users WHERE ID_U = ?");
            $stmt->execute([$userId]);
            break;
    }
} catch (\Throwable $e) {
    // Ловим ВООБЩЕ ВСЕ ошибки, чтобы не было пустого экрана 500
    die("Ошибка базы данных при выполнении действия: " . $e->getMessage());
}

header('Location: admin.php');
exit;