<?php declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$backupDir = __DIR__ . '/backups';
if (!is_dir($backupDir)) {
    @mkdir($backupDir, 0755, true);
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Получаем список файлов
$backups = [];
$files = glob($backupDir . '/*.sql');
if ($files) {
    foreach ($files as $file) {
        $backups[] = [
            'name' => basename($file),
            'size' => filesize($file),
            'date' => filemtime($file),
        ];
    }
    usort($backups, fn(array $a, array $b): int => $b['date'] <=> $a['date']);
}

// Получаем логи
try {
    $logs = $pdo->query("
        SELECT b.*, u.Login AS Admin_Login
        FROM backup_logs b
        LEFT JOIN users u ON u.ID_U = b.Created_By
        ORDER BY b.Created_at DESC
        LIMIT 20
    ")->fetchAll();
} catch (\PDOException $e) {
    $logs = [];
}

function formatBytes(int $bytes): string {
    $units = ['Б', 'КБ', 'МБ', 'ГБ'];
    $pow = $bytes > 0 ? floor(log($bytes) / log(1024)) : 0;
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, 2) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Резервные копии БД</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .top-nav { display: flex; gap: 15px; margin-bottom: 20px; }
        .btn-back { display: inline-block; color: #007bff; text-decoration: none; font-weight: bold; padding: 8px 15px; border: 1px solid #007bff; border-radius: 5px; }
        .btn-back:hover { background: #007bff; color: white; }
        .card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card h2 { margin-top: 0; font-size: 18px; }
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        .btn-create { background: #28a745; color: white; border: none; padding: 14px 30px; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: bold; display: inline-flex; align-items: center; gap: 10px; transition: 0.3s; }
        .btn-create:hover { background: #218838; }
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        table.data th { background: #343a40; color: white; font-weight: normal; }
        table.data tr:hover { background: #f8f9fa; }
        .btn { padding: 6px 14px; border-radius: 4px; text-decoration: none; font-size: 12px; color: white; display: inline-block; margin: 2px; border: none; cursor: pointer; font-weight: bold; }
        .btn-download { background: #007bff; }
        .btn-restore { background: #fd7e14; }
        .btn-delete { background: #dc3545; }
        .btn:hover { opacity: 0.85; }
        .loading { display: none; padding: 15px; background: #fff3cd; color: #856404; border-radius: 6px; margin-top: 15px; border-left: 5px solid #ffc107; font-weight: bold; }
        .loading.active { display: block; }
    </style>
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        <h1>💾 Резервные копии БД</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📥 Создать резервную копию</h2>
            <p style="color:#666;">Создаётся полный дамп базы данных <code>Project_Yfkin</code> в формате SQL.</p>
            
            <form method="POST" action="backup_create.php" id="backupForm">
                <button type="submit" class="btn-create" id="createBtn">💾 Создать бэкап сейчас</button>
            </form>
            
            <div class="loading" id="loadingBox">
                ⏳ Идёт создание резервной копии... Пожалуйста, не закрывайте страницу.
            </div>
        </div>
        
        <div class="card">
            <h2>📁 Существующие бэкапы (<?= count($backups) ?>)</h2>
            <?php if (empty($backups)): ?>
                <p style="color:#999;">Пока нет ни одной резервной копии.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr><th>Файл</th><th>Размер</th><th>Создан</th><th>Действия</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($backups as $b): ?>
                        <tr>
                            <td><b><?= htmlspecialchars($b['name'], ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><?= formatBytes($b['size']) ?></td>
                            <td><?= date('d.m.Y H:i:s', $b['date']) ?></td>
                            <td>
                                <a href="backup_download.php?file=<?= urlencode($b['name']) ?>" class="btn btn-download">⬇️ Скачать</a>
                                <a href="backup_restore.php?file=<?= urlencode($b['name']) ?>" class="btn btn-restore" onclick="return confirm('⚠️ ВОССТАНОВИТЬ БД?\n\nВсе текущие данные будут ЗАМЕНЕНЫ!')">♻️ Восстановить</a>
                                <a href="backup_delete.php?file=<?= urlencode($b['name']) ?>" class="btn btn-delete" onclick="return confirm('Удалить файл бэкапа?')">🗑 Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h2>📜 История бэкапов (лог)</h2>
            <?php if (empty($logs)): ?>
                <p style="color:#999;">История пуста.</p>
            <?php else: ?>
                <table class="data">
                    <thead><tr><th>Дата</th><th>Файл</th><th>Размер</th><th>Кто создал</th><th>Тип</th></tr></thead>
                    <tbody>
                        <?php foreach ($logs as $l): ?>
                        <tr>
                            <td><?= htmlspecialchars($l['Created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($l['Filename'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= $l['Size_KB'] ?> КБ</td>
                            <td><?= htmlspecialchars($l['Admin_Login'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= $l['Type'] === 'auto' ? '🤖 Авто' : '👤 Ручной' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.getElementById('backupForm').addEventListener('submit', function() {
            // Показываем анимацию загрузки
            document.getElementById('loadingBox').classList.add('active');
            const btn = document.getElementById('createBtn');
            
            // ВАЖНО: мы НЕ отключаем кнопку через disabled, чтобы форма ушла на сервер.
            // Вместо этого просто блокируем повторный клик через CSS.
            btn.style.pointerEvents = 'none';
            btn.style.opacity = '0.7';
            btn.textContent = '⏳ Создание...';
        });
    </script>
</body>
</html>