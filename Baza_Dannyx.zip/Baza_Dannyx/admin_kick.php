<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$userId = (int) ($_GET['user_id'] ?? 0);
$sessionId = $_GET['session'] ?? '';

if (!$userId) {
    $_SESSION['flash'] = ['msg' => 'Не указан пользователь', 'error' => true];
    header('Location: admin_stats.php');
    exit;
}

try {
    $pdo->prepare("UPDATE users SET Kick_Flag = 1, Last_Activity = NULL WHERE ID_U = ?")->execute([$userId]);

    if ($sessionId) {
        $pdo->prepare("DELETE FROM active_sessions WHERE Session_ID = ?")->execute([$sessionId]);
    } else {
        $pdo->prepare("DELETE FROM active_sessions WHERE User_ID = ?")->execute([$userId]);
    }

    $_SESSION['flash'] = ['msg' => "⚡ Пользователь отключён от системы.", 'error' => false];
} catch (\PDOException $e) {
    $_SESSION['flash'] = ['msg' => 'Ошибка: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin_stats.php');
exit;