<?php
declare(strict_types=1);

// Включаем показ ошибок, чтобы видеть причину
ini_set('display_errors', '1');
error_reporting(E_ALL);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён.');
}

function setFlash(string $msg, bool $isError = false): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'error' => $isError];
}

function logAdminAction(PDO $pdo, int $adminId, string $action, string $targetType, string $targetId, string $details): void
{
    try {
        $pdo->prepare("
            INSERT INTO admin_action_logs (Admin_ID, Action, Target_Type, Target_ID, Details, IP_Address)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            $adminId, $action, $targetType, $targetId, $details,
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
        ]);
    } catch (\Throwable $e) {
        // Если логирование не удалось, не ломаем основной процесс
    }
}

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
$action = $_POST['mass_action'] ?? '';
$userIds = $_POST['user_ids'] ?? [];

if (!$action) {
    setFlash('Не выбрано действие', true);
    header('Location: admin.php');
    exit;
}

if (empty($userIds) || !is_array($userIds)) {
    setFlash('Не выбрано ни одного пользователя', true);
    header('Location: admin.php');
    exit;
}

// Фильтруем ID (только положительные числа)
$userIds = array_filter(array_map('intval', $userIds), fn(int $id): bool => $id > 0);
$count = count($userIds);

if ($count === 0) {
    setFlash('Некорректные ID пользователей', true);
    header('Location: admin.php');
    exit;
}

// Защита: обычный Admin не может управлять System_Admin
if (!$isSystemAdmin) {
    $placeholders = implode(',', array_fill(0, $count, '?'));
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE ID_U IN ($placeholders) AND Role = 'System_Admin'");
    $stmt->execute($userIds);
    if ($stmt->fetchColumn() > 0) {
        setFlash('❌ Вы не можете управлять системными администраторами!', true);
        header('Location: admin.php');
        exit;
    }
}

$placeholders = implode(',', array_fill(0, $count, '?'));

try {
    switch ($action) {
        case 'ban':
            // Обновляем статус и флаг для принудительного выхода
            $stmt = $pdo->prepare("UPDATE users SET Ban = '1', Kick_Flag = 1 WHERE ID_U IN ($placeholders)");
            $stmt->execute($userIds);
            logAdminAction($pdo, (int)$_SESSION['user_id'], 'mass_ban', 'user', implode(',', $userIds), "Забанено: $count");
            setFlash("🚫 Забанено пользователей: $count");
            break;

        case 'unban':
            $stmt = $pdo->prepare("UPDATE users SET Ban = '0', Failed_Attempts = 0, Kick_Flag = 0 WHERE ID_U IN ($placeholders)");
            $stmt->execute($userIds);
            logAdminAction($pdo, (int)$_SESSION['user_id'], 'mass_unban', 'user', implode(',', $userIds), "Разбанено: $count");
            setFlash("✅ Разбанено пользователей: $count");
            break;

        case 'change_role_user':
        case 'change_role_admin':
        case 'change_role_sysadmin':
            $roles = [
                'change_role_user' => 'User',
                'change_role_admin' => 'Admin',
                'change_role_sysadmin' => 'System_Admin'
            ];
            $newRole = $roles[$action];

            if ($newRole === 'System_Admin' && !$isSystemAdmin) {
                throw new \Exception('Недостаточно прав для назначения System_Admin');
            }

            if (in_array((int)$_SESSION['user_id'], $userIds, true) && $newRole !== 'System_Admin' && $_SESSION['user_role'] === 'System_Admin') {
                throw new \Exception('Вы не можете понизить свою собственную роль');
            }

            $stmt = $pdo->prepare("UPDATE users SET Role = ?, Kick_Flag = 1 WHERE ID_U IN ($placeholders)");
            $stmt->execute(array_merge([$newRole], $userIds));
            
            // Обновляем Role_ID в user_profiles (если таблица существует)
            try {
                $roleStmt = $pdo->prepare("SELECT Role_ID FROM roles WHERE Role_Name = ?");
                $roleStmt->execute([$newRole]);
                $roleData = $roleStmt->fetch();
                if ($roleData) {
                    $pdo->prepare("UPDATE user_profiles SET Role_ID = ? WHERE User_ID IN ($placeholders)")
                        ->execute(array_merge([$roleData['Role_ID']], $userIds));
                }
            } catch (\Throwable $e) {
                // Игнорируем ошибки, если таблицы roles или user_profiles настроены иначе
            }

            logAdminAction($pdo, (int)$_SESSION['user_id'], 'mass_change_role', 'user', implode(',', $userIds), "Новая роль: $newRole, пользователей: $count");
            setFlash("✅ Роль изменена на «$newRole» у $count пользователей. Они отключены от системы.");
            break;

        case 'delete':
            if (!$isSystemAdmin) {
                throw new \Exception('Недостаточно прав');
            }

            if (in_array((int)$_SESSION['user_id'], $userIds, true)) {
                throw new \Exception('Вы не можете удалить свой собственный аккаунт');
            }

            $stmt = $pdo->prepare("DELETE FROM users WHERE ID_U IN ($placeholders)");
            $stmt->execute($userIds);
            logAdminAction($pdo, (int)$_SESSION['user_id'], 'mass_delete', 'user', implode(',', $userIds), "Удалено: $count");
            setFlash("🗑 Удалено пользователей: $count");
            break;

        case 'send_message':
            $_SESSION['mass_message_ids'] = $userIds;
            header('Location: admin_mass_message.php');
            exit;

        default:
            throw new \Exception('Неизвестное действие');
    }
} catch (\Throwable $e) {
    // Ловим ВСЕ ошибки PHP 8 (включая TypeError и PDOException)
    setFlash('❌ Ошибка БД: ' . $e->getMessage(), true);
}

header('Location: admin.php');
exit;