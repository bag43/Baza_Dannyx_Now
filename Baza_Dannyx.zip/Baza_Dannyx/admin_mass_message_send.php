 <?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён.');
}

$userIds = $_SESSION['mass_message_ids'] ?? [];
if (empty($userIds)) {
    $_SESSION['flash'] = ['msg' => 'Не выбраны получатели', 'error' => true];
    header('Location: admin.php');
    exit;
}

$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

if (!$subject || !$message) {
    $_SESSION['flash'] = ['msg' => 'Заполните все поля', 'error' => true];
    header('Location: admin_mass_message.php');
    exit;
}

try {
    $placeholders = implode(',', array_fill(0, count($userIds), '?'));
    $sql = "
        INSERT INTO notifications (User_ID, Sender_ID, Subject, Message, Is_System, Is_Read, Created_at)
        SELECT ID_U, ?, ?, ?, 0, 0, NOW()
        FROM users
        WHERE ID_U IN ($placeholders) AND Ban = '0'
    ";
    
    $params = array_merge([$_SESSION['user_id'], $subject, $message], $userIds);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $sent = $stmt->rowCount();
    
    $pdo->prepare("
        INSERT INTO admin_action_logs (Admin_ID, Action, Target_Type, Target_ID, Details, IP_Address)
        VALUES (?, 'mass_message', 'user', ?, ?, ?)
    ")->execute([
        $_SESSION['user_id'],
        implode(',', $userIds),
        "Отправлено $sent сообщений. Тема: $subject",
        $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
    ]);
    
    unset($_SESSION['mass_message_ids']);
    $_SESSION['flash'] = ['msg' => "✅ Сообщение отправлено $sent пользователям.", 'error' => false];
} catch (\PDOException $e) {
    $_SESSION['flash'] = ['msg' => '❌ Ошибка: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin.php');
exit;