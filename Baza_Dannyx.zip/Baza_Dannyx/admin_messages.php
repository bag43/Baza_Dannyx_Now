<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён. Только для администраторов.');
}

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ============ ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ИЗ URL (если перешли по кнопке) ============
$toUserId = isset($_GET['to']) ? (int)$_GET['to'] : 0;

// Получаем список всех пользователей
$users = $pdo->query("
    SELECT ID_U, Login, Role 
    FROM users 
    WHERE Ban = '0'
    ORDER BY Role, Login
")->fetchAll();

// Последние 30 отправленных сообщений от этого админа
try {
    $sentMessages = $pdo->prepare("
        SELECT 
            n.Notification_ID, n.User_ID, n.Subject, n.Message, n.Created_at, n.Is_Read,
            u.Login AS Recipient_Login,
            s.Login AS Sender_Login
        FROM notifications n
        JOIN users u ON u.ID_U = n.User_ID
        LEFT JOIN users s ON s.ID_U = n.Sender_ID
        WHERE n.Sender_ID = ?
        ORDER BY n.Created_at DESC
        LIMIT 30
    ");
    $sentMessages->execute([$_SESSION['user_id']]);
    $sent = $sentMessages->fetchAll();
} catch (\PDOException $e) {
    $sent = [];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Отправка сообщений</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .top-nav { display: flex; gap: 15px; margin-bottom: 20px; }
        .btn-back { display: inline-block; color: #007bff; text-decoration: none; font-weight: bold; padding: 8px 15px; border: 1px solid #007bff; border-radius: 5px; }
        .btn-back:hover { background: #007bff; color: white; }
        
        .card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card h2 { margin-top: 0; font-size: 18px; }
        
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 6px; font-size: 14px; }
        .form-group input[type="text"], .form-group select, .form-group textarea {
            width: 100%; padding: 10px; box-sizing: border-box;
            border: 1px solid #ccc; border-radius: 6px; font-size: 14px; font-family: inherit;
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .hint { font-size: 12px; color: #666; margin-top: 4px; }
        
        .submit-btn { padding: 12px 30px; background: #007bff; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold; }
        .submit-btn:hover { background: #0056b3; }
        
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #eee; }
        table.data th { background: #343a40; color: white; font-weight: normal; }
        table.data tr:hover { background: #f8f9fa; }
        
        .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-read { background: #d4edda; color: #155724; }
        .badge-unread { background: #fff3cd; color: #856404; }
        .badge-sys { background: #dc3545; color: white; }
        .badge-adm { background: #fd7e14; color: white; }
        .badge-usr { background: #007bff; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        <h1>✉️ Отправка сообщений</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📝 Новое сообщение</h2>
            <form method="POST" action="admin_messages_send.php">
                <div class="form-group">
                    <label>Получатель:</label>
                    <select name="user_id" required>
                        <option value="">— выберите получателя —</option>
                        <option value="all" style="font-weight:bold; color:#28a745;">📢 ВСЕМ ПОЛЬЗОВАТЕЛЯМ</option>
                        <?php foreach ($users as $u): 
                            if ($u['ID_U'] == $_SESSION['user_id']) continue;
                            $cls = $u['Role'] === 'System_Admin' ? '🔴' : ($u['Role'] === 'Admin' ? '🟠' : '🔵');
                            
                            // ЕСЛИ ID СОВПАДАЕТ С ТЕМ, ЧТО ПРИШЕЛ В URL - ВЫДЕЛЯЕМ ЕГО
                            $selected = ($u['ID_U'] == $toUserId) ? 'selected' : '';
                        ?>
                            <option value="<?= $u['ID_U'] ?>" <?= $selected ?>>
                                <?= $cls ?> <?= htmlspecialchars($u['Login'], ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($u['Role'], ENT_QUOTES, 'UTF-8') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Тема:</label>
                    <input type="text" name="subject" required maxlength="255" placeholder="Например: Важное объявление">
                </div>
                
                <div class="form-group">
                    <label>Текст сообщения:</label>
                    <textarea name="message" required maxlength="2000" placeholder="Введите текст сообщения..."></textarea>
                    <div class="hint">Максимум 2000 символов.</div>
                </div>
                
                <button type="submit" class="submit-btn">📤 Отправить сообщение</button>
            </form>
        </div>
        
        <div class="card">
            <h2>📨 Последние 30 отправленных вами сообщений</h2>
            <?php if (empty($sent)): ?>
                <p style="color:#999;">Вы пока не отправляли сообщений.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr><th>Дата</th><th>Получатель</th><th>Тема</th><th>Статус</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sent as $m): ?>
                        <tr>
                            <td><?= htmlspecialchars($m['Created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><b><?= htmlspecialchars($m['Recipient_Login'], ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><?= htmlspecialchars($m['Subject'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <?php if ($m['Is_Read'] === '1'): ?>
                                    <span class="badge badge-read">✅ Прочитано</span>
                                <?php else: ?>
                                    <span class="badge badge-unread">⏳ Не прочитано</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>