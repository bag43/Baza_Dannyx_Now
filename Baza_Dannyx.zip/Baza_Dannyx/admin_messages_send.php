<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён.');
}

$userInput = $_POST['user_id'] ?? '';
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

if (!$userInput || !$subject || !$message) {
    $_SESSION['flash'] = ['msg' => 'Заполните все поля!', 'error' => true];
    header('Location: admin_messages.php');
    exit;
}

if (mb_strlen($subject) > 255) {
    $_SESSION['flash'] = ['msg' => 'Тема слишком длинная (макс. 255)', 'error' => true];
    header('Location: admin_messages.php');
    exit;
}
if (mb_strlen($message) > 2000) {
    $_SESSION['flash'] = ['msg' => 'Сообщение слишком длинное (макс. 2000)', 'error' => true];
    header('Location: admin_messages.php');
    exit;
}

try {
    if ($userInput === 'all') {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (User_ID, Sender_ID, Subject, Message, Is_System, Is_Read, Created_at)
            SELECT ID_U, ?, ?, ?, 0, 0, NOW()
            FROM users
            WHERE ID_U != ? AND Ban = '0'
        ");
        $stmt->execute([$_SESSION['user_id'], $subject, $message, $_SESSION['user_id']]);
        $count = $stmt->rowCount();
        
        $_SESSION['flash'] = ['msg' => "✅ Сообщение отправлено $count пользователям.", 'error' => false];
    } else {
        $userId = (int) $userInput;
        
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE ID_U = ?");
        $check->execute([$userId]);
        if (!$check->fetchColumn()) {
            throw new \Exception('Пользователь не найден');
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO notifications (User_ID, Sender_ID, Subject, Message, Is_System, Is_Read, Created_at)
            VALUES (?, ?, ?, ?, 0, 0, NOW())
        ");
        $stmt->execute([$userId, $_SESSION['user_id'], $subject, $message]);
        
        $_SESSION['flash'] = ['msg' => "✅ Сообщение отправлено.", 'error' => false];
    }
} catch (\Exception $e) {
    $_SESSION['flash'] = ['msg' => '❌ Ошибка: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin_messages.php');
exit;