<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$userId = (int) ($_POST['user_id'] ?? 0);
$newPassword = $_POST['new_password'] ?? '';

if (!$userId || strlen($newPassword) < 4) {
    $_SESSION['flash'] = ['msg' => 'Пароль слишком короткий (минимум 4 символа)', 'error' => true];
    header('Location: admin_stats.php');
    exit;
}

try {
    $hash = hash('sha256', $newPassword);

    $pdo->prepare("
        UPDATE users 
        SET Password = ?, 
            Failed_Attempts = 0, 
            Last_Password_Change = NOW(),
            Kick_Flag = 1
        WHERE ID_U = ?
    ")->execute([$hash, $userId]);

    $pdo->prepare("
        INSERT INTO password_change_logs (User_ID, Changed_By, Changed_At)
        VALUES (?, ?, NOW())
    ")->execute([$userId, $_SESSION['user_id']]);

    $pdo->prepare("DELETE FROM active_sessions WHERE User_ID = ?")->execute([$userId]);

    $_SESSION['flash'] = ['msg' => "✅ Пароль изменён. Пользователь отключён.", 'error' => false];
} catch (\PDOException $e) {
    $_SESSION['flash'] = ['msg' => 'Ошибка: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin_stats.php');
exit;