<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

// Первичная загрузка данных для отрисовки HTML
$onlineCount = 0; // Значения подтянутся через JS
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мониторинг системы (Live)</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1400px; margin: 0 auto; }
        h1 { margin-top: 10px; display: flex; align-items: center; justify-content: space-between; }
        .live-indicator { display: flex; align-items: center; gap: 8px; font-size: 14px; color: #28a745; font-weight: bold; }
        .live-dot { width: 10px; height: 10px; background: #28a745; border-radius: 50%; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }
        
        .top-nav { display: flex; gap: 15px; margin-bottom: 20px; }
        .btn-back { display: inline-block; color: #007bff; text-decoration: none; font-weight: bold; padding: 8px 15px; border: 1px solid #007bff; border-radius: 5px; }
        .btn-back:hover { background: #007bff; color: white; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 25px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-left: 5px solid #007bff; transition: 0.3s; }
        .stat-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .stat-card.green { border-left-color: #28a745; }
        .stat-card.orange { border-left-color: #fd7e14; }
        .stat-card.red { border-left-color: #dc3545; }
        .stat-card.purple { border-left-color: #6f42c1; }
        .stat-card.info { border-left-color: #17a2b8; }
        .stat-card.disk { border-left-color: #343a40; }
        .stat-card .label { color: #666; font-size: 13px; margin-bottom: 5px; }
        .stat-card .value { font-size: 28px; font-weight: bold; color: #333; transition: color 0.3s; }
        .stat-card .sub { color: #999; font-size: 12px; margin-top: 5px; }
        
        .progress-bar { width: 100%; height: 10px; background: #e9ecef; border-radius: 5px; overflow: hidden; margin-top: 10px; }
        .progress-fill { height: 100%; transition: width 0.5s ease-in-out; }
        .disk-details { display: flex; justify-content: space-between; font-size: 11px; color: #666; margin-top: 4px; }
        
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card h2 { margin-top: 0; font-size: 18px; }
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #eee; }
        table.data th { background: #343a40; color: white; font-weight: normal; }
        table.data tr:hover { background: #f8f9fa; }
        .badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-sys { background: #dc3545; color: white; }
        .badge-adm { background: #fd7e14; color: white; }
        .badge-usr { background: #007bff; color: white; }
        .btn-kick { background: #dc3545; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold; }
        .btn-kick:hover { background: #c82333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        
        <h1>
            📡 Мониторинг системы
            <div class="live-indicator"><div class="live-dot"></div> LIVE (обновление каждые 3 сек)</div>
        </h1>
        
        <!-- ===== ПРОИЗВОДИТЕЛЬНОСТЬ И НАГРУЗКА ===== -->
        <div class="stats-grid">
            <div class="stat-card info">
                <div class="label">⚡ Отклик БД</div>
                <div class="value" id="val-db-ping">— <span style="font-size: 16px;">мс</span></div>
                <div class="sub">Запрос SELECT 1</div>
            </div>
            <div class="stat-card info" style="border-left-color: #6f42c1;">
                <div class="label">🔑 Отклик Входа</div>
                <div class="value" id="val-login-ping">— <span style="font-size: 16px;">мс</span></div>
                <div class="sub">Среднее за последние 50 входов</div>
            </div>
            <div class="stat-card purple">
                <div class="label">🔌 Лимит MySQL</div>
                <div class="value" id="val-max-conn">—</div>
                <div class="sub">Максимум сессий</div>
            </div>
            <div class="stat-card orange">
                <div class="label">👥 Лимит юзеров</div>
                <div class="value" id="val-max-users">—</div>
                <div class="sub">На основе RAM (<span id="val-free-mem">0</span> МБ)</div>
            </div>
        </div>

        <!-- ===== РАЗМЕР БД И ДИСКА ===== -->
        <div class="stats-grid">
            <div class="stat-card disk">
                <div class="label">🗄️ База данных на диске</div>
                <div class="value" id="val-db-size">— <span style="font-size: 16px;">МБ</span></div>
                <div class="sub">Данные актуальны</div>
            </div>
            
            <div class="stat-card green">
                <div class="label">🟢 Сейчас в сети</div>
                <div class="value" id="val-online-count">0</div>
                <div class="sub">активны за последние 5 минут</div>
            </div>
            
            <div class="stat-card <?= '' ?>" id="disk-card" style="grid-column: span 2;">
                <div class="label">💽 Свободно на диске</div>
                <div class="value" id="val-disk-free">—</div>
                <div class="sub">из <span id="val-disk-total">—</span> · занято <span id="val-disk-percent">0</span>%</div>
                <div class="progress-bar">
                    <div class="progress-fill" id="disk-progress-bar" style="width: 0%; background: #28a745;"></div>
                </div>
                <div class="disk-details">
                    <span>Использовано: <span id="val-disk-used">—</span></span>
                    <span><span id="val-disk-free-percent">0</span>% свободно</span>
                </div>
            </div>
        </div>
        
        <!-- ТАБЛИЦА ОНЛАЙН -->
        <div class="card">
            <h2>🟢 Сейчас в сети (<span id="table-online-count">0</span>)</h2>
            <div id="online-table-container">
                <p style="color:#999;">Загрузка данных...</p>
            </div>
        </div>
    </div>

    <script>
        // Функция для форматирования чисел
        function formatNumber(num) {
            return new Intl.NumberFormat('ru-RU').format(num);
        }

        // Основная функция обновления данных
        function fetchStats() {
            fetch('api_stats_data.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        console.error("Ошибка API:", data.error);
                        return;
                    }

                    // 1. Обновление карточек
                    document.getElementById('val-db-ping').innerHTML = data.db_response_ms + ' <span style="font-size: 16px;">мс</span>';
                    document.getElementById('val-login-ping').innerHTML = data.login_response_ms + ' <span style="font-size: 16px;">мс</span>';
                    document.getElementById('val-max-conn').textContent = data.max_connections;
                    document.getElementById('val-max-users').textContent = '~ ' + formatNumber(data.estimated_users);
                    document.getElementById('val-free-mem').textContent = formatNumber(data.free_mem_mb);

                    document.getElementById('val-db-size').innerHTML = data.db_size_mb + ' <span style="font-size: 16px;">МБ</span>';
                    document.getElementById('val-online-count').textContent = data.online_count;

                    document.getElementById('val-disk-free').textContent = data.disk_free_f;
                    document.getElementById('val-disk-total').textContent = data.disk_total_f;
                    document.getElementById('val-disk-used').textContent = data.disk_used_f;
                    document.getElementById('val-disk-percent').textContent = data.disk_percent;
                    document.getElementById('val-disk-free-percent').textContent = (100 - data.disk_percent).toFixed(1);

                    // Обновление прогресс-бара диска
                    const bar = document.getElementById('disk-progress-bar');
                    bar.style.width = data.disk_percent + '%';
                    
                    let barColor = '#28a745'; // Зеленый
                    if (data.disk_percent > 70) barColor = '#ffc107'; // Желтый
                    if (data.disk_percent > 90) barColor = '#dc3545'; // Красный
                    bar.style.background = barColor;

                    // 2. Обновление таблицы онлайн-пользователей
                    document.getElementById('table-online-count').textContent = data.online_count;
                    const tableContainer = document.getElementById('online-table-container');
                    
                    if (data.online_users.length === 0) {
                        tableContainer.innerHTML = '<p style="color:#999;">Нет активных пользователей.</p>';
                    } else {
                        let html = '<table class="data"><thead><tr><th>Логин</th><th>Роль</th><th>IP-адрес</th><th>Вход</th><th>Был активен</th><th>Действия</th></tr></thead><tbody>';
                        
                        data.online_users.forEach(u => {
                            let badgeClass = u.Role === 'System_Admin' ? 'badge-sys' : (u.Role === 'Admin' ? 'badge-adm' : 'badge-usr');
                            
                            html += `<tr>
                                <td><b>${u.Login}</b></td>
                                <td><span class="badge ${badgeClass}">${u.Role}</span></td>
                                <td>${u.IP_Address}</td>
                                <td>${u.Login_Time}</td>
                                <td>${u.Seconds_Ago} сек назад</td>
                                <td>
                                    <a href="admin_kick.php?user_id=${u.ID_U}&session=${encodeURIComponent(u.Session_ID)}" 
                                       class="btn-kick"
                                       onclick="return confirm('Отключить пользователя «${u.Login}» от системы?')">
                                       ⚡ Отключить
                                    </a>
                                </td>
                            </tr>`;
                        });
                        
                        html += '</tbody></table>';
                        tableContainer.innerHTML = html;
                    }
                })
                .catch(err => console.error("Ошибка получения данных:", err));
        }

        // Запускаем сразу при загрузке страницы
        fetchStats();

        // И запускаем интервал каждые 3 секунды (3000 мс)
        setInterval(fetchStats, 3000);
    </script>
</body>
</html>