<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$logFile = __DIR__ . '/selenium_test_results.json';
$groupId = $_GET['group_id'] ?? null;

if (!file_exists($logFile)) {
    die('Файл с результатами еще не создан.');
}

$content = file_get_contents($logFile);
$data = json_decode($content, true) ?: [];

if ($groupId) {
    // Ищем нужную группу
    $groupToDownload = null;
    foreach ($data as $group) {
        if ($group['group_id'] === $groupId) {
            $groupToDownload = $group;
            break;
        }
    }
    
    if (!$groupToDownload) {
        die('Группа с таким ID не найдена.');
    }
    
    $output = json_encode($groupToDownload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $filename = 'selenium_group_' . $groupId . '.json';
} else {
    // Отдаем весь файл
    $output = $content;
    $filename = 'selenium_all_results_' . date('Y-m-d_H-i-s') . '.json';
}

header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($output));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
echo $output;
exit;