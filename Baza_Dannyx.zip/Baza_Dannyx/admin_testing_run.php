<?php declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);
set_time_limit(300);

require 'db.php';

if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require __DIR__ . '/vendor/autoload.php';
}

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;
use Facebook\WebDriver\Chrome\ChromeOptions;

header('Content-Type: application/json');

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    echo json_encode(['success' => false, 'message' => 'Доступ запрещён.']);
    exit;
}

$action = $_POST['action'] ?? 'auth';
$targetUrl = $_POST['target_url'] ?? 'http://localhost:3000/index.php';
$accountsRaw = trim($_POST['accounts'] ?? '');
$accounts = [];

if ($action === 'auth') {
    if (!$accountsRaw) {
        echo json_encode(['success' => false, 'message' => 'Список аккаунтов пуст.']);
        exit;
    }
    $lines = explode("\n", $accountsRaw);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode(':', $line);
        if (count($parts) >= 2) {
            $accounts[] = ['login' => trim($parts[0]), 'password' => trim($parts[1])];
        }
    }
}

$fp = @fsockopen('localhost', 4444, $errno, $errstr, 1);
if (!$fp) {
    echo json_encode(['success' => false, 'message' => 'ChromeDriver не запущен на порту 4444!']);
    exit;
}
fclose($fp);

$logFile = __DIR__ . '/selenium_test_results.json';
$currentGroupResults = [];
$groupTimestamp = date('Y-m-d H:i:s');
$groupId = date('Ymd_His') . '_' . substr(md5(uniqid('', true)), 0, 4);

try {
    $serverUrl = 'http://localhost:4444';
    $options = new ChromeOptions();
    $options->setBinary('/usr/bin/chromium-browser');
    $options->addArguments(['--headless', '--no-sandbox', '--disable-dev-shm-usage']);
    
    $capabilities = DesiredCapabilities::chrome();
    $capabilities->setCapability(ChromeOptions::CAPABILITY, $options);
    
    $driver = RemoteWebDriver::create($serverUrl, $capabilities, 10000, 10000);
    
    try {
        if ($action === 'speed') {
            // === ТЕСТ СКОРОСТИ (через JS Fetch) ===
            $testUrl = 'http://localhost:3000/speed_test_endpoint.php';
            
            $driver->get('http://localhost:3000/index.php');
            
            $result = $driver->executeScript("
                return new Promise((resolve, reject) => {
                    const start = performance.now();
                    fetch('{$testUrl}')
                        .then(response => {
                            if (!response.ok) throw new Error('HTTP error ' + response.status);
                            return response.blob();
                        })
                        .then(blob => {
                            const end = performance.now();
                            const timeTaken = (end - start) / 1000;
                            const sizeMB = blob.size / (1024 * 1024);
                            resolve({ timeTaken: timeTaken, sizeMB: sizeMB });
                        })
                        .catch(err => reject(err.message));
                });
            ");
            
            if (isset($result['timeTaken']) && isset($result['sizeMB'])) {
                $timeTaken = $result['timeTaken'];
                $fileSizeMB = $result['sizeMB'];
                if ($timeTaken <= 0) $timeTaken = 0.001;
                
                $speed = $fileSizeMB / $timeTaken;
                $status = 'SUCCESS';
                $message = "Скорость: " . round($speed, 2) . " МБ/с (Скачано " . round($fileSizeMB, 2) . " МБ за " . round($timeTaken, 2) . " сек).";
            } else {
                $status = 'FAIL';
                $message = "Ошибка при замере скорости через JS.";
            }
            
            $currentGroupResults[] = ['login' => 'Тест Скорости', 'status' => $status, 'message' => $message];

        } else if ($action === 'disk') {
            // === АВТОРИЗАЦИЯ ДЛЯ ДОСТУПА К СТРАНИЦЕ ===
            $driver->get('http://localhost:3000/index.php');
            $driver->executeScript("
                document.querySelector('input[name=\"login\"]').value = 'sys_admin_1';
                document.querySelector('input[name=\"password\"]').value = 'admin123';
                document.querySelector('input[name=\"captcha_order\"]').value = '1,2,3,4';
                document.getElementById('loginForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
            ");
            $driver->wait(15)->until(WebDriverExpectedCondition::urlContains('dashboard.php'));

            // === ПРОВЕРКА ВИДЖЕТА ДИСКА И БД ===
            $testUrl = 'http://localhost:3000/admin_testing.php';
            $driver->get($testUrl);
            
            $driver->wait(5)->until(
                WebDriverExpectedCondition::presenceOfElementLocated(WebDriverBy::id('disk-space-widget'))
            );
            
            $totalText = $driver->findElement(WebDriverBy::id('disk-total'))->getText();
            $freeText  = $driver->findElement(WebDriverBy::id('disk-free'))->getText();
            $dbText    = $driver->findElement(WebDriverBy::id('db-size'))->getText(); // Читаем размер БД
            
            if (!empty($totalText) && !empty($freeText) && !empty($dbText) && $totalText !== '—' && $freeText !== '—' && $dbText !== '—') {
                $status = 'SUCCESS';
                $message = "Виджет работает. Свободно на диске: $freeText. Размер БД: $dbText";
            } else {
                $status = 'FAIL';
                $message = "Виджет диска или БД не найден, либо отображает пустые данные.";
            }
            
            $currentGroupResults[] = ['login' => 'Тест Диск', 'status' => $status, 'message' => $message];
        } else {
            // === ТЕСТ АВТОРИЗАЦИИ ===
            foreach ($accounts as $acc) {
                $testLogin = $acc['login'];
                $testPassword = $acc['password'];
                $status = 'FAIL';
                $message = '';
                
                $driver->manage()->deleteAllCookies();
                
                try {
                    if (strpos($targetUrl, 'phpmyadmin') !== false) {
                        $driver->get($targetUrl);
                        $driver->findElement(WebDriverBy::id('input_username'))->sendKeys($testLogin);
                        $driver->findElement(WebDriverBy::id('input_password'))->sendKeys($testPassword);
                        $driver->findElement(WebDriverBy::id('input_go'))->click();
                        sleep(1);
                        if (strpos($driver->getCurrentURL(), 'phpmyadmin/index.php') !== false) {
                            $status = 'SUCCESS';
                            $message = "Успешная авторизация в phpMyAdmin.";
                        } else {
                            $message = "Не удалось войти в phpMyAdmin.";
                        }
                    } else {
                        $driver->get($targetUrl);
                        
                        $jsLogin = json_encode($testLogin);
                        $jsPassword = json_encode($testPassword);
                        
                        $driver->executeScript("
                            document.querySelector('input[name=\"login\"]').value = {$jsLogin};
                            document.querySelector('input[name=\"password\"]').value = {$jsPassword};
                            document.querySelector('input[name=\"captcha_order\"]').value = '1,2,3,4';
                            document.getElementById('loginForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                        ");
                        
                        try {
                            $driver->wait(15)->until(WebDriverExpectedCondition::urlContains('dashboard.php'));
                            $status = 'SUCCESS';
                            $message = "Успешная авторизация.";
                        } catch (\Exception $e) {
                            $currentUrl = $driver->getCurrentURL();
                            $msgText = $driver->executeScript("return document.getElementById('loginMessage') ? document.getElementById('loginMessage').innerText : 'нет сообщения';");
                            $message = "Таймаут. URL: " . $currentUrl . " | Ответ сервера: " . $msgText;
                        }
                    }
                } catch (\Exception $e) {
                    $message = 'Ошибка Selenium: ' . $e->getMessage();
                }
                
                $currentGroupResults[] = ['login' => $testLogin, 'status' => $status, 'message' => $message];
            }
        }
    } finally {
        try { $driver->quit(); } catch (\Exception $e) {}
    }
    
    $existingGroups = [];
    if (file_exists($logFile)) {
        $existingGroups = json_decode(file_get_contents($logFile), true) ?: [];
    }
    
    $successCount = count(array_filter($currentGroupResults, fn($r) => $r['status'] === 'SUCCESS'));
    $newGroup = [
        'group_id'   => $groupId,
        'timestamp'  => $groupTimestamp,
        'target_url' => ($action === 'disk') ? 'disk_space' : (($action === 'speed') ? 'speed_test' : $targetUrl),
        'total'      => count($currentGroupResults),
        'success'    => $successCount,
        'results'    => $currentGroupResults
    ];
    
    array_unshift($existingGroups, $newGroup);
    if (count($existingGroups) > 20) {
        $existingGroups = array_slice($existingGroups, 0, 20);
    }
    
    file_put_contents($logFile, json_encode($existingGroups, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo json_encode([
        'success' => true, 
        'message' => "Тест завершен. Успешно: {$successCount} из " . count($currentGroupResults)
    ]);
    
} catch (\Throwable $e) { 
    echo json_encode([
        'success' => false, 
        'message' => 'ОШИБКА [' . get_class($e) . ']: ' . $e->getMessage() . ' (Файл: ' . basename($e->getFile()) . ':' . $e->getLine() . ')'
    ]);
}