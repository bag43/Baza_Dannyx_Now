<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if (isset($_GET['force_error']) && $_GET['force_error'] === '1') {
    http_response_code(500);
    echo json_encode(['error' => 'Внутренняя ошибка сервера (тест)'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

require 'db.php';

try {
    $stmt = $pdo->query("
        SELECT n.Id, n.Title, n.Content, n.created_at, u.Login
        FROM notes n
        JOIN users u ON u.ID_U = n.Id_user
        ORDER BY n.Id ASC
    ");
    $rows = $stmt->fetchAll();
} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error'], JSON_UNESCAPED_UNICODE);
    exit;
}

$result = [];
foreach ($rows as $row) {
    $result[] = [
        'id'             => str_pad((string) $row['Id'], 5, '0', STR_PAD_LEFT),
        'title_user'     => $row['Title'] . ' - ' . $row['Login'],
        'content'        => $row['Content'],
        'formatted_date' => date('d.m.Y', strtotime($row['created_at'])),
    ];
}

$flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT;
$json = json_encode($result, $flags);

if ($json === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Ошибка сериализации данных'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (isset($_GET['download']) && $_GET['download'] === '1') {
    $filename = $_GET['filename'] ?? 'notes';
    $filename = preg_replace('/[^a-zA-Z0-9_\-]/', '', $filename);
    if ($filename === '') {
        $filename = 'notes';
    }
    header('Content-Disposition: attachment; filename="' . $filename . '.json"');
    header('Content-Length: ' . strlen($json));
}

http_response_code(200);
echo $json;