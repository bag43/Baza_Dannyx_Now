<?php declare(strict_types=1);

require 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    echo json_encode(['error' => 'Доступ запрещён']);
    exit;
}

// ============ ОБНОВЛЯЕМ АКТИВНОСТЬ ТЕКУЩЕГО АДМИНА ============
// Так как мониторинг обновляется каждые 3 секунды, мы "пингуем" сессию админа
if (isset($_SESSION['user_id'], $_SESSION['session_id'])) {
    try {
        $pdo->prepare("UPDATE active_sessions SET Last_Ping = NOW() WHERE Session_ID = ?")
            ->execute([$_SESSION['session_id']]);
        $pdo->prepare("UPDATE users SET Last_Activity = NOW() WHERE ID_U = ?")
            ->execute([$_SESSION['user_id']]);
    } catch (\PDOException $e) {
        // Игнорируем, если таблицы нет
    }
}

$data = [];

// 1. Замер отклика БД
$dbPingStart = microtime(true);
try {
    $pdo->query("SELECT 1");
    $dbPingEnd = microtime(true);
    $data['db_response_ms'] = round(($dbPingEnd - $dbPingStart) * 1000, 2);
} catch (\PDOException $e) {
    $data['db_response_ms'] = 'Ошибка';
}

// 2. Среднее время входа
try {
    $loginAvg = $pdo->query("SELECT ROUND(AVG(Response_Time_Ms), 2) FROM (SELECT Response_Time_Ms FROM login_metrics ORDER BY Created_at DESC LIMIT 50) as sub")->fetchColumn();
    $data['login_response_ms'] = $loginAvg ?: '0.00';
} catch (\PDOException $e) {
    $data['login_response_ms'] = '—';
}

// 3. Лимит подключений MySQL
try {
    $maxConnStmt = $pdo->query("SHOW VARIABLES LIKE 'max_connections'");
    $maxConnData = $maxConnStmt->fetch(\PDO::FETCH_ASSOC);
    $data['max_connections'] = $maxConnData['Value'] ?? '—';
} catch (\PDOException $e) {
    $data['max_connections'] = '—';
}

// 4. Онлайн пользователи (активные за последние 5 минут)
try {
    $onlineStmt = $pdo->query("
        SELECT u.ID_U, u.Login, u.Role, s.IP_Address, s.Login_Time, s.Session_ID,
               TIMESTAMPDIFF(SECOND, s.Last_Ping, NOW()) AS Seconds_Ago
        FROM active_sessions s
        JOIN users u ON u.ID_U = s.User_ID
        WHERE s.Last_Ping > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ORDER BY s.Last_Ping DESC
    ");
    $data['online_users'] = $onlineStmt->fetchAll();
    $data['online_count'] = count($data['online_users']);
} catch (\PDOException $e) {
    $data['online_users'] = [];
    $data['online_count'] = 0;
}

// 5. Данные о диске и БД
$diskTotal = @disk_total_space('/');
$diskFree  = @disk_free_space('/');
$diskUsed  = $diskTotal - $diskFree;

function formatBytes(float|int|false|null $bytes, int $precision = 2): string {
    if ($bytes === false || $bytes === null) return '—';
    $units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}

$data['disk_total_f'] = formatBytes($diskTotal);
$data['disk_free_f'] = formatBytes($diskFree);
$data['disk_used_f'] = formatBytes($diskUsed);
$data['disk_percent'] = ($diskTotal > 0) ? round(($diskUsed / $diskTotal) * 100, 1) : 0;

try {
    $dbSize = $pdo->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) FROM information_schema.tables WHERE table_schema = DATABASE()")->fetchColumn() ?: 0;
    $data['db_size_mb'] = $dbSize;
} catch (\PDOException $e) {
    $data['db_size_mb'] = 0;
}

// 6. Оперативная память
$freeMemMB = 0;
if (is_readable('/proc/meminfo')) {
    $meminfo = file_get_contents('/proc/meminfo');
    if (preg_match('/MemAvailable:\s+(\d+)\s+kB/', $meminfo, $matches)) {
        $freeMemMB = (int)$matches[1] / 1024;
    }
}
$data['free_mem_mb'] = round($freeMemMB);
$data['estimated_users'] = ($freeMemMB > 0) ? floor(($freeMemMB * 0.8) / 50) : '—';

echo json_encode($data);