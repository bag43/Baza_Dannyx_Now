<?php declare(strict_types=1);

// Включаем показ ошибок для отладки
ini_set('display_errors', '1');
error_reporting(E_ALL);
set_time_limit(300);
ini_set('memory_limit', '512M');

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$backupDir = __DIR__ . '/backups';
if (!is_dir($backupDir)) {
    if (!@mkdir($backupDir, 0755, true)) {
        die('Ошибка: Не удалось создать папку /backups. Проверьте права.');
    }
}
if (!is_writable($backupDir)) {
    die('Ошибка: Папка /backups недоступна для записи. Выполните в терминале: chmod 755 backups');
}

$filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
$filepath = $backupDir . '/' . $filename;

try {
    $success = false;
    
    // Пытаемся создать через mysqldump (если есть в системе)
    if (function_exists('exec')) {
        $cmd = sprintf(
            'mysqldump --host=%s --user=%s --password=%s %s > %s 2>&1',
            escapeshellarg($host),
            escapeshellarg($user),
            escapeshellarg($pass),
            escapeshellarg($db),
            escapeshellarg($filepath)
        );
        @exec($cmd, $output, $returnCode);
        
        if ($returnCode === 0 && file_exists($filepath) && filesize($filepath) > 100) {
            $success = true;
        }
    }
    
    // Резервный вариант (чистый PHP)
    if (!$success) {
        $fp = fopen($filepath, 'w');
        if (!$fp) {
            throw new \Exception('Не удалось открыть файл для записи.');
        }

        fwrite($fp, "-- Резервная копия БД `$db`\n-- Создано: " . date('Y-m-d H:i:s') . "\n\n");
        fwrite($fp, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\nSET time_zone = \"+00:00\";\nSET NAMES utf8mb4;\n\n");

        $tables = $pdo->query("SHOW TABLES")->fetchAll(\PDO::FETCH_COLUMN);

        foreach ($tables as $table) {
            $safeTable = str_replace('`', '``', $table);
            $createStmt = $pdo->query("SHOW CREATE TABLE `$safeTable`")->fetch();
            $createSql = $createStmt['Create Table'] ?? $createStmt[1] ?? '';

            fwrite($fp, "\nDROP TABLE IF EXISTS `$safeTable`;\n$createSql;\n\n");

            $rows = $pdo->query("SELECT * FROM `$safeTable`")->fetchAll(\PDO::FETCH_ASSOC);
            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $cols = array_map(fn(string $c): string => "`" . str_replace('`', '``', $c) . "`", array_keys($row));
                    $vals = array_map(function(mixed $v) use ($pdo): string {
                        return $v === null ? 'NULL' : $pdo->quote((string) $v);
                    }, array_values($row));
                    fwrite($fp, "INSERT INTO `$safeTable` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n");
                }
            }
        }
        fclose($fp);
        $success = true;
    }

    if (!$success) {
        throw new \Exception('Не удалось создать SQL-дамп.');
    }

    $sizeKb = (int) (filesize($filepath) / 1024);
    
    // Записываем в лог бэкапов
    $pdo->prepare("INSERT INTO backup_logs (Filename, Size_KB, Created_By, Type) VALUES (?, ?, ?, 'manual')")
        ->execute([$filename, $sizeKb, $_SESSION['user_id']]);

    // Записываем в лог действий
    $pdo->prepare("INSERT INTO admin_action_logs (Admin_ID, Action, Target_Type, Target_ID, Details, IP_Address) VALUES (?, 'create_backup', 'database', ?, ?, ?)")
        ->execute([$_SESSION['user_id'], $db, "Создан бэкап: $filename ($sizeKb КБ)", $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);

    $_SESSION['flash'] = ['msg' => "✅ Бэкап создан: $filename ($sizeKb КБ)", 'error' => false];
    
} catch (\Throwable $e) {
    if (file_exists($filepath)) @unlink($filepath);
    $_SESSION['flash'] = ['msg' => '❌ Ошибка: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin_backup.php');
exit;