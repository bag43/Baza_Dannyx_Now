<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$file = basename($_GET['file'] ?? '');
if (!$file || !preg_match('/^backup_[\d\-_]+\.sql$/', $file)) {
    $_SESSION['flash'] = ['msg' => 'Неверное имя файла', 'error' => true];
    header('Location: admin_backup.php');
    exit;
}

$path = __DIR__ . '/backups/' . $file;
if (file_exists($path)) {
    unlink($path);
    $_SESSION['flash'] = ['msg' => "🗑 Файл $file удалён.", 'error' => false];
} else {
    $_SESSION['flash'] = ['msg' => 'Файл не найден', 'error' => true];
}

header('Location: admin_backup.php');
exit;