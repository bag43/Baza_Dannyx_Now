<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$file = basename($_GET['file'] ?? '');
if (!$file || !preg_match('/^backup_[\d\-_]+\.sql$/', $file)) {
    die('Неверное имя файла');
}

$path = __DIR__ . '/backups/' . $file;
if (!file_exists($path)) die('Файл не найден');

header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;