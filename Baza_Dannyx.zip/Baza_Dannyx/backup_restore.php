<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

@set_time_limit(600);
@ini_set('memory_limit', '512M');

$file = basename($_GET['file'] ?? '');
if (!$file || !preg_match('/^backup_[\d\-_]+\.sql$/', $file)) {
    $_SESSION['flash'] = ['msg' => 'Неверное имя файла', 'error' => true];
    header('Location: admin_backup.php');
    exit;
}

$path = __DIR__ . '/backups/' . $file;
if (!file_exists($path)) {
    $_SESSION['flash'] = ['msg' => 'Файл не найден', 'error' => true];
    header('Location: admin_backup.php');
    exit;
}

try {
    $sql = file_get_contents($path);
    if ($sql === false) {
        throw new \Exception('Не удалось прочитать файл');
    }

    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    $statements = [];
    $current = '';
    $inString = false;
    $stringChar = '';
    $len = strlen($sql);
    
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        $prev = $i > 0 ? $sql[$i - 1] : '';
        
        if (!$inString && ($ch === "'" || $ch === '"')) {
            $inString = true;
            $stringChar = $ch;
        } elseif ($inString && $ch === $stringChar && $prev !== '\\') {
            $inString = false;
        }
        
        $current .= $ch;
        
        if (!$inString && $ch === ';') {
            $stmt = trim($current);
            if ($stmt !== '' && !preg_match('/^--/', $stmt)) {
                $statements[] = $stmt;
            }
            $current = '';
        }
    }

    $executed = 0;
    foreach ($statements as $stmt) {
        $stmt = trim($stmt);
        if ($stmt === '' || str_starts_with($stmt, '--')) {
            continue;
        }
        try {
            $pdo->exec($stmt);
            $executed++;
        } catch (\PDOException $e) {
            // Игнорируем ошибки дублирования таблиц
        }
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

    $pdo->prepare("
        INSERT INTO admin_action_logs (Admin_ID, Action, Target_Type, Target_ID, Details, IP_Address)
        VALUES (?, 'restore_backup', 'database', ?, ?, ?)
    ")->execute([
        $_SESSION['user_id'], $file,
        "Восстановлено из бэкапа. Выполнено запросов: $executed",
        $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
    ]);

    $_SESSION['flash'] = ['msg' => "✅ База восстановлена из $file (выполнено $executed запросов).", 'error' => false];
} catch (\Exception $e) {
    $_SESSION['flash'] = ['msg' => '❌ Ошибка восстановления: ' . $e->getMessage(), 'error' => true];
}

header('Location: admin_backup.php');
exit;