/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Project_Yfkin
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `active_sessions`
--

DROP TABLE IF EXISTS `active_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `active_sessions` (
  `Session_ID` varchar(128) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `IP_Address` varchar(45) NOT NULL,
  `User_Agent` varchar(255) DEFAULT NULL,
  `Login_Time` datetime NOT NULL DEFAULT current_timestamp(),
  `Last_Ping` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Session_ID`),
  KEY `idx_user` (`User_ID`),
  KEY `idx_ping` (`Last_Ping`),
  CONSTRAINT `active_sessions_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_sessions`
--

LOCK TABLES `active_sessions` WRITE;
/*!40000 ALTER TABLE `active_sessions` DISABLE KEYS */;
INSERT INTO `active_sessions` VALUES
('0qqtkl8vl7h0bq8ahia93hogpu',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-22 10:17:26','2026-10-22 10:35:33'),
('2i8uki18qjmqrkv5d1f1gsb57b',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-22 11:18:56','2026-10-22 11:18:56'),
('4bsn288qler2qhoj9um61pgrg9',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 10:23:39','2026-10-28 10:23:39'),
('4ktgao27nkuloo2hh160l5q6pg',8,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-12 11:57:31','2026-10-12 11:57:31'),
('67d9lbmo1ufm6tjb028j6ke1nm',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-28 09:06:02','2026-10-28 09:06:18'),
('69kc7srp7m4hic8cacjc7529gd',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-22 09:26:50','2026-10-22 09:28:21'),
('7nb38l698l960b0hmlqrlp01es',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-22 11:45:46','2026-10-22 11:45:46'),
('82qj543i98mmsbm8j6ppa7sri7',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-11-09 09:38:32','2026-11-09 10:07:32'),
('88hn9kqe3g03t8dqodp3h7d0rq',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-14 09:22:54','2026-10-14 10:34:39'),
('9uafebfmvfn0skkngmab6p8agq',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 09:59:23','2026-10-28 09:59:23'),
('afudjqj3a4gcm0ciphi99od05p',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-11-09 09:53:02','2026-11-09 09:53:02'),
('bnjprik90fg6mvv62kv4mitdmf',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-22 09:42:16','2026-10-22 09:45:03'),
('ca8o3iof0ntvrghl7cimigsaa0',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-12 11:57:00','2026-10-12 11:57:00'),
('cdqnobekc9vqveb1pbrlrsinpe',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-22 09:45:43','2026-10-22 10:17:03'),
('de7us0sqksjo5cbc6dgu1lk4n4',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 09:59:17','2026-10-28 09:59:17'),
('dmpsoeiekn2c4pk8f1r31n5b92',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-12 11:31:00','2026-10-12 11:56:06'),
('do5c7ghr8hgbevrhiquifapkq3',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-11-09 09:03:02','2026-11-09 09:37:41'),
('ec9gvc8rgh246vkf72o2lr3ntl',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 09:59:00','2026-10-28 09:59:00'),
('gjc4i72u5r3idt8elahpj9gpp1',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-11-09 09:04:26','2026-11-09 09:04:26'),
('idsjco8s2595h78ei86tdvdpob',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-21 10:04:09','2026-10-21 10:04:09'),
('jafn5e8o1q3mv3lvqklls3fafc',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 10:09:14','2026-10-28 10:09:14'),
('k8268pcbo4pi15ccni8jthi14b',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 09:58:10','2026-10-28 09:58:10'),
('nonkv369g75gghf4oboc2fn5dk',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 10:21:18','2026-10-28 10:21:18'),
('putagc2fva4n2ar4untrrhn1lo',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-21 09:27:49','2026-10-21 10:02:54'),
('s44303n02ovq69j9l3bl0id7m5',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-28 09:38:21','2026-10-28 09:38:21'),
('t3femuhs4unq52fjb9g21m15uc',1,'::1','Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-10-15 09:24:48','2026-10-15 11:44:48'),
('vm1n2aono8vvdi699fit6nf9tu',1,'::1','Mozilla/5.0 (X11; Linux x86_64; Chromium GOST) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.0.0 Safari/537.36','2026-10-22 11:49:24','2026-10-22 11:49:24');
/*!40000 ALTER TABLE `active_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_action_logs`
--

DROP TABLE IF EXISTS `admin_action_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_action_logs` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Admin_ID` int(11) NOT NULL,
  `Action` varchar(50) NOT NULL COMMENT 'Тип действия',
  `Target_Type` varchar(50) DEFAULT NULL COMMENT 'Над чем (user/table/backup)',
  `Target_ID` varchar(50) DEFAULT NULL COMMENT 'ID цели',
  `Details` text DEFAULT NULL COMMENT 'Детали',
  `IP_Address` varchar(45) DEFAULT NULL,
  `Created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Log_ID`),
  KEY `idx_admin` (`Admin_ID`),
  KEY `idx_date` (`Created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_action_logs`
--

LOCK TABLES `admin_action_logs` WRITE;
/*!40000 ALTER TABLE `admin_action_logs` DISABLE KEYS */;
INSERT INTO `admin_action_logs` VALUES
(1,1,'mass_ban','user','6,7','Забанено: 2','::1','2026-11-09 09:51:50');
/*!40000 ALTER TABLE `admin_action_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Old_Role` varchar(50) NOT NULL,
  `New_Role` varchar(50) NOT NULL,
  `Changed_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Log_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,9,'User','Admin','2026-10-12 09:55:26');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `Backup_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Filename` varchar(255) NOT NULL,
  `Size_KB` int(11) NOT NULL,
  `Created_By` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `Type` enum('manual','auto') NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`Backup_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ban_logs`
--

DROP TABLE IF EXISTS `ban_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ban_logs` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Old_Ban` varchar(1) NOT NULL,
  `New_Ban` varchar(1) NOT NULL,
  `Changed_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Log_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ban_logs`
--

LOCK TABLES `ban_logs` WRITE;
/*!40000 ALTER TABLE `ban_logs` DISABLE KEYS */;
INSERT INTO `ban_logs` VALUES
(1,8,'0','1','2026-10-08 10:16:24'),
(2,8,'1','0','2026-10-12 09:55:13'),
(3,8,'0','1','2026-10-12 09:55:17'),
(4,8,'1','0','2026-10-12 09:55:17'),
(5,7,'0','1','2026-10-12 09:59:24'),
(6,7,'1','0','2026-10-12 09:59:26'),
(7,4,'0','1','2026-10-12 11:55:45'),
(8,3,'0','1','2026-10-28 09:58:11'),
(9,5,'0','1','2026-10-28 09:58:27'),
(10,4,'1','0','2026-11-09 09:18:23'),
(11,3,'1','0','2026-11-09 09:18:24'),
(12,5,'1','0','2026-11-09 09:18:25'),
(13,6,'0','1','2026-11-09 09:51:50'),
(14,7,'0','1','2026-11-09 09:51:50'),
(15,6,'1','0','2026-11-09 09:53:39'),
(16,7,'1','0','2026-11-09 10:10:18');
/*!40000 ALTER TABLE `ban_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Код заметки',
  `Title` varchar(255) NOT NULL COMMENT 'Заголовок',
  `Content` text NOT NULL COMMENT 'Содержание',
  `Id_user` int(11) NOT NULL COMMENT 'Код пользователя (внешний ключ)',
  `created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Дата создания',
  PRIMARY KEY (`Id`),
  KEY `idx_user` (`Id_user`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_notes_user` FOREIGN KEY (`Id_user`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES
(1,'Первая заметка','Это тестовая заметка системного администратора. Проверка работы API.',1,'2026-10-14 09:18:56'),
(2,'Важное напоминание','Не забыть проверить бэкапы базы данных в конце недели.',2,'2026-10-14 09:18:56'),
(3,'Список задач на день','1. Проверить логи\n2. Ответить на сообщения\n3. Обновить пароли',3,'2026-10-14 09:18:56'),
(4,'Идея для проекта','Добавить в админку экспорт данных в Excel и PDF-отчёты.',4,'2026-10-14 09:18:56'),
(5,'Личная заметка','Не забыть поздравить коллегу с днём рождения 15 октября.',5,'2026-10-14 09:18:56');
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `Notification_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Message` text NOT NULL,
  `Is_Read` tinyint(1) NOT NULL DEFAULT 0,
  `Created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `Sender_ID` int(11) DEFAULT NULL COMMENT 'Кто отправил (NULL = системное)',
  `Subject` varchar(255) DEFAULT NULL COMMENT 'Тема сообщения',
  `Is_System` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = системное, 0 = от админа',
  `Deleted_By_User` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Пользователь удалил',
  PRIMARY KEY (`Notification_ID`),
  KEY `idx_user_read` (`User_ID`,`Is_Read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,8,'Добро пожаловать в систему! Пожалуйста, не забудьте сменить пароль, если он был выдан администратором.',0,'2026-10-08 10:12:31',NULL,NULL,0,0),
(2,8,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-08 10:16:24',NULL,NULL,0,0),
(4,8,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-12 09:55:17',NULL,NULL,0,0),
(5,7,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-12 09:59:24',NULL,NULL,0,0),
(6,3,'67',0,'2026-10-12 11:55:26',1,'Чикен нагетс',0,0),
(7,4,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-12 11:55:45',NULL,NULL,0,0),
(8,3,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-28 09:58:11',NULL,NULL,0,0),
(9,5,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-10-28 09:58:27',NULL,NULL,0,0),
(10,6,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-11-09 09:51:50',NULL,NULL,0,0),
(11,7,'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.',0,'2026-11-09 09:51:50',NULL,NULL,0,0);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_change_logs`
--

DROP TABLE IF EXISTS `password_change_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_change_logs` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `Changed_By` int(11) DEFAULT NULL COMMENT 'Кто изменил (ID админа), NULL = сам пользователь',
  `Changed_At` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Log_ID`),
  KEY `User_ID` (`User_ID`),
  CONSTRAINT `password_change_logs_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_change_logs`
--

LOCK TABLES `password_change_logs` WRITE;
/*!40000 ALTER TABLE `password_change_logs` DISABLE KEYS */;
INSERT INTO `password_change_logs` VALUES
(1,3,1,'2026-10-12 11:21:34'),
(2,8,1,'2026-10-12 11:57:21');
/*!40000 ALTER TABLE `password_change_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `Role_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Role_Name` varchar(50) NOT NULL COMMENT 'Название роли',
  PRIMARY KEY (`Role_ID`),
  UNIQUE KEY `Role_Name_UNIQUE` (`Role_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles` (
  `User_ID` int(11) NOT NULL COMMENT 'Ссылка на таблицу users',
  `Last_Name` varchar(50) NOT NULL COMMENT 'Фамилия',
  `First_Name` varchar(50) NOT NULL COMMENT 'Имя',
  `Middle_Name` varchar(50) DEFAULT NULL COMMENT 'Отчество (может отсутствовать)',
  `Email` varchar(100) DEFAULT NULL COMMENT 'Электронная почта (доп. поле)',
  PRIMARY KEY (`User_ID`),
  CONSTRAINT `fk_user_profile` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID_U`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
INSERT INTO `user_profiles` VALUES
(1,'Иванов','Иван','Иванович','ivanov@example.com'),
(2,'Петров','Петр','Петрович','petrov@example.com'),
(3,'Сидоров','Сидор','Сидорович','sidorov@example.com'),
(4,'Смирнов','Алексей','Викторович','smirnov@example.com'),
(5,'Кузнецов','Дмитрий','Анатольевич','kuznetsov@example.com'),
(6,'Попова','Анна','Сергеевна','popova@example.com'),
(7,'Тестов','Тест','Тестович','test@example.com');
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `ID_U` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Нужно для создания',
  `Login` varchar(50) NOT NULL COMMENT 'Для авторизации',
  `Password` varchar(255) NOT NULL COMMENT 'Необходим для авторизации (хранит хэш)',
  `Phone_Number` varchar(20) NOT NULL COMMENT 'Хранит номер',
  `Created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Когда был создан',
  `Ban` enum('0','1') NOT NULL DEFAULT '0' COMMENT 'Заблокирован (0 - нет, 1 - да)',
  `Role` enum('System_Admin','Admin','User') NOT NULL DEFAULT 'User' COMMENT 'Роль пользователя',
  `Failed_Attempts` int(11) NOT NULL DEFAULT 0 COMMENT 'Количество неудачных попыток входа',
  `Last_Password_Change` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Дата последней смены пароля',
  `Last_Activity` datetime DEFAULT NULL COMMENT 'Последняя активность',
  `Kick_Flag` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = принудительный выход',
  PRIMARY KEY (`ID_U`),
  UNIQUE KEY `Login_UNIQUE` (`Login`),
  UNIQUE KEY `Phone_Number_UNIQUE` (`Phone_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'sys_admin_1','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','79000000001','2026-10-05 10:54:58','0','System_Admin',0,'2026-10-12 09:25:13','2026-11-09 10:07:32',0),
(2,'sys_admin_2','hash_password_2','79000000002','2026-10-05 10:54:58','0','System_Admin',0,'2026-10-07 09:13:55',NULL,0),
(3,'admin_1','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4','79000000003','2026-10-05 10:54:58','0','Admin',0,'2026-10-12 11:21:34',NULL,0),
(4,'admin_2','hash_password_4','79000000004','2026-10-05 10:54:58','0','Admin',0,'2026-10-07 09:13:55',NULL,0),
(5,'user_1','hash_password_5','79000000005','2026-10-05 10:54:58','0','User',0,'2026-10-07 09:13:55',NULL,0),
(6,'user_2','hash_password_6','79000000006','2026-10-05 10:54:58','0','User',0,'2026-10-07 09:13:55',NULL,0),
(7,'test_user','my_secure_hash_123','79991234567','2026-10-05 11:14:28','0','User',0,'2026-10-07 09:13:55',NULL,0),
(8,'sosovod','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4','79000000099','2026-10-08 10:12:31','0','User',0,'2026-10-12 11:57:21','2026-10-12 11:57:31',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`localhost`*/ /*!50003 TRIGGER `After_User_Registration`
AFTER INSERT ON `users`
FOR EACH ROW
BEGIN
    INSERT INTO notifications (User_ID, Message)
    VALUES (NEW.ID_U, 'Добро пожаловать в систему! Пожалуйста, не забудьте сменить пароль, если он был выдан администратором.');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`localhost`*/ /*!50003 TRIGGER `After_User_Role_Change`
AFTER UPDATE ON `users`
FOR EACH ROW
BEGIN
    -- Если старая роль не равна новой роли
    IF OLD.Role != NEW.Role THEN
        INSERT INTO audit_logs (User_ID, Old_Role, New_Role)
        VALUES (OLD.ID_U, OLD.Role, NEW.Role);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`admin`@`localhost`*/ /*!50003 TRIGGER `After_User_Ban_Change`
AFTER UPDATE ON `users`
FOR EACH ROW
BEGIN
    -- Проверяем, изменилось ли поле Ban
    IF OLD.Ban != NEW.Ban THEN
        -- 1. Записываем в лог аудита
        INSERT INTO ban_logs (User_ID, Old_Ban, New_Ban)
        VALUES (NEW.ID_U, OLD.Ban, NEW.Ban);
        
        -- 2. Если пользователя забанили (Ban стал '1'), отправляем уведомление
        IF NEW.Ban = '1' THEN
            INSERT INTO notifications (User_ID, Message)
            VALUES (NEW.ID_U, 'Ваш аккаунт был заблокирован. Пожалуйста, обратитесь к администратору.');
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-09 10:24:20
