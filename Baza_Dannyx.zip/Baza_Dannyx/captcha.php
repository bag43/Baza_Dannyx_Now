<?php
declare(strict_types=1);

$captcha_id = 'captcha_' . uniqid('', true);
$pieces = [1, 2, 3, 4];
shuffle($pieces);

$image_path = 'img/puzzle.svg';
$debug_msg = '';

if (!file_exists($image_path)) {
    $debug_msg = "<p style='color:red; font-size:12px;'>⚠️ Файл не найден по пути: <b>$image_path</b>. Проверьте путь!</p>";
}
?>

<div class="captcha-wrapper" id="<?= htmlspecialchars($captcha_id, ENT_QUOTES, 'UTF-8') ?>">
    <p class="captcha-hint">Соберите пазл: перетащите кусочки так, чтобы получилась целая картинка</p>
    
    <?= $debug_msg ?>

    <div class="captcha-container">
        <?php foreach ($pieces as $piece_id): ?>
            <div class="puzzle-piece piece-<?= $piece_id ?>" 
                 draggable="true" 
                 data-id="<?= $piece_id ?>"
                 style="background-image: url('<?= htmlspecialchars($image_path, ENT_QUOTES, 'UTF-8') ?>');">
            </div>
        <?php endforeach; ?>
    </div>
    
    <input type="hidden" name="captcha_order" class="captcha-order-input" value="">
</div>

<style>
    .captcha-wrapper { margin: 15px 0; padding: 15px; border: 1px dashed #ccc; border-radius: 5px; background: #fafafa; text-align: center; }
    .captcha-hint { font-size: 13px; color: #555; margin: 0 0 15px 0; }
    .captcha-container { display: flex; flex-wrap: wrap; width: 165px; margin: 0 auto; gap: 5px; }
    .puzzle-piece { width: 80px; height: 80px; background-color: #e0e0e0; background-size: 160px 160px; cursor: grab; border: 2px solid #333; border-radius: 3px; user-select: none; transition: transform 0.2s; box-sizing: border-box; }
    .puzzle-piece:active { cursor: grabbing; transform: scale(1.05); }
    .piece-1 { background-position: 0 0; }
    .piece-2 { background-position: -80px 0; }
    .piece-3 { background-position: 0 -80px; }
    .piece-4 { background-position: -80px -80px; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const wrappers = document.querySelectorAll('.captcha-wrapper');
    
    wrappers.forEach(wrapper => {
        const container = wrapper.querySelector('.captcha-container');
        const hiddenInput = wrapper.querySelector('.captcha-order-input');
        let draggedItem = null;

        function updateOrder() {
            const items = container.querySelectorAll('.puzzle-piece');
            let order = [];
            items.forEach(item => order.push(item.getAttribute('data-id')));
            hiddenInput.value = order.join(',');
        }

        container.addEventListener('dragstart', e => {
            if (e.target.classList.contains('puzzle-piece')) {
                draggedItem = e.target;
                setTimeout(() => e.target.style.opacity = '0.5', 0);
            }
        });

        container.addEventListener('dragend', e => {
            if (e.target.classList.contains('puzzle-piece')) {
                setTimeout(() => { e.target.style.opacity = '1'; draggedItem = null; }, 0);
                updateOrder();
            }
        });

        container.addEventListener('dragover', e => e.preventDefault());

        container.addEventListener('dragenter', e => {
            e.preventDefault();
            if (e.target.classList.contains('puzzle-piece') && e.target !== draggedItem) {
                const items = Array.from(container.querySelectorAll('.puzzle-piece'));
                const draggedIndex = items.indexOf(draggedItem);
                const targetIndex = items.indexOf(e.target);
                
                if (draggedIndex < targetIndex) {
                    e.target.after(draggedItem);
                } else {
                    e.target.before(draggedItem);
                }
            }
        });

        container.addEventListener('drop', e => {
            e.preventDefault();
            updateOrder();
        });
        
        updateOrder(); 
    });
});
</script>