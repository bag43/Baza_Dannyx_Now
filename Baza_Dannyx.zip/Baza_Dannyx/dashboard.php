<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$role = $_SESSION['user_role'] ?? 'User';
$userId = (int) $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT Last_Name, First_Name, Middle_Name FROM user_profiles WHERE User_ID = ?");
$stmt->execute([$userId]);
$profile = $stmt->fetch();

$displayName = $_SESSION['user_login'];
if ($profile && $profile['First_Name']) {
    $displayName = trim(($profile['Last_Name'] ?? '') . ' ' . ($profile['First_Name'] ?? ''));
}

$unreadStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE User_ID = ? AND Is_Read = 0 AND Deleted_By_User = 0");
$unreadStmt->execute([$userId]);
$unreadCount = (int) $unreadStmt->fetchColumn();

$notesStmt = $pdo->prepare("SELECT COUNT(*) FROM notes WHERE Id_user = ?");
$notesStmt->execute([$userId]);
$notesCount = (int) $notesStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; background: #f0f2f5; }
        .btn {
            padding: 12px 25px; color: white; text-decoration: none; border-radius: 6px;
            margin: 6px; display: inline-block; position: relative;
            font-weight: bold; font-size: 14px; transition: 0.2s;
            border: none; cursor: pointer;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.15); }
        .logout-btn { background: #dc3545; }
        .admin-btn { background: #fd7e14; }
        .sysadmin-btn { background: #6f42c1; }
        .monitor-btn { background: #17a2b8; }
        .testing-btn { background: #20c997; } /* Цвет кнопки тестирования */
        .messages-btn { background: #007bff; }
        .notes-btn { background: #28a745; }
        .download-btn { background: #6c757d; }
        .role-tag { display: inline-block; padding: 3px 10px; border-radius: 15px; background: #007bff; color: white; font-size: 14px; }
        .badge-count {
            position: absolute; top: -8px; right: -8px;
            background: #dc3545; color: white; border-radius: 50%;
            min-width: 22px; height: 22px; line-height: 22px;
            font-size: 12px; font-weight: bold; padding: 0 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <h1>Добро пожаловать, <?= htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') ?>!</h1>
    <p>Ваша роль: <span class="role-tag"><?= htmlspecialchars($role, ENT_QUOTES, 'UTF-8') ?></span></p>

    <div style="max-width: 800px; margin: 30px auto;">

        <a href="notes.php" class="btn notes-btn">
            📝 Мои заметки
            <?php if ($notesCount > 0): ?>
                <span class="badge-count"><?= $notesCount ?></span>
            <?php endif; ?>
        </a>

        <a href="api_notes.php?download=1&filename=all_notes" class="btn download-btn">
            ⬇️ Скачать все заметки (JSON)
        </a>

        <a href="messages.php" class="btn messages-btn">
            ✉️ Мои сообщения
            <?php if ($unreadCount > 0): ?>
                <span class="badge-count"><?= $unreadCount ?></span>
            <?php endif; ?>
        </a>

        <?php if (in_array($role, ['Admin', 'System_Admin'], true)): ?>
            <a href="admin_messages.php" class="btn admin-btn">📤 Отправить сообщение</a>
            <a href="admin.php" class="btn admin-btn">⚙️ Панель администратора</a>
        <?php endif; ?>

        <?php if ($role === 'System_Admin'): ?>
            <a href="admin_stats.php" class="btn monitor-btn">📡 Мониторинг</a>
            <!-- ДОБАВЛЕНА КНОПКА ТЕСТИРОВАНИЯ -->
            <a href="admin_testing.php" class="btn testing-btn">🧪 Тестирование и отладка</a>
            <a href="db_tools.php" class="btn sysadmin-btn">🛠️ Управление таблицами БД</a>
        <?php endif; ?>

        <br><br>
        <a href="logout.php" class="btn logout-btn">Выйти</a>
    </div>

    <script>
    setInterval(() => {
        fetch('heartbeat.php')
            .then(r => r.json())
            .then(data => {
                if (!data.active && data.reason === 'kicked') {
                    alert('Администратор завершил вашу сессию.');
                    window.location.href = 'logout.php';
                }
            })
            .catch(() => {});
    }, 15000);
    </script>
</body>
</html>