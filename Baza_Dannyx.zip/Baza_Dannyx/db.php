<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost';
$db   = 'Project_Yfkin';
$user = 'project_user';
$pass = 'SuperPassword123!';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Ошибка подключения к БД: " . $e->getMessage());
}

$currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');
$skipCheck = in_array($currentScript, ['process.php'], true);

if (!$skipCheck && isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT Kick_Flag FROM users WHERE ID_U = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $kick = $stmt->fetchColumn();

        if ($kick === 1) {
            $uid = $_SESSION['user_id'];

            $pdo->prepare("UPDATE users SET Kick_Flag = 0, Last_Activity = NULL WHERE ID_U = ?")
                ->execute([$uid]);
            $pdo->prepare("DELETE FROM active_sessions WHERE User_ID = ?")
                ->execute([$uid]);

            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            session_destroy();

            if ($currentScript === 'heartbeat.php') {
                header('Content-Type: application/json');
                echo json_encode([
                    'active'  => false,
                    'reason'  => 'kicked',
                    'message' => 'Администратор завершил вашу сессию.'
                ]);
                exit;
            }

            header('Location: index.php?kicked=1');
            exit;
        }
    } catch (\PDOException $e) {
        // Игнорируем
    }
}