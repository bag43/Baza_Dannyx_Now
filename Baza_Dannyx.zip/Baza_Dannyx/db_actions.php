 <?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

function sanitizeIdent(string $name): string
{
    return preg_replace('/[^a-zA-Z0-9_]/', '', $name);
}

function setFlash(string $msg, bool $isError = false): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'error' => $isError];
}

$protected = ['users', 'roles', 'user_profiles', 'notifications', 'audit_logs', 'ban_logs'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create':
            $tableName = sanitizeIdent($_POST['table_name'] ?? '');
            if (!$tableName) {
                throw new \Exception('Неверное имя таблицы');
            }
            
            $uids = $_POST['col_uid'] ?? [];
            $pkUid = $_POST['col_pk'] ?? null;
            
            if (empty($uids)) {
                throw new \Exception('Добавьте хотя бы один столбец');
            }
            
            $allowedTypes = ['INT', 'BIGINT', 'TINYINT', 'VARCHAR', 'TEXT', 'DATETIME', 'DATE', 'TIME', 'DECIMAL', 'FLOAT', 'DOUBLE', 'BOOLEAN', 'ENUM'];
            
            $cols = [];
            $pkName = null;
            
            foreach ($uids as $uid) {
                $name = sanitizeIdent($_POST['col_name'][$uid] ?? '');
                if (!$name) {
                    continue;
                }
                
                $type = strtoupper($_POST['col_type'][$uid] ?? 'VARCHAR');
                if (!in_array($type, $allowedTypes, true)) {
                    $type = 'VARCHAR';
                }
                
                $length = trim($_POST['col_length'][$uid] ?? '');
                $typeSql = $type;
                
                if ($length !== '') {
                    if ($type === 'ENUM') {
                        $length = preg_replace("/[^a-zA-Z0-9а-яА-Я_,' ]/u", '', $length);
                        $typeSql = "ENUM($length)";
                    } elseif (preg_match('/^[0-9,]+$/', $length)) {
                        $typeSql = "$type($length)";
                    }
                }
                
                $nullable = isset($_POST['col_nullable'][$uid]) ? 'NULL' : 'NOT NULL';
                
                $default = trim($_POST['col_default'][$uid] ?? '');
                $defaultSql = '';
                if ($default !== '') {
                    $upper = strtoupper($default);
                    if (in_array($upper, ['CURRENT_TIMESTAMP', 'NOW()', 'NULL'], true)) {
                        $defaultSql = "DEFAULT $default";
                    } elseif (is_numeric($default)) {
                        $defaultSql = "DEFAULT $default";
                    } else {
                        $defaultSql = "DEFAULT " . $pdo->quote($default);
                    }
                }
                
                $ai = (isset($_POST['col_ai'][$uid]) && $type === 'INT') ? 'AUTO_INCREMENT' : '';
                
                $isPk = ($uid == $pkUid);
                if ($isPk) {
                    $pkName = $name;
                }
                
                $cols[] = "`$name` $typeSql $nullable $defaultSql $ai";
            }
            
            if (empty($cols)) {
                throw new \Exception('Не удалось собрать столбцы');
            }
            
            $pkSql = $pkName ? ", PRIMARY KEY (`$pkName`)" : '';
            
            $sql = "CREATE TABLE `$tableName` (" . implode(', ', $cols) . "$pkSql) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            setFlash("✅ Таблица `$tableName` успешно создана!");
            break;
        
        case 'drop':
            $tableName = sanitizeIdent($_GET['table'] ?? '');
            if (!$tableName) {
                throw new \Exception('Неверное имя таблицы');
            }
            if (in_array($tableName, $protected, true)) {
                throw new \Exception('Эту таблицу удалять запрещено!');
            }
            
            $pdo->exec("DROP TABLE `$tableName`");
            setFlash("🗑 Таблица `$tableName` удалена.");
            break;
        
        default:
            throw new \Exception('Неизвестное действие');
    }
} catch (\Exception $e) {
    setFlash('❌ Ошибка: ' . $e->getMessage(), true);
}

header('Location: db_tools.php');
exit;