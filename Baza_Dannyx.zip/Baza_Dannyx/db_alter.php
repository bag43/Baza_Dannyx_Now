<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

function sanitizeIdent(string $name): string
{
    return preg_replace('/[^a-zA-Z0-9_]/', '', $name);
}

function setFlash(string $msg, bool $isError = false): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'error' => $isError];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$tableName = sanitizeIdent($_POST['table'] ?? $_GET['table'] ?? '');

if (!$tableName) {
    setFlash('Не указана таблица', true);
    header('Location: db_tools.php');
    exit;
}

$protected = ['users', 'roles', 'user_profiles', 'notifications', 'audit_logs', 'ban_logs'];

try {
    switch ($action) {
        case 'add_column':
            $colName = sanitizeIdent($_POST['col_name'] ?? '');
            if (!$colName) {
                throw new \Exception('Неверное имя столбца');
            }
            
            $type = strtoupper($_POST['col_type'] ?? 'VARCHAR');
            $allowed = ['INT', 'BIGINT', 'TINYINT', 'VARCHAR', 'TEXT', 'DATETIME', 'DATE', 'TIME', 'DECIMAL', 'FLOAT', 'DOUBLE', 'BOOLEAN', 'ENUM'];
            if (!in_array($type, $allowed, true)) {
                $type = 'VARCHAR';
            }
            
            $length = trim($_POST['col_length'] ?? '');
            $typeSql = $type;
            if ($length !== '') {
                if ($type === 'ENUM') {
                    $length = preg_replace("/[^a-zA-Z0-9а-яА-Я_,' ]/u", '', $length);
                    $typeSql = "ENUM($length)";
                } elseif (preg_match('/^[0-9,]+$/', $length)) {
                    $typeSql = "$type($length)";
                }
            }
            
            $default = trim($_POST['col_default'] ?? '');
            $defaultSql = '';
            if ($default !== '') {
                $upper = strtoupper($default);
                if (in_array($upper, ['CURRENT_TIMESTAMP', 'NOW()', 'NULL'], true) || is_numeric($default)) {
                    $defaultSql = "DEFAULT $default";
                } else {
                    $defaultSql = "DEFAULT " . $pdo->quote($default);
                }
            }
            
            $sql = "ALTER TABLE `$tableName` ADD COLUMN `$colName` $typeSql NULL $defaultSql";
            $pdo->exec($sql);
            setFlash("✅ Столбец `$colName` добавлен в таблицу `$tableName`.");
            break;
        
        case 'drop_column':
            $colName = sanitizeIdent($_GET['column'] ?? '');
            if (!$colName) {
                throw new \Exception('Неверное имя столбца');
            }
            
            $sql = "ALTER TABLE `$tableName` DROP COLUMN `$colName`";
            $pdo->exec($sql);
            setFlash("🗑 Столбец `$colName` удалён.");
            break;
        
        case 'rename_table':
            if (in_array($tableName, $protected, true)) {
                throw new \Exception('Эту таблицу переименовывать нельзя!');
            }
            
            $newName = sanitizeIdent($_POST['new_name'] ?? '');
            if (!$newName) {
                throw new \Exception('Неверное новое имя');
            }
            
            $sql = "RENAME TABLE `$tableName` TO `$newName`";
            $pdo->exec($sql);
            setFlash("✅ Таблица переименована в `$newName`.");
            header('Location: db_tools.php');
            exit;
        
        default:
            throw new \Exception('Неизвестное действие');
    }
} catch (\Exception $e) {
    setFlash('❌ Ошибка: ' . $e->getMessage(), true);
}

header('Location: db_edit.php?table=' . urlencode($tableName));
exit;