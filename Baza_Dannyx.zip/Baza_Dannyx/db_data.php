 <?php

declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();

$pkColumn = null;
foreach ($columns as $c) {
    if ($c['Key'] === 'PRI') {
        $pkColumn = $c['Field'];
        break;
    }
}

$rows = $pdo->query("SELECT * FROM `$tableName` LIMIT 500")->fetchAll();
$total = $pdo->query("SELECT COUNT(*) FROM `$tableName`")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Данные таблицы: <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 100%; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px; }
        .btn-add { background: #28a745; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-weight: bold; font-size: 14px; }
        .btn-add:hover { background: #218838; }
        .info { background: #e7f3ff; padding: 12px 18px; border-radius: 6px; margin-bottom: 15px; color: #004085; border-left: 5px solid #007bff; }
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow-x: auto; }
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 8px 12px; border-bottom: 1px solid #eee; text-align: left; white-space: nowrap; }
        table.data th { background: #343a40; color: white; font-weight: normal; position: sticky; top: 0; }
        table.data tr:hover { background: #f8f9fa; }
        table.data td.null { color: #aaa; font-style: italic; }
        table.data td.pk { font-weight: bold; color: #007bff; }
        .btn-edit-sm, .btn-del-sm { padding: 4px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; color: white; display: inline-block; }
        .btn-edit-sm { background: #007bff; margin-right: 4px; }
        .btn-del-sm { background: #dc3545; }
        .btn-edit-sm:hover { background: #0056b3; }
        .btn-del-sm:hover { background: #c82333; }
    </style>
</head>
<body>
    <div class="container">
        <a href="db_tools.php" class="back">← К списку таблиц</a>
        <h1>📊 Данные таблицы: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code></h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="top-bar">
            <div class="info" style="margin:0; flex:1;">
                Всего записей: <b><?= $total ?></b>. Показано первых <b><?= count($rows) ?></b>.
                <?php if (!$pkColumn): ?>
                    <br>⚠️ <b>Внимание:</b> у таблицы нет PRIMARY KEY, редактирование может быть неточным.
                <?php endif; ?>
            </div>
            <a href="db_row_edit.php?table=<?= urlencode($tableName) ?>" class="btn-add">➕ Добавить строку</a>
        </div>
        
        <div class="card">
            <?php if (empty($rows)): ?>
                <p style="text-align:center; color:#999;">Таблица пуста. Нажмите «Добавить строку», чтобы создать первую запись.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $c): ?>
                                <th><?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?></th>
                            <?php endforeach; ?>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($columns as $c): 
                                    $val = $row[$c['Field']] ?? null;
                                    $isPk = ($c['Field'] === $pkColumn);
                                ?>
                                    <td class="<?= $val === null ? 'null' : '' ?> <?= $isPk ? 'pk' : '' ?>">
                                        <?= $val === null ? 'NULL' : htmlspecialchars(mb_substr((string) $val, 0, 100), ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                <?php endforeach; ?>
                                <td>
                                    <?php if ($pkColumn): ?>
                                        <a href="db_row_edit.php?table=<?= urlencode($tableName) ?>&id=<?= urlencode((string) $row[$pkColumn]) ?>" 
                                           class="btn-edit-sm">✏️ Изменить</a>
                                        <a href="db_row_actions.php?action=delete&table=<?= urlencode($tableName) ?>&id=<?= urlencode((string) $row[$pkColumn]) ?>" 
                                           class="btn-del-sm"
                                           onclick="return confirm('Удалить эту строку?')">🗑 Удалить</a>
                                    <?php else: ?>
                                        <span style="color:#aaa; font-size:11px;">нет PK</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>