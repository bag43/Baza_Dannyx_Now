<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name = ?
");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$protected = ['users', 'roles', 'user_profiles', 'notifications', 'audit_logs', 'ban_logs'];
$isProtected = in_array($tableName, $protected, true);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование таблицы: <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1000px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .card { background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card h2 { margin-top: 0; font-size: 18px; color: #333; }
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        table.cols { width: 100%; border-collapse: collapse; }
        table.cols th, table.cols td { padding: 10px 12px; border-bottom: 1px solid #eee; text-align: left; font-size: 14px; }
        table.cols th { background: #343a40; color: white; font-weight: normal; }
        .btn-drop { background: #dc3545; color: white; border: none; padding: 5px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; text-decoration: none; }
        .btn-drop:hover { background: #c82333; }
        form.alter-form { display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr auto; gap: 10px; align-items: end; }
        form.alter-form label { font-size: 12px; color: #555; display: block; margin-bottom: 4px; font-weight: bold; }
        form.alter-form input, form.alter-form select { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 13px; }
        .btn-primary { background: #007bff; color: white; border: none; padding: 9px 20px; border-radius: 4px; cursor: pointer; font-size: 13px; font-weight: bold; }
        .btn-primary:hover { background: #0056b3; }
        .btn-warn { background: #fd7e14; color: white; border: none; padding: 9px 20px; border-radius: 4px; cursor: pointer; font-size: 13px; font-weight: bold; }
        .btn-warn:hover { background: #e86e10; }
        .rename-form { display: flex; gap: 10px; }
        .rename-form input { flex: 1; padding: 9px; border: 1px solid #ccc; border-radius: 4px; }
        .hint { font-size: 12px; color: #666; background: #fff3cd; padding: 8px 12px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <div class="container">
        <a href="db_tools.php" class="back">← К списку таблиц</a>
        <h1>✏️ Таблица: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code>
            <?= $isProtected ? ' 🔒' : '' ?>
        </h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>">
                <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📋 Существующие столбцы</h2>
            <table class="cols">
                <thead>
                    <tr>
                        <th>Столбец</th>
                        <th>Тип</th>
                        <th>NULL</th>
                        <th>Ключ</th>
                        <th>По умолчанию</th>
                        <th>Extra</th>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($columns as $c): ?>
                    <tr>
                        <td><b><?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?></b></td>
                        <td><?= htmlspecialchars($c['Type'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= $c['Null'] === 'YES' ? '✓' : '—' ?></td>
                        <td><?= htmlspecialchars($c['Key'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) ($c['Default'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($c['Extra'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <?php if (count($columns) > 1 && $c['Key'] !== 'PRI'): ?>
                                <a href="db_alter.php?action=drop_column&table=<?= urlencode($tableName) ?>&column=<?= urlencode($c['Field']) ?>"
                                   class="btn-drop"
                                   onclick="return confirm('Удалить столбец «<?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?>»? Данные будут потеряны!')">
                                   Удалить
                                </a>
                            <?php else: ?>
                                <span style="color:#aaa; font-size:12px;">защищён</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <h2>➕ Добавить новый столбец</h2>
            <div class="hint">
                💡 <b>Длина:</b> VARCHAR — <code>100</code>; DECIMAL — <code>10,2</code>; ENUM — <code>'да','нет'</code>.
            </div>
            <form method="POST" action="db_alter.php" class="alter-form">
                <input type="hidden" name="action" value="add_column">
                <input type="hidden" name="table" value="<?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?>">
                
                <div>
                    <label>Имя</label>
                    <input type="text" name="col_name" required pattern="[a-zA-Z0-9_]+" placeholder="column_name">
                </div>
                <div>
                    <label>Тип</label>
                    <select name="col_type">
                        <option value="INT">INT</option>
                        <option value="VARCHAR" selected>VARCHAR</option>
                        <option value="TEXT">TEXT</option>
                        <option value="DATETIME">DATETIME</option>
                        <option value="DATE">DATE</option>
                        <option value="DECIMAL">DECIMAL</option>
                        <option value="TINYINT">TINYINT</option>
                        <option value="ENUM">ENUM</option>
                    </select>
                </div>
                <div>
                    <label>Длина</label>
                    <input type="text" name="col_length" placeholder="255">
                </div>
                <div>
                    <label>По умолчанию</label>
                    <input type="text" name="col_default" placeholder="">
                </div>
                <button type="submit" class="btn-primary">Добавить</button>
            </form>
        </div>
        
        <?php if (!$isProtected): ?>
        <div class="card">
            <h2>🔄 Переименовать таблицу</h2>
            <form method="POST" action="db_alter.php" class="rename-form">
                <input type="hidden" name="action" value="rename_table">
                <input type="hidden" name="table" value="<?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?>">
                <input type="text" name="new_name" required pattern="[a-zA-Z0-9_]+" 
                       placeholder="новое_имя_таблицы" value="<?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" class="btn-warn" onclick="return confirm('Переименовать таблицу?')">Переименовать</button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>