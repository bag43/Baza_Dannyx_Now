<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

function setFlash(string $msg, bool $isError = false): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'error' => $isError];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['table'] ?? $_GET['table'] ?? '');

if (!$tableName) {
    setFlash('Не указана таблица', true);
    header('Location: db_tools.php');
    exit;
}

$check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    setFlash('Таблица не найдена', true);
    header('Location: db_tools.php');
    exit;
}

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();
$columnNames = array_column($columns, 'Field');

try {
    switch ($action) {
        case 'delete':
            $pkColumn = null;
            foreach ($columns as $c) {
                if ($c['Key'] === 'PRI') {
                    $pkColumn = $c['Field'];
                    break;
                }
            }
            if (!$pkColumn) {
                throw new \Exception('У таблицы нет PRIMARY KEY');
            }
            
            $id = $_GET['id'] ?? null;
            if ($id === null) {
                throw new \Exception('Не указан ID');
            }
            
            $stmt = $pdo->prepare("DELETE FROM `$tableName` WHERE `$pkColumn` = ? LIMIT 1");
            $stmt->execute([$id]);
            
            setFlash('🗑 Строка удалена.');
            header('Location: db_data.php?table=' . urlencode($tableName));
            exit;
        
        case 'insert':
            $fields = [];
            $placeholders = [];
            $values = [];
            
            foreach ($columns as $c) {
                $name = $c['Field'];
                if (str_contains($c['Extra'], 'auto_increment')) {
                    continue;
                }
                if (!isset($_POST[$name])) {
                    continue;
                }
                
                $val = $_POST[$name];
                if ($val === '' && $c['Null'] === 'YES') {
                    $val = null;
                }
                if ($val === '' && $c['Default'] !== null) {
                    continue;
                }
                
                $fields[] = "`$name`";
                $placeholders[] = "?";
                $values[] = $val;
            }
            
            if (empty($fields)) {
                throw new \Exception('Нет данных для вставки');
            }
            
            $sql = "INSERT INTO `$tableName` (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            
            setFlash('✅ Строка успешно добавлена.');
            header('Location: db_data.php?table=' . urlencode($tableName));
            exit;
        
        case 'update':
            $pkColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['pk_column'] ?? '');
            $pkValue = $_POST['pk_value'] ?? null;
            
            if (!$pkColumn || $pkValue === null) {
                throw new \Exception('Не указан PRIMARY KEY');
            }
            if (!in_array($pkColumn, $columnNames, true)) {
                throw new \Exception('Неверный PRIMARY KEY');
            }
            
            $setParts = [];
            $values = [];
            
            foreach ($columns as $c) {
                $name = $c['Field'];
                if ($name === $pkColumn) {
                    continue;
                }
                if (!isset($_POST[$name])) {
                    continue;
                }
                
                $val = $_POST[$name];
                if ($val === '' && $c['Null'] === 'YES') {
                    $val = null;
                }
                
                $setParts[] = "`$name` = ?";
                $values[] = $val;
            }
            
            if (empty($setParts)) {
                throw new \Exception('Нет полей для обновления');
            }
            
            $values[] = $pkValue;
            $sql = "UPDATE `$tableName` SET " . implode(', ', $setParts) . " WHERE `$pkColumn` = ? LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            
            setFlash('✅ Изменения сохранены.');
            header('Location: db_data.php?table=' . urlencode($tableName));
            exit;
        
        default:
            throw new \Exception('Неизвестное действие');
    }
} catch (\Exception $e) {
    setFlash('❌ Ошибка: ' . $e->getMessage(), true);
    
    if ($action === 'update' || $action === 'insert') {
        $id = $_POST['pk_value'] ?? '';
        $url = 'db_row_edit.php?table=' . urlencode($tableName);
        if ($id !== '') {
            $url .= '&id=' . urlencode((string) $id);
        }
        header('Location: ' . $url);
    } else {
        header('Location: db_data.php?table=' . urlencode($tableName));
    }
    exit;
}