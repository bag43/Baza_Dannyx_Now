 <?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();

$pkColumn = null;
foreach ($columns as $c) {
    if ($c['Key'] === 'PRI') {
        $pkColumn = $c['Field'];
        break;
    }
}

$rowId = $_GET['id'] ?? null;
$isEdit = ($rowId !== null && $rowId !== '');
$row = [];

if ($isEdit) {
    if (!$pkColumn) {
        die('У таблицы нет PRIMARY KEY, редактирование невозможно');
    }
    $stmt = $pdo->prepare("SELECT * FROM `$tableName` WHERE `$pkColumn` = ? LIMIT 1");
    $stmt->execute([$rowId]);
    $row = $stmt->fetch();
    if (!$row) {
        die('Строка не найдена');
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

function fieldInput(array $col, mixed $value, bool $isPk, bool $isEdit): string
{
    $name = htmlspecialchars($col['Field'], ENT_QUOTES, 'UTF-8');
    $type = strtolower($col['Type']);
    $val = htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    $required = ($col['Null'] === 'NO' && $col['Default'] === null && !$isPk) ? 'required' : '';
    $readonly = ($isPk && $isEdit) ? 'readonly' : '';
    $extra = ($isPk && $isEdit) ? 'background:#eee;' : '';
    
    if (preg_match("/^enum\((.*)\)$/i", $type, $m)) {
        $options = str_getcsv($m[1], ',', "'");
        $html = "<select name=\"$name\" style=\"width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;\" $required>";
        foreach ($options as $opt) {
            $opt = trim($opt);
            $sel = ($opt === (string) $value) ? 'selected' : '';
            $html .= "<option value=\"" . htmlspecialchars($opt, ENT_QUOTES, 'UTF-8') . "\" $sel>" . htmlspecialchars($opt, ENT_QUOTES, 'UTF-8') . "</option>";
        }
        $html .= "</select>";
        return $html;
    }
    
    if (str_contains($type, 'text')) {
        return "<textarea name=\"$name\" rows=\"4\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>$val</textarea>";
    }
    
    if (preg_match('/^(int|tinyint|smallint|mediumint|bigint|decimal|float|double)/', $type)) {
        $step = (str_contains($type, 'decimal') || str_contains($type, 'float') || str_contains($type, 'double')) ? '0.01' : '1';
        return "<input type=\"number\" step=\"$step\" name=\"$name\" value=\"$val\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px; $extra\" $required $readonly>";
    }
    
    if (str_contains($type, 'datetime') || str_contains($type, 'timestamp')) {
        $dt = $value ? date('Y-m-d\TH:i', strtotime((string) $value)) : '';
        return "<input type=\"datetime-local\" name=\"$name\" value=\"$dt\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>";
    }
    if (str_contains($type, 'date')) {
        $dt = $value ? date('Y-m-d', strtotime((string) $value)) : '';
        return "<input type=\"date\" name=\"$name\" value=\"$dt\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>";
    }
    
    return "<input type=\"text\" name=\"$name\" value=\"$val\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px; $extra\" $required $readonly>";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Редактирование' : 'Добавление' ?> строки в <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 700px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 14px; color: #333; }
        .form-group label .type-hint { color: #888; font-weight: normal; font-size: 12px; margin-left: 8px; }
        .form-group label .pk-badge { background: #007bff; color: white; font-size: 10px; padding: 2px 6px; border-radius: 3px; margin-left: 8px; }
        .form-group label .null-badge { background: #6c757d; color: white; font-size: 10px; padding: 2px 6px; border-radius: 3px; margin-left: 4px; }
        .submit-btn { width: 100%; padding: 14px; background: #28a745; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 10px; }
        .submit-btn:hover { background: #218838; }
        .cancel-btn { display: block; text-align: center; margin-top: 10px; color: #666; text-decoration: none; font-size: 14px; }
        .cancel-btn:hover { color: #000; }
    </style>
</head>
<body>
    <div class="container">
        <a href="db_data.php?table=<?= urlencode($tableName) ?>" class="back">← К данным таблицы</a>
        <h1><?= $isEdit ? '✏️ Редактирование строки' : '➕ Новая строка' ?>: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code></h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <form method="POST" action="db_row_actions.php">
                <input type="hidden" name="action" value="<?= $isEdit ? 'update' : 'insert' ?>">
                <input type="hidden" name="table" value="<?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="pk_column" value="<?= htmlspecialchars((string) $pkColumn, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="pk_value" value="<?= htmlspecialchars((string) $rowId, ENT_QUOTES, 'UTF-8') ?>">
                <?php endif; ?>
                
                <?php foreach ($columns as $c): 
                    $isPk = ($c['Field'] === $pkColumn);
                    if (!$isEdit && str_contains($c['Extra'], 'auto_increment')) {
                        continue;
                    }
                ?>
                    <div class="form-group">
                        <label>
                            <?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?>
                            <span class="type-hint">(<?= htmlspecialchars($c['Type'], ENT_QUOTES, 'UTF-8') ?>)</span>
                            <?php if ($isPk): ?><span class="pk-badge">PK</span><?php endif; ?>
                            <?php if ($c['Null'] === 'YES'): ?><span class="null-badge">NULL</span><?php endif; ?>
                        </label>
                        <?= fieldInput($c, $row[$c['Field']] ?? null, $isPk, $isEdit) ?>
                    </div>
                <?php endforeach; ?>
                
                <button type="submit" class="submit-btn"><?= $isEdit ? '💾 Сохранить изменения' : '➕ Добавить строку' ?></button>
                <a href="db_data.php?table=<?= urlencode($tableName) ?>" class="cancel-btn">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>