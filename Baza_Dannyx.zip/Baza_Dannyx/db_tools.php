<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$protected = ['users', 'roles', 'user_profiles', 'notifications', 'audit_logs', 'ban_logs'];

$tables = $pdo->query("
    SELECT table_name 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE()
    ORDER BY table_name
")->fetchAll(PDO::FETCH_COLUMN);

$tablesInfo = [];
foreach ($tables as $t) {
    $colStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM information_schema.columns 
        WHERE table_schema = DATABASE() 
        AND table_name = ?
    ");
    $colStmt->execute([$t]);
    $colCount = (int) $colStmt->fetchColumn();
    
    $rowCount = (int) $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
    
    $tablesInfo[] = ['name' => $t, 'cols' => $colCount, 'rows' => $rowCount];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление таблицами БД</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .back:hover { text-decoration: underline; }
        .btn-create { background: #28a745; color: white; border: none; padding: 12px 25px; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold; margin-bottom: 20px; }
        .btn-create:hover { background: #218838; }
        table.tables { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.08); border-radius: 8px; overflow: hidden; }
        table.tables th, table.tables td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        table.tables th { background: #343a40; color: white; font-weight: normal; }
        table.tables tr:hover { background: #f8f9fa; }
        .btn-view, .btn-edit, .btn-del { padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 13px; color: white; display: inline-block; margin-right: 5px; }
        .btn-view { background: #17a2b8; }
        .btn-edit { background: #007bff; }
        .btn-del { background: #dc3545; }
        .btn-view:hover { background: #138496; }
        .btn-edit:hover { background: #0056b3; }
        .btn-del:hover { background: #c82333; }
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: flex-start; overflow-y: auto; z-index: 1000; padding: 40px 20px; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: white; padding: 30px; border-radius: 10px; width: 100%; max-width: 850px; position: relative; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        .close-btn { position: absolute; top: 15px; right: 20px; font-size: 28px; cursor: pointer; color: #999; line-height: 1; }
        .close-btn:hover { color: #000; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: bold; }
        .form-group input[type="text"] { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        .column-row { display: grid; grid-template-columns: 1.5fr 1fr 0.8fr 60px 1fr 40px 40px 40px; gap: 8px; padding: 8px; background: #f8f9fa; border-radius: 6px; margin-bottom: 8px; align-items: center; }
        .column-row input[type="text"], .column-row select { padding: 6px 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; box-sizing: border-box; width: 100%; }
        .column-row label { display: flex; align-items: center; gap: 3px; font-size: 12px; }
        .column-row .btn-remove { background: #dc3545; color: white; border: none; width: 28px; height: 28px; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .btn-add-col { background: #17a2b8; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 13px; margin-top: 5px; }
        .btn-add-col:hover { background: #138496; }
        .submit-btn { width: 100%; padding: 14px; background: #28a745; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 15px; }
        .submit-btn:hover { background: #218838; }
        .hint { font-size: 12px; color: #666; background: #fff3cd; padding: 8px 12px; border-radius: 4px; margin-bottom: 15px; border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin.php" class="back">← Назад в панель администратора</a>
        <h1>🛠️ Управление таблицами БД</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>">
                <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>
        
        <button class="btn-create" onclick="openCreateModal()">➕ Создать новую таблицу</button>
        
        <table class="tables">
            <thead>
                <tr>
                    <th>Имя таблицы</th>
                    <th>Столбцов</th>
                    <th>Строк</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tablesInfo as $t): 
                    $isProtected = in_array($t['name'], $protected, true);
                ?>
                <tr>
                    <td>
                        <b><?= htmlspecialchars($t['name'], ENT_QUOTES, 'UTF-8') ?></b>
                        <?= $isProtected ? ' 🔒' : '' ?>
                    </td>
                    <td><?= $t['cols'] ?></td>
                    <td><?= $t['rows'] ?></td>
                    <td>
                        <a href="db_data.php?table=<?= urlencode($t['name']) ?>" class="btn-view" style="background:#28a745;">📊 Данные</a>
                        <a href="db_edit.php?table=<?= urlencode($t['name']) ?>" class="btn-edit">✏️ Структура</a>
                        <?php if (!$isProtected): ?>
                            <a href="db_actions.php?action=drop&table=<?= urlencode($t['name']) ?>" 
                               class="btn-del" 
                               onclick="return confirm('Удалить таблицу «<?= htmlspecialchars($t['name'], ENT_QUOTES, 'UTF-8') ?>»? Это действие необратимо!')">🗑 Удалить</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <div id="createModal" class="modal-overlay">
        <div class="modal-content">
            <span class="close-btn" onclick="closeCreateModal()">&times;</span>
            <h2 style="margin-top:0;">➕ Создать новую таблицу</h2>
            
            <form method="POST" action="db_actions.php">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label>Имя таблицы:</label>
                    <input type="text" name="table_name" required pattern="[a-zA-Z0-9_]+" placeholder="например: products (только латиница, цифры, _)">
                </div>
                
                <div class="form-group">
                    <label>Столбцы таблицы:</label>
                    <div class="hint">
                        💡 <b>Длина/значения:</b> для VARCHAR — число (например <code>100</code>); 
                        для DECIMAL — <code>10,2</code>; для ENUM — <code>'да','нет','может быть'</code>.
                    </div>
                    <div id="columnsContainer"></div>
                    <button type="button" class="btn-add-col" onclick="addColumn()">➕ Добавить столбец</button>
                </div>
                
                <button type="submit" class="submit-btn">Создать таблицу</button>
            </form>
        </div>
    </div>
    
    <script>
        let colUid = 0;
        
        function openCreateModal() {
            document.getElementById('createModal').classList.add('active');
            document.getElementById('columnsContainer').innerHTML = '';
            colUid = 0;
            addColumn();
        }
        
        function closeCreateModal() {
            document.getElementById('createModal').classList.remove('active');
        }
        
        function addColumn() {
            const uid = colUid++;
            const container = document.getElementById('columnsContainer');
            const html = `
                <div class="column-row">
                    <input type="hidden" name="col_uid[]" value="${uid}">
                    <input type="text" name="col_name[${uid}]" placeholder="Имя столбца" required>
                    <select name="col_type[${uid}]">
                        <option value="INT">INT</option>
                        <option value="VARCHAR" selected>VARCHAR</option>
                        <option value="TEXT">TEXT</option>
                        <option value="DATETIME">DATETIME</option>
                        <option value="DATE">DATE</option>
                        <option value="DECIMAL">DECIMAL</option>
                        <option value="TINYINT">TINYINT</option>
                        <option value="ENUM">ENUM</option>
                    </select>
                    <input type="text" name="col_length[${uid}]" placeholder="Длина">
                    <label title="Может быть NULL">
                        <input type="checkbox" name="col_nullable[${uid}]" value="1"> NULL
                    </label>
                    <input type="text" name="col_default[${uid}]" placeholder="По умолч.">
                    <label title="Auto Increment">
                        <input type="checkbox" name="col_ai[${uid}]" value="1"> AI
                    </label>
                    <label title="Primary Key">
                        <input type="radio" name="col_pk" value="${uid}"> PK
                    </label>
                    <button type="button" class="btn-remove" onclick="this.parentNode.remove()">✖</button>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
        }
        
        document.getElementById('createModal').addEventListener('click', function(e) {
            if (e.target === this) closeCreateModal();
        });
    </script>
</body>
</html>