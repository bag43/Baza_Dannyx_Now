<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name = ?
");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();
$rows = $pdo->query("SELECT * FROM `$tableName` LIMIT 100")->fetchAll();
$total = $pdo->query("SELECT COUNT(*) FROM `$tableName`")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Просмотр: <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 100%; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow-x: auto; }
        table.data { width: 100%; border-collapse: collapse; font-size: 13px; }
        table.data th, table.data td { padding: 8px 12px; border-bottom: 1px solid #eee; text-align: left; white-space: nowrap; }
        table.data th { background: #343a40; color: white; font-weight: normal; position: sticky; top: 0; }
        table.data tr:hover { background: #f8f9fa; }
        table.data td.null { color: #aaa; font-style: italic; }
        .info { background: #e7f3ff; padding: 12px 18px; border-radius: 6px; margin-bottom: 15px; color: #004085; border-left: 5px solid #007bff; }
    </style>
</head>
<body>
    <div class="container">
        <a href="db_tools.php" class="back">← К списку таблиц</a>
        <h1>👁 Просмотр: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code></h1>
        
        <div class="info">
            Всего записей: <b><?= $total ?></b>. Показано первых <b><?= count($rows) ?></b>.
        </div>
        
        <div class="card">
            <?php if (empty($rows)): ?>
                <p style="text-align:center; color:#999;">Таблица пуста.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $c): ?>
                                <th><?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($columns as $c): 
                                    $val = $row[$c['Field']] ?? null;
                                ?>
                                    <td class="<?= $val === null ? 'null' : '' ?>">
                                        <?= $val === null ? 'NULL' : htmlspecialchars(mb_substr((string) $val, 0, 100), ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>