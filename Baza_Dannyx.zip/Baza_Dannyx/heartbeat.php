<?php
declare(strict_types=1);

require 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['active' => false, 'reason' => 'not_logged_in']);
    exit;
}

try {
    $pdo->prepare("UPDATE active_sessions SET Last_Ping = NOW() WHERE Session_ID = ?")
        ->execute([session_id()]);
    $pdo->prepare("UPDATE users SET Last_Activity = NOW() WHERE ID_U = ?")
        ->execute([$_SESSION['user_id']]);

    echo json_encode(['active' => true]);
} catch (\PDOException $e) {
    echo json_encode(['active' => false, 'reason' => 'error']);
}