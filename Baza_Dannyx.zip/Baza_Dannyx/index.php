<?php
declare(strict_types=1);

require 'db.php';

if (isset($_SESSION['user_login'])) {
    header('Location: dashboard.php');
    exit;
}

$kicked = isset($_GET['kicked']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; flex-direction: column; }
        .main-btn { padding: 15px 40px; font-size: 18px; background: #007bff; color: white; border: none; border-radius: 8px; cursor: pointer; transition: 0.3s; }
        .main-btn:hover { background: #0056b3; }
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: white; padding: 30px; border-radius: 10px; width: 350px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); position: relative; }
        .close-btn { position: absolute; top: 10px; right: 15px; font-size: 24px; cursor: pointer; color: #aaa; }
        .close-btn:hover { color: #000; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .submit-btn { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        .submit-btn:hover { background: #218838; }
        .register-link { text-align: center; margin-top: 15px; font-size: 14px; }
        .register-link a { color: #007bff; text-decoration: none; font-weight: bold; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; font-size: 14px; display: none; }
        .message.error { background: #f8d7da; color: #721c24; display: block; }
        .message.success { background: #d4edda; color: #155724; display: block; }
        .kicked-notice { background: #fff3cd; color: #856404; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid #ffc107; font-weight: bold; }
    </style>
</head>
<body>
    <?php if ($kicked): ?>
        <div class="kicked-notice">
            ⚠️ Администратор завершил вашу сессию. Войдите заново.
        </div>
    <?php endif; ?>

    <button class="main-btn" onclick="openModal()">Войти в систему</button>

    <div class="modal-overlay" id="loginModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <h2 style="text-align:center; margin-top:0;">Вход</h2>
            <div id="loginMessage" class="message"></div>

            <form id="loginForm">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" name="login" required>
                </div>
                <div class="form-group">
                    <label>Пароль:</label>
                    <input type="password" name="password" required>
                </div>
                <?php include 'captcha.php'; ?>
                <button type="submit" class="submit-btn">Войти</button>
            </form>
            <div class="register-link">
                Нет аккаунта? <a href="register.php">Зарегистрироваться</a>
            </div>
        </div>
    </div>

    <script>
        function openModal() { document.getElementById('loginModal').classList.add('active'); }
        function closeModal() { document.getElementById('loginModal').classList.remove('active'); }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const msgDiv = document.getElementById('loginMessage');
            
            fetch('process.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    msgDiv.className = 'message ' + (data.success ? 'success' : 'error');
                    msgDiv.textContent = data.message;
                    if (data.success) {
                        setTimeout(() => { window.location.href = 'dashboard.php'; }, 1500);
                    }
                })
                .catch(() => {
                    msgDiv.className = 'message error';
                    msgDiv.textContent = 'Ошибка соединения с сервером.';
                });
        });
    </script>
</body>
</html>