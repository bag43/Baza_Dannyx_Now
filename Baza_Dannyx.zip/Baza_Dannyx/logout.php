<?php declare(strict_types=1);

// Подключаем базу данных, чтобы удалить сессию из таблицы
require 'db.php'; 

if (isset($_SESSION['session_id'])) {
    try {
        // Удаляем текущую сессию из active_sessions
        $pdo->prepare("DELETE FROM active_sessions WHERE Session_ID = ?")
            ->execute([$_SESSION['session_id']]);
            
        // Обнуляем время последней активности
        if (isset($_SESSION['user_id'])) {
            $pdo->prepare("UPDATE users SET Last_Activity = NULL WHERE ID_U = ?")
                ->execute([$_SESSION['user_id']]);
        }
    } catch (\PDOException $e) {
        // Игнорируем ошибки БД при выходе, чтобы не блокировать пользователя
    }
}

// Уничтожаем сессию PHP
session_destroy();

// Перенаправляем на главную
header('Location: index.php');
exit;