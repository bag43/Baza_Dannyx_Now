<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

if (isset($_GET['read'])) {
    $nid = (int) $_GET['read'];
    $pdo->prepare("UPDATE notifications SET Is_Read = 1 WHERE Notification_ID = ? AND User_ID = ?")
        ->execute([$nid, $userId]);
    header('Location: messages.php');
    exit;
}

if (isset($_GET['delete'])) {
    $nid = (int) $_GET['delete'];
    $pdo->prepare("UPDATE notifications SET Deleted_By_User = 1 WHERE Notification_ID = ? AND User_ID = ?")
        ->execute([$nid, $userId]);
    header('Location: messages.php');
    exit;
}

if (isset($_GET['read_all'])) {
    $pdo->prepare("UPDATE notifications SET Is_Read = 1 WHERE User_ID = ? AND Deleted_By_User = 0")
        ->execute([$userId]);
    header('Location: messages.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT 
        n.Notification_ID, n.Subject, n.Message, n.Is_Read, n.Is_System, n.Created_at,
        s.Login AS Sender_Login, s.Role AS Sender_Role
    FROM notifications n
    LEFT JOIN users s ON s.ID_U = n.Sender_ID
    WHERE n.User_ID = ? AND n.Deleted_By_User = 0
    ORDER BY n.Created_at DESC
");
$stmt->execute([$userId]);
$messages = $stmt->fetchAll();

$unread = count(array_filter($messages, fn(array $m): bool => $m['Is_Read'] === '0'));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои сообщения</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 900px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        
        .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px; }
        .btn-read-all { background: #17a2b8; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; font-size: 14px; font-weight: bold; }
        .btn-read-all:hover { background: #138496; }
        
        .msg-card {
            background: white; padding: 20px; border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 12px;
            border-left: 5px solid #e0e0e0; transition: 0.2s;
        }
        .msg-card.unread { border-left-color: #007bff; background: #f8fbff; }
        .msg-card.system { border-left-color: #dc3545; }
        
        .msg-header { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; }
        .msg-subject { font-size: 16px; font-weight: bold; color: #333; margin: 0; }
        .msg-meta { font-size: 12px; color: #888; }
        .msg-body { color: #555; font-size: 14px; line-height: 1.5; margin: 12px 0; white-space: pre-wrap; }
        
        .badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-sys { background: #dc3545; color: white; }
        .badge-adm { background: #fd7e14; color: white; }
        .badge-unread { background: #007bff; color: white; }
        
        .msg-actions { margin-top: 12px; padding-top: 12px; border-top: 1px dashed #eee; }
        .btn-sm {
            padding: 5px 12px; border-radius: 4px; text-decoration: none;
            font-size: 12px; color: white; margin-right: 6px; display: inline-block;
        }
        .btn-read { background: #28a745; }
        .btn-del { background: #dc3545; }
        .btn-read:hover { background: #218838; }
        .btn-del:hover { background: #c82333; }
        
        .empty { text-align: center; padding: 40px; color: #999; background: white; border-radius: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back">← В личный кабинет</a>
        
        <div class="top-bar">
            <h1>✉️ Мои сообщения <?= $unread > 0 ? "<span style='color:#dc3545;'>($unread новых)</span>" : '' ?></h1>
            <?php if ($unread > 0): ?>
                <a href="?read_all=1" class="btn-read-all">✅ Прочитать все</a>
            <?php endif; ?>
        </div>
        
        <?php if (empty($messages)): ?>
            <div class="empty">
                <p style="font-size:40px; margin:10px;">📭</p>
                <p>У вас нет сообщений.</p>
            </div>
        <?php else: ?>
            <?php foreach ($messages as $m): ?>
                <div class="msg-card <?= $m['Is_Read'] === '0' ? 'unread' : '' ?> <?= $m['Is_System'] === '1' ? 'system' : '' ?>">
                    <div class="msg-header">
                        <div>
                            <h3 class="msg-subject">
                                <?php if ($m['Is_Read'] === '0'): ?>
                                    <span class="badge badge-unread">НОВОЕ</span>
                                <?php endif; ?>
                                <?= htmlspecialchars($m['Subject'] ?? 'Без темы', ENT_QUOTES, 'UTF-8') ?>
                            </h3>
                            <div class="msg-meta">
                                <?php if ($m['Is_System'] === '1'): ?>
                                    <span class="badge badge-sys">СИСТЕМА</span>
                                <?php else: ?>
                                    От: <b><?= htmlspecialchars($m['Sender_Login'] ?? 'Администратор', ENT_QUOTES, 'UTF-8') ?></b>
                                    <?php if (($m['Sender_Role'] ?? '') === 'System_Admin'): ?>
                                        <span class="badge badge-sys">Sys_Admin</span>
                                    <?php elseif (($m['Sender_Role'] ?? '') === 'Admin'): ?>
                                        <span class="badge badge-adm">Admin</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                                · <?= htmlspecialchars($m['Created_at'], ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="msg-body"><?= htmlspecialchars($m['Message'], ENT_QUOTES, 'UTF-8') ?></div>
                    
                    <div class="msg-actions">
                        <?php if ($m['Is_Read'] === '0'): ?>
                            <a href="?read=<?= $m['Notification_ID'] ?>" class="btn-sm btn-read">✅ Пометить прочитанным</a>
                        <?php endif; ?>
                        <a href="?delete=<?= $m['Notification_ID'] ?>" class="btn-sm btn-del"
                           onclick="return confirm('Удалить это сообщение?')">🗑 Удалить</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>