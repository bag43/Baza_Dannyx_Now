<?php
require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$role   = $_SESSION['user_role'] ?? 'User';
$flash  = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ============ ЗАПРОС: все заметки (сис-админ) или свои (обычный) ============
if ($role === 'System_Admin') {
    $stmt = $pdo->query("
        SELECT n.*, u.Login AS Author, u.Role AS Author_Role
        FROM notes n
        JOIN users u ON u.ID_U = n.Id_user
        ORDER BY n.Id ASC
    ");
} else {
    $stmt = $pdo->prepare("
        SELECT n.*, u.Login AS Author, u.Role AS Author_Role
        FROM notes n
        JOIN users u ON u.ID_U = n.Id_user
        WHERE n.Id_user = ?
        ORDER BY n.Id ASC
    ");
    $stmt->execute([$userId]);
}
$notes = $stmt->fetchAll();

// ============ СТАТИСТИКА ============
$totalNotes = count($notes);
$totalChars = array_sum(array_map(fn($n) => mb_strlen($n['Content']), $notes));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заметки</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 1100px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }

        .top-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; flex-wrap: wrap; gap: 10px;
        }
        .top-actions { display: flex; gap: 10px; flex-wrap: wrap; }

        .btn {
            padding: 10px 20px; border-radius: 6px; text-decoration: none;
            font-size: 14px; font-weight: bold; color: white; border: none;
            cursor: pointer; display: inline-block; transition: 0.2s;
        }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 3px 8px rgba(0,0,0,0.15); }
        .btn-add { background: #28a745; }
        .btn-add:hover { background: #218838; }
        .btn-download { background: #6c757d; }
        .btn-download:hover { background: #5a6268; }

        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }

        .stats {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px; margin-bottom: 20px;
        }
        .stat-card {
            background: white; padding: 15px 20px; border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-left: 5px solid #007bff;
        }
        .stat-card .label { font-size: 12px; color: #666; }
        .stat-card .value { font-size: 24px; font-weight: bold; color: #333; }

        .note-card {
            background: white; padding: 20px; border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 15px;
            border-left: 5px solid #007bff; transition: 0.2s;
        }
        .note-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.12); }
        .note-card.foreign { border-left-color: #dc3545; background: #fffafa; }

        .note-header {
            display: flex; justify-content: space-between; align-items: flex-start;
            margin-bottom: 12px; flex-wrap: wrap; gap: 10px;
        }
        .note-title { font-size: 18px; font-weight: bold; margin: 0; color: #333; }
        .note-meta { font-size: 12px; color: #888; }
        .note-meta .badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }
        .badge-sys { background: #dc3545; color: white; }
        .badge-adm { background: #fd7e14; color: white; }
        .badge-usr { background: #007bff; color: white; }
        .badge-own { background: #28a745; color: white; }

        .note-content {
            color: #555; font-size: 14px; line-height: 1.6;
            white-space: pre-wrap; word-wrap: break-word;
            padding: 12px 0; border-top: 1px dashed #eee; border-bottom: 1px dashed #eee;
            margin: 12px 0;
        }

        .note-actions { display: flex; gap: 8px; }
        .btn-sm {
            padding: 6px 12px; border-radius: 4px; text-decoration: none;
            font-size: 12px; color: white; border: none; cursor: pointer;
            font-weight: bold;
        }
        .btn-edit { background: #007bff; }
        .btn-edit:hover { background: #0056b3; }
        .btn-del { background: #dc3545; }
        .btn-del:hover { background: #c82333; }

        .empty {
            background: white; padding: 60px 20px; border-radius: 10px;
            text-align: center; color: #999; box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .empty .icon { font-size: 60px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back">← В личный кабинет</a>

        <div class="top-bar">
            <h1>📝 <?= $role === 'System_Admin' ? 'Все заметки пользователей' : 'Мои заметки' ?></h1>
            <div class="top-actions">
                <a href="api_notes.php?download=1&filename=notes" class="btn btn-download">⬇️ Скачать notes.json</a>
                <a href="notes_edit.php" class="btn btn-add">➕ Новая заметка</a>
            </div>
        </div>

        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg']) ?></div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat-card">
                <div class="label">📋 Всего заметок</div>
                <div class="value"><?= $totalNotes ?></div>
            </div>
            <div class="stat-card" style="border-left-color: #28a745;">
                <div class="label">📝 Символов в тексте</div>
                <div class="value"><?= number_format($totalChars, 0, '.', ' ') ?></div>
            </div>
        </div>

        <?php if (empty($notes)): ?>
            <div class="empty">
                <div class="icon">📭</div>
                <h2>Заметок пока нет</h2>
                <p>Нажмите «➕ Новая заметка», чтобы создать первую.</p>
            </div>
        <?php else: ?>
            <?php foreach ($notes as $n):
                $isMine = ($n['Id_user'] == $userId);
                $canEdit = $isMine || $role === 'System_Admin';
            ?>
                <div class="note-card <?= !$isMine ? 'foreign' : '' ?>">
                    <div class="note-header">
                        <div>
                            <h3 class="note-title"><?= htmlspecialchars($n['Title']) ?></h3>
                            <div class="note-meta">
                                ID: <b><?= str_pad((string)$n['Id'], 5, '0', STR_PAD_LEFT) ?></b>
                                · Автор: <b><?= htmlspecialchars($n['Author']) ?></b>
                                <?php if ($isMine): ?>
                                    <span class="badge badge-own">Моя</span>
                                <?php else: ?>
                                    <?php
                                        $cls = $n['Author_Role'] === 'System_Admin' ? 'badge-sys' :
                                              ($n['Author_Role'] === 'Admin' ? 'badge-adm' : 'badge-usr');
                                    ?>
                                    <span class="badge <?= $cls ?>"><?= $n['Author_Role'] ?></span>
                                <?php endif; ?>
                                · <?= date('d.m.Y', strtotime($n['created_at'])) ?>
                            </div>
                        </div>
                    </div>

                    <div class="note-content"><?= htmlspecialchars($n['Content']) ?></div>

                    <?php if ($canEdit): ?>
                    <div class="note-actions">
                        <a href="notes_edit.php?id=<?= $n['Id'] ?>" class="btn-sm btn-edit">✏️ Редактировать</a>
                        <a href="notes_actions.php?action=delete&id=<?= $n['Id'] ?>"
                           class="btn-sm btn-del"
                           onclick="return confirm('Удалить заметку «<?= htmlspecialchars($n['Title']) ?>»?')">
                           🗑 Удалить
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>