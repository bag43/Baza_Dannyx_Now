<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    die('Доступ запрещён.');
}

function setFlash(string $msg, bool $isError = false): void
{
    $_SESSION['flash'] = ['msg' => $msg, 'error' => $isError];
}

$userId = (int) $_SESSION['user_id'];
$role   = $_SESSION['user_role'] ?? 'User';
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'insert':
            $title   = trim($_POST['title'] ?? '');
            $content = trim($_POST['content'] ?? '');

            if (!$title || !$content) {
                throw new \Exception('Заполните все поля');
            }
            if (mb_strlen($title) > 255) {
                throw new \Exception('Заголовок длиннее 255 символов');
            }
            if (mb_strlen($content) > 10000) {
                throw new \Exception('Содержание длиннее 10 000 символов');
            }

            $pdo->prepare("
                INSERT INTO notes (Title, Content, Id_user, created_at) 
                VALUES (?, ?, ?, NOW())
            ")->execute([$title, $content, $userId]);

            setFlash('✅ Заметка успешно создана!');
            header('Location: notes.php');
            exit;

        case 'update':
            $noteId  = (int) ($_POST['id'] ?? 0);
            $title   = trim($_POST['title'] ?? '');
            $content = trim($_POST['content'] ?? '');

            if (!$noteId) {
                throw new \Exception('Не указан ID заметки');
            }
            if (!$title || !$content) {
                throw new \Exception('Заполните все поля');
            }

            $stmt = $pdo->prepare("SELECT Id_user FROM notes WHERE Id = ?");
            $stmt->execute([$noteId]);
            $ownerId = $stmt->fetchColumn();

            if ($ownerId === false) {
                throw new \Exception('Заметка не найдена');
            }
            if ($ownerId != $userId && $role !== 'System_Admin') {
                throw new \Exception('Вы не можете редактировать чужие заметки');
            }

            $pdo->prepare("
                UPDATE notes SET Title = ?, Content = ? WHERE Id = ?
            ")->execute([$title, $content, $noteId]);

            setFlash('✅ Заметка обновлена!');
            header('Location: notes.php');
            exit;

        case 'delete':
            $noteId = (int) ($_GET['id'] ?? 0);
            if (!$noteId) {
                throw new \Exception('Не указан ID заметки');
            }

            $stmt = $pdo->prepare("SELECT Id_user FROM notes WHERE Id = ?");
            $stmt->execute([$noteId]);
            $ownerId = $stmt->fetchColumn();

            if ($ownerId === false) {
                throw new \Exception('Заметка не найдена');
            }
            if ($ownerId != $userId && $role !== 'System_Admin') {
                throw new \Exception('Вы не можете удалять чужие заметки');
            }

            $pdo->prepare("DELETE FROM notes WHERE Id = ?")->execute([$noteId]);

            setFlash('🗑 Заметка удалена.');
            header('Location: notes.php');
            exit;

        default:
            throw new \Exception('Неизвестное действие');
    }
} catch (\Exception $e) {
    setFlash('❌ Ошибка: ' . $e->getMessage(), true);
    header('Location: notes.php');
    exit;
}