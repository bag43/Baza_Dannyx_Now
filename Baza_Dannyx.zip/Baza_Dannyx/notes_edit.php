<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$role   = $_SESSION['user_role'] ?? 'User';
$isEdit = isset($_GET['id']) && $_GET['id'] !== '';

$note = ['Title' => '', 'Content' => ''];

if ($isEdit) {
    $noteId = (int) $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM notes WHERE Id = ?");
    $stmt->execute([$noteId]);
    $note = $stmt->fetch();

    if (!$note) {
        $_SESSION['flash'] = ['msg' => 'Заметка не найдена', 'error' => true];
        header('Location: notes.php');
        exit;
    }

    if ($note['Id_user'] != $userId && $role !== 'System_Admin') {
        die('Доступ запрещён. Вы можете редактировать только свои заметки.');
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Редактирование' : 'Новая' ?> заметка</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; margin: 0; }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { margin-top: 10px; }
        .back { display: inline-block; margin-bottom: 15px; color: #007bff; text-decoration: none; font-weight: bold; }
        
        .card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        
        .msg { padding: 12px 18px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; background: #d4edda; color: #155724; border-left: 5px solid #28a745; }
        .msg.error { background: #f8d7da; color: #721c24; border-left-color: #dc3545; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 6px; }
        .form-group input, .form-group textarea {
            width: 100%; padding: 12px; box-sizing: border-box;
            border: 1px solid #ccc; border-radius: 6px; font-size: 14px;
            font-family: inherit;
        }
        .form-group textarea { resize: vertical; min-height: 200px; }
        .form-group .hint { font-size: 12px; color: #888; margin-top: 4px; }
        
        .btn-save {
            background: #28a745; color: white; border: none; padding: 14px 30px;
            border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold;
        }
        .btn-save:hover { background: #218838; }
        .btn-cancel {
            display: inline-block; margin-left: 15px; color: #666; text-decoration: none;
            font-size: 14px;
        }
        .btn-cancel:hover { color: #000; }
        
        .author-notice {
            background: #fff3cd; padding: 12px 18px; border-radius: 6px;
            margin-bottom: 20px; border-left: 5px solid #ffc107;
            font-size: 13px; color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="notes.php" class="back">← К заметкам</a>
        <h1><?= $isEdit ? '✏️ Редактирование заметки' : '➕ Новая заметка' ?></h1>

        <?php if ($isEdit && $note['Id_user'] != $userId && $role === 'System_Admin'): 
            $authorStmt = $pdo->prepare("SELECT Login FROM users WHERE ID_U = ?");
            $authorStmt->execute([$note['Id_user']]);
            $author = $authorStmt->fetchColumn();
        ?>
            <div class="author-notice">
                ⚠️ Вы редактируете заметку пользователя <b><?= htmlspecialchars((string)$author, ENT_QUOTES, 'UTF-8') ?></b> как системный администратор.
            </div>
        <?php endif; ?>

        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="notes_actions.php">
                <input type="hidden" name="action" value="<?= $isEdit ? 'update' : 'insert' ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="id" value="<?= $note['Id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label>Заголовок:</label>
                    <input type="text" name="title" required maxlength="255"
                           value="<?= htmlspecialchars($note['Title'], ENT_QUOTES, 'UTF-8') ?>"
                           placeholder="Например: Список задач на день">
                    <div class="hint">Максимум 255 символов.</div>
                </div>

                <div class="form-group">
                    <label>Содержание:</label>
                    <textarea name="content" required maxlength="10000"
                              placeholder="Введите текст заметки..."><?= htmlspecialchars($note['Content'], ENT_QUOTES, 'UTF-8') ?></textarea>
                    <div class="hint">Максимум 10 000 символов.</div>
                </div>

                <button type="submit" class="btn-save">💾 <?= $isEdit ? 'Сохранить изменения' : 'Создать заметку' ?></button>
                <a href="notes.php" class="btn-cancel">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>