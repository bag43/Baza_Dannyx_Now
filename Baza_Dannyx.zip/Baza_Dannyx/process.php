<?php declare(strict_types=1);

require 'db.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // 1. Проверка капчи
    $captcha_order = $_POST['captcha_order'] ?? '';
    if ($captcha_order !== '1,2,3,4') {
        $response['message'] = 'Ошибка: Картинки расположены в неправильном порядке!';
        echo json_encode($response);
        exit;
    }

    // 2. Обработка ВХОДА
    if ($action === 'login') {
        $login = trim($_POST['login']);
        $password = $_POST['password'];
        $hashed_password = hash('sha256', $password); 

        $start_time = microtime(true);

        try {
            $stmt = $pdo->prepare("CALL CheckUserLogin(?, ?)");
            $stmt->execute([$login, $hashed_password]);
            $result = $stmt->fetch();
            $stmt->closeCursor();

            if ($result && $result['Result'] === 'Успешный вход') {
                $stmt2 = $pdo->prepare("SELECT ID_U, Role, Kick_Flag FROM users WHERE Login = ?");
                $stmt2->execute([$login]);
                $userData = $stmt2->fetch();

                if ($userData['Kick_Flag'] == 1) {
                    $pdo->prepare("UPDATE users SET Kick_Flag = 0 WHERE ID_U = ?")->execute([$userData['ID_U']]);
                }

                // === УДАЛЯЕМ СТАРЫЕ СЕССИИ ЭТОГО ПОЛЬЗОВАТЕЛЯ ===
                $pdo->prepare("DELETE FROM active_sessions WHERE User_ID = ?")->execute([$userData['ID_U']]);

                session_regenerate_id(true);
                $_SESSION['user_id']    = $userData['ID_U'];
                $_SESSION['user_login'] = $login;
                $_SESSION['user_role']  = $userData['Role'];
                $_SESSION['session_id'] = session_id();

                $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
                $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
                
                // Создаем новую единственную сессию
                $pdo->prepare("
                    INSERT INTO active_sessions (Session_ID, User_ID, IP_Address, User_Agent, Login_Time, Last_Ping)
                    VALUES (?, ?, ?, ?, NOW(), NOW())
                ")->execute([session_id(), $userData['ID_U'], $ip, $ua]);

                $pdo->prepare("UPDATE users SET Last_Activity = NOW() WHERE ID_U = ?")->execute([$userData['ID_U']]);

                $end_time = microtime(true);
                $response_time_ms = round(($end_time - $start_time) * 1000, 4);
                
                $pdo->prepare("INSERT INTO login_metrics (User_ID, Response_Time_Ms, IP_Address) VALUES (?, ?, ?)")
                    ->execute([$userData['ID_U'], $response_time_ms, $ip]);

                $response['success'] = true;
                $response['message'] = $result['Result'];
            } else {
                $response['message'] = $result['Result'] ?? 'Неизвестная ошибка при входе.';
            }
        } catch (PDOException $e) {
            $response['message'] = "Ошибка БД: " . $e->getMessage();
        }
    }

    // 3. Обработка РЕГИСТРАЦИИ
    if ($action === 'register') {
        $login = trim($_POST['login']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'] ?? '';
        $phone = trim($_POST['phone']);
        $lastName = trim($_POST['last_name'] ?? '');
        $firstName = trim($_POST['first_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        
        $role = 'User';

        if (!$lastName || !$firstName || !$email) {
            $response['message'] = 'Ошибка: Заполните ФИО и Email.';
            echo json_encode($response);
            exit;
        }

        if ($password !== $confirm_password) {
            $response['message'] = 'Ошибка: Введенные пароли не совпадают!';
            echo json_encode($response);
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response['message'] = 'Ошибка: Неверный формат Email.';
            echo json_encode($response);
            exit;
        }

        $hashed_password = hash('sha256', $password);

        try {
            $emailCheck = $pdo->prepare("SELECT COUNT(*) FROM user_profiles WHERE Email = ?");
            $emailCheck->execute([$email]);
            if ($emailCheck->fetchColumn() > 0) {
                $response['message'] = 'Ошибка: Пользователь с таким Email уже существует.';
                echo json_encode($response);
                exit;
            }

            $stmt = $pdo->prepare("CALL RegisterUser(?, ?, ?, ?)");
            $stmt->execute([$login, $hashed_password, $phone, $role]);
            $result = $stmt->fetch();
            $stmt->closeCursor();

            if ($result && strpos($result['Result'], 'Успех') !== false) {
                $idStmt = $pdo->prepare("SELECT ID_U FROM users WHERE Login = ?");
                $idStmt->execute([$login]);
                $newUserId = $idStmt->fetchColumn();

                if ($newUserId) {
                    $profileStmt = $pdo->prepare("INSERT INTO user_profiles (User_ID, Last_Name, First_Name, Email) VALUES (?, ?, ?, ?)");
                    $profileStmt->execute([$newUserId, $lastName, $firstName, $email]);
                }

                $response['success'] = true;
                $response['message'] = 'Регистрация успешна! Перенаправление...';
            } else {
                $response['message'] = $result['Result'] ?? 'Ошибка при регистрации.';
            }
        } catch (PDOException $e) {
            $response['message'] = "Ошибка БД: " . $e->getMessage();
        }
    }
}

echo json_encode($response);