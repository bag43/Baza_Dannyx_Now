<?php
declare(strict_types=1);

require 'db.php';

if (isset($_SESSION['user_login'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; padding: 20px; }
        .form-container { background: white; padding: 30px; border-radius: 10px; width: 450px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-top: 0; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .row { display: flex; gap: 10px; }
        .row .form-group { flex: 1; }
        .submit-btn { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 15px; }
        .submit-btn:hover { background: #218838; }
        .message { padding: 12px; margin-bottom: 15px; border-radius: 4px; font-size: 14px; display: none; }
        .message.error { background: #f8d7da; color: #721c24; display: block; }
        .message.success { background: #d4edda; color: #155724; display: block; }
        .back-link { display: block; text-align: center; margin-top: 15px; color: #007bff; text-decoration: none; }
    </style>
</head>
<body>

    <div class="form-container">
        <h2>Регистрация</h2>
        <div id="registerMessage" class="message"></div>

        <form id="registerForm">
            <input type="hidden" name="action" value="register">
            
            <div class="row">
                <div class="form-group">
                    <label>Фамилия:</label>
                    <input type="text" name="last_name" required>
                </div>
                <div class="form-group">
                    <label>Имя:</label>
                    <input type="text" name="first_name" required>
                </div>
            </div>

            <div class="form-group">
                <label>Email (Почта):</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Логин:</label>
                <input type="text" name="login" required>
            </div>
            
            <div class="form-group">
                <label>Пароль:</label>
                <input type="password" name="password" id="pass1" required>
            </div>

            <!-- НОВОЕ ПОЛЕ: Повтор пароля -->
            <div class="form-group">
                <label>Повторите пароль:</label>
                <input type="password" name="confirm_password" id="pass2" required>
            </div>

            <div class="form-group">
                <label>Номер телефона:</label>
                <input type="text" name="phone" required>
            </div>
            <?php include 'captcha.php'; ?>
            <button type="submit" class="submit-btn">Зарегистрироваться</button>
        </form>
        <a href="index.php" class="back-link">Вернуться на главную</a>
    </div>

    <script>
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const pass1 = document.getElementById('pass1').value;
            const pass2 = document.getElementById('pass2').value;
            const msgDiv = document.getElementById('registerMessage');
            
            // Быстрая проверка совпадения паролей на клиенте
            if (pass1 !== pass2) {
                msgDiv.className = 'message error';
                msgDiv.textContent = 'Ошибка: Пароли не совпадают!';
                return; // Останавливаем отправку
            }

            const formData = new FormData(this);
            const btn = this.querySelector('.submit-btn');
            
            btn.disabled = true;
            btn.textContent = 'Регистрация...';
            msgDiv.className = 'message';
            msgDiv.textContent = '';
            
            fetch('process.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    btn.disabled = false;
                    btn.textContent = 'Зарегистрироваться';
                    msgDiv.className = 'message ' + (data.success ? 'success' : 'error');
                    msgDiv.textContent = data.message;
                    if (data.success) {
                        setTimeout(() => { window.location.href = 'index.php'; }, 2000);
                    }
                })
                .catch(() => {
                    btn.disabled = false;
                    btn.textContent = 'Зарегистрироваться';
                    msgDiv.className = 'message error';
                    msgDiv.textContent = 'Ошибка соединения с сервером.';
                });
        });
    </script>
</body>
</html>