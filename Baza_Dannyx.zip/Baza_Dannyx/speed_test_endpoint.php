<?php declare(strict_types=1);

// Размер тестового файла (УВЕЛИЧЕН ДО 50 МБ)
$sizeInMB = 50; 
$bytes = $sizeInMB * 1024 * 1024;

header('Content-Type: application/octet-stream');
header('Content-Length: ' . $bytes);
header('Content-Disposition: attachment; filename="speedtest.bin"');

// Отключаем буферизацию
while (ob_get_level()) {
    ob_end_clean();
}

// Выводим 50 МБ нулей
echo str_repeat('0', $bytes);
exit;