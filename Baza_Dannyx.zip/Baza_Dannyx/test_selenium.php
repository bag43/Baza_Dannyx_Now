 <?php
require 'vendor/autoload.php';

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Chrome\ChromeOptions;

echo "1. Подключение к ChromeDriver...<br>";
try {
    $options = new ChromeOptions();
    $options->setBinary('/usr/bin/chromium-browser');
    // Самый минимум аргументов
    $options->addArguments(['--headless', '--no-sandbox', '--disable-dev-shm-usage']);
    
    $capabilities = DesiredCapabilities::chrome();
    $capabilities->setCapability(ChromeOptions::CAPABILITY, $options);
    
    $driver = RemoteWebDriver::create('http://localhost:4444', $capabilities, 10000, 10000);
    echo "2. Браузер успешно запущен!<br>";
    
    echo "3. Открываем страницу...<br>";
    $driver->get('http://localhost:3000/index.php');
    echo "4. Страница загружена. Заголовок: " . $driver->getTitle() . "<br>";
    
    $driver->quit();
    echo "5. Успех!";
} catch (\Exception $e) {
    echo "ОШИБКА: " . $e->getMessage();
}
