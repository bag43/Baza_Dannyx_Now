<?php declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$backupDir = __DIR__ . '/backups';
if (!is_dir($backupDir)) {
    @mkdir($backupDir, 0755, true);
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Получаем список файлов
$backups = [];
$files = glob($backupDir . '/*.sql');
if ($files) {
    foreach ($files as $file) {
        $backups[] = [
            'name' => basename($file),
            'size' => filesize($file),
            'date' => filemtime($file),
        ];
    }
    usort($backups, fn(array $a, array $b): int => $b['date'] <=> $a['date']);
}

// Получаем логи
try {
    $logs = $pdo->query("
        SELECT b.*, u.Login AS Admin_Login
        FROM backup_logs b
        LEFT JOIN users u ON u.ID_U = b.Created_By
        ORDER BY b.Created_at DESC
        LIMIT 20
    ")->fetchAll();
} catch (\PDOException $e) {
    $logs = [];
}

function formatBytes(int $bytes): string {
    $units = ['Б', 'КБ', 'МБ', 'ГБ'];
    $pow = $bytes > 0 ? floor(log($bytes) / log(1024)) : 0;
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, 2) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Резервные копии БД</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin-backup.css">
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        <h1>💾 Резервные копии БД</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📥 Создать резервную копию</h2>
            <p style="color:#666;">Создаётся полный дамп базы данных <code>Project_Yfkin</code> в формате SQL.</p>
            
            <form method="POST" action="backup_create.php" id="backupForm">
                <button type="submit" class="btn-create" id="createBtn">💾 Создать бэкап сейчас</button>
            </form>
            
            <div class="loading" id="loadingBox">
                ⏳ Идёт создание резервной копии... Пожалуйста, не закрывайте страницу.
            </div>
        </div>
        
        <div class="card">
            <h2>📁 Существующие бэкапы (<?= count($backups) ?>)</h2>
            <?php if (empty($backups)): ?>
                <p style="color:#999;">Пока нет ни одной резервной копии.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr><th>Файл</th><th>Размер</th><th>Создан</th><th>Действия</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($backups as $b): ?>
                        <tr>
                            <td><b><?= htmlspecialchars($b['name'], ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><?= formatBytes($b['size']) ?></td>
                            <td><?= date('d.m.Y H:i:s', $b['date']) ?></td>
                            <td>
                                <a href="backup_download.php?file=<?= urlencode($b['name']) ?>" class="btn btn-download">⬇️ Скачать</a>
                                <a href="backup_restore.php?file=<?= urlencode($b['name']) ?>" class="btn btn-restore" onclick="return confirm('⚠️ ВОССТАНОВИТЬ БД?\n\nВсе текущие данные будут ЗАМЕНЕНЫ!')">♻️ Восстановить</a>
                                <a href="backup_delete.php?file=<?= urlencode($b['name']) ?>" class="btn btn-delete" onclick="return confirm('Удалить файл бэкапа?')">🗑 Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div class="card">
            <h2>📜 История бэкапов (лог)</h2>
            <?php if (empty($logs)): ?>
                <p style="color:#999;">История пуста.</p>
            <?php else: ?>
                <table class="data">
                    <thead><tr><th>Дата</th><th>Файл</th><th>Размер</th><th>Кто создал</th><th>Тип</th></tr></thead>
                    <tbody>
                        <?php foreach ($logs as $l): ?>
                        <tr>
                            <td><?= htmlspecialchars($l['Created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars($l['Filename'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= $l['Size_KB'] ?> КБ</td>
                            <td><?= htmlspecialchars($l['Admin_Login'] ?? '—', ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= $l['Type'] === 'auto' ? '🤖 Авто' : '👤 Ручной' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.getElementById('backupForm').addEventListener('submit', function() {
            // Показываем анимацию загрузки
            document.getElementById('loadingBox').classList.add('active');
            const btn = document.getElementById('createBtn');
            
            // ВАЖНО: мы НЕ отключаем кнопку через disabled, чтобы форма ушла на сервер.
            // Вместо этого просто блокируем повторный клик через CSS.
            btn.style.pointerEvents = 'none';
            btn.style.opacity = '0.7';
            btn.textContent = '⏳ Создание...';
        });
    </script>
</body>
</html>