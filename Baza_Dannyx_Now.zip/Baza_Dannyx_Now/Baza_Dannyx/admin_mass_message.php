<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён.');
}

$userIds = $_SESSION['mass_message_ids'] ?? [];
if (empty($userIds)) {
    header('Location: admin.php');
    exit;
}

$placeholders = implode(',', array_fill(0, count($userIds), '?'));
$stmt = $pdo->prepare("SELECT Login FROM users WHERE ID_U IN ($placeholders)");
$stmt->execute($userIds);
$logins = $stmt->fetchAll(PDO::FETCH_COLUMN);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Массовая отправка сообщений</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin-messages.css">
</head>
<body>
    <div class="container">
        <a href="admin.php" class="back">← Назад в панель администратора</a>
        <h1>✉️ Массовая отправка сообщений</h1>

        <?php if ($flash): ?>
            <div style="padding:12px; background:#f8d7da; color:#721c24; border-radius:6px; margin-bottom:15px;">
                <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="recipients">
                <b>Получатели (<?= count($logins) ?>):</b><br>
                <?php foreach ($logins as $login): ?>
                    <code><?= htmlspecialchars($login, ENT_QUOTES, 'UTF-8') ?></code>
                <?php endforeach; ?>
            </div>

            <form method="POST" action="admin_mass_message_send.php">
                <div class="form-group">
                    <label>Тема:</label>
                    <input type="text" name="subject" required maxlength="255" placeholder="Например: Важное объявление">
                </div>

                <div class="form-group">
                    <label>Текст сообщения:</label>
                    <textarea name="message" required maxlength="2000" placeholder="Введите текст..."></textarea>
                </div>

                <button type="submit" class="submit-btn">📤 Отправить всем</button>
                <a href="admin.php" style="margin-left:15px; color:#666; text-decoration:none;">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>