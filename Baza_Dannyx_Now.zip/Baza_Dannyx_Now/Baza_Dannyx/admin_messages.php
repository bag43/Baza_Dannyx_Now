<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    die('Доступ запрещён. Только для администраторов.');
}

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ============ ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ИЗ URL (если перешли по кнопке) ============
$toUserId = isset($_GET['to']) ? (int)$_GET['to'] : 0;

// Получаем список всех пользователей
$users = $pdo->query("
    SELECT ID_U, Login, Role 
    FROM users 
    WHERE Ban = '0'
    ORDER BY Role, Login
")->fetchAll();

// Последние 30 отправленных сообщений от этого админа
try {
    $sentMessages = $pdo->prepare("
        SELECT 
            n.Notification_ID, n.User_ID, n.Subject, n.Message, n.Created_at, n.Is_Read,
            u.Login AS Recipient_Login,
            s.Login AS Sender_Login
        FROM notifications n
        JOIN users u ON u.ID_U = n.User_ID
        LEFT JOIN users s ON s.ID_U = n.Sender_ID
        WHERE n.Sender_ID = ?
        ORDER BY n.Created_at DESC
        LIMIT 30
    ");
    $sentMessages->execute([$_SESSION['user_id']]);
    $sent = $sentMessages->fetchAll();
} catch (\PDOException $e) {
    $sent = [];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Отправка сообщений</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin-messages.css">
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        <h1>✉️ Отправка сообщений</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <h2>📝 Новое сообщение</h2>
            <form method="POST" action="admin_messages_send.php">
                <div class="form-group">
                    <label>Получатель:</label>
                    <select name="user_id" required>
                        <option value="">— выберите получателя —</option>
                        <option value="all" style="font-weight:bold; color:#28a745;">📢 ВСЕМ ПОЛЬЗОВАТЕЛЯМ</option>
                        <?php foreach ($users as $u): 
                            if ($u['ID_U'] == $_SESSION['user_id']) continue;
                            $cls = $u['Role'] === 'System_Admin' ? '🔴' : ($u['Role'] === 'Admin' ? '🟠' : '🔵');
                            
                            // ЕСЛИ ID СОВПАДАЕТ С ТЕМ, ЧТО ПРИШЕЛ В URL - ВЫДЕЛЯЕМ ЕГО
                            $selected = ($u['ID_U'] == $toUserId) ? 'selected' : '';
                        ?>
                            <option value="<?= $u['ID_U'] ?>" <?= $selected ?>>
                                <?= $cls ?> <?= htmlspecialchars($u['Login'], ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($u['Role'], ENT_QUOTES, 'UTF-8') ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Тема:</label>
                    <input type="text" name="subject" required maxlength="255" placeholder="Например: Важное объявление">
                </div>
                
                <div class="form-group">
                    <label>Текст сообщения:</label>
                    <textarea name="message" required maxlength="2000" placeholder="Введите текст сообщения..."></textarea>
                    <div class="hint">Максимум 2000 символов.</div>
                </div>
                
                <button type="submit" class="submit-btn">📤 Отправить сообщение</button>
            </form>
        </div>
        
        <div class="card">
            <h2>📨 Последние 30 отправленных вами сообщений</h2>
            <?php if (empty($sent)): ?>
                <p style="color:#999;">Вы пока не отправляли сообщений.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr><th>Дата</th><th>Получатель</th><th>Тема</th><th>Статус</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sent as $m): ?>
                        <tr>
                            <td><?= htmlspecialchars($m['Created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><b><?= htmlspecialchars($m['Recipient_Login'], ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><?= htmlspecialchars($m['Subject'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td>
                                <?php if ($m['Is_Read'] === '1'): ?>
                                    <span class="badge badge-read">✅ Прочитано</span>
                                <?php else: ?>
                                    <span class="badge badge-unread">⏳ Не прочитано</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>