<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

// Первичная загрузка данных для отрисовки HTML
$onlineCount = 0; // Значения подтянутся через JS
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мониторинг системы (Live)</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin-stats.css">
</head>
<body>
    <div class="container">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">← В личный кабинет</a>
            <a href="admin.php" class="btn-back">← В панель администратора</a>
        </div>
        
        <h1>
            📡 Мониторинг системы
            <div class="live-indicator"><div class="live-dot"></div> LIVE (обновление каждые 3 сек)</div>
        </h1>
        
        <!-- ===== ПРОИЗВОДИТЕЛЬНОСТЬ И НАГРУЗКА ===== -->
        <div class="stats-grid">
            <div class="stat-card info">
                <div class="label">⚡ Отклик БД</div>
                <div class="value" id="val-db-ping">— <span style="font-size: 16px;">мс</span></div>
                <div class="sub">Запрос SELECT 1</div>
            </div>
            <div class="stat-card info" style="border-left-color: #6f42c1;">
                <div class="label">🔑 Отклик Входа</div>
                <div class="value" id="val-login-ping">— <span style="font-size: 16px;">мс</span></div>
                <div class="sub">Среднее за последние 50 входов</div>
            </div>
            <div class="stat-card purple">
                <div class="label">🔌 Лимит MySQL</div>
                <div class="value" id="val-max-conn">—</div>
                <div class="sub">Максимум сессий</div>
            </div>
            <div class="stat-card orange">
                <div class="label">👥 Лимит юзеров</div>
                <div class="value" id="val-max-users">—</div>
                <div class="sub">На основе RAM (<span id="val-free-mem">0</span> МБ)</div>
            </div>
        </div>

        <!-- ===== РАЗМЕР БД И ДИСКА ===== -->
        <div class="stats-grid">
            <div class="stat-card disk">
                <div class="label">🗄️ База данных на диске</div>
                <div class="value" id="val-db-size">— <span style="font-size: 16px;">МБ</span></div>
                <div class="sub">Данные актуальны</div>
            </div>
            
            <div class="stat-card green">
                <div class="label">🟢 Сейчас в сети</div>
                <div class="value" id="val-online-count">0</div>
                <div class="sub">активны за последние 5 минут</div>
            </div>
            
            <div class="stat-card <?= '' ?>" id="disk-card" style="grid-column: span 2;">
                <div class="label">💽 Свободно на диске</div>
                <div class="value" id="val-disk-free">—</div>
                <div class="sub">из <span id="val-disk-total">—</span> · занято <span id="val-disk-percent">0</span>%</div>
                <div class="progress-bar">
                    <div class="progress-fill" id="disk-progress-bar" style="width: 0%; background: #28a745;"></div>
                </div>
                <div class="disk-details">
                    <span>Использовано: <span id="val-disk-used">—</span></span>
                    <span><span id="val-disk-free-percent">0</span>% свободно</span>
                </div>
            </div>
        </div>
        
        <!-- ТАБЛИЦА ОНЛАЙН -->
        <div class="card">
            <h2>🟢 Сейчас в сети (<span id="table-online-count">0</span>)</h2>
            <div id="online-table-container">
                <p style="color:#999;">Загрузка данных...</p>
            </div>
        </div>
    </div>

    <script>
        // Функция для форматирования чисел
        function formatNumber(num) {
            return new Intl.NumberFormat('ru-RU').format(num);
        }

        // Основная функция обновления данных
        function fetchStats() {
            fetch('api_stats_data.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        console.error("Ошибка API:", data.error);
                        return;
                    }

                    // 1. Обновление карточек
                    document.getElementById('val-db-ping').innerHTML = data.db_response_ms + ' <span style="font-size: 16px;">мс</span>';
                    document.getElementById('val-login-ping').innerHTML = data.login_response_ms + ' <span style="font-size: 16px;">мс</span>';
                    document.getElementById('val-max-conn').textContent = data.max_connections;
                    document.getElementById('val-max-users').textContent = '~ ' + formatNumber(data.estimated_users);
                    document.getElementById('val-free-mem').textContent = formatNumber(data.free_mem_mb);

                    document.getElementById('val-db-size').innerHTML = data.db_size_mb + ' <span style="font-size: 16px;">МБ</span>';
                    document.getElementById('val-online-count').textContent = data.online_count;

                    document.getElementById('val-disk-free').textContent = data.disk_free_f;
                    document.getElementById('val-disk-total').textContent = data.disk_total_f;
                    document.getElementById('val-disk-used').textContent = data.disk_used_f;
                    document.getElementById('val-disk-percent').textContent = data.disk_percent;
                    document.getElementById('val-disk-free-percent').textContent = (100 - data.disk_percent).toFixed(1);

                    // Обновление прогресс-бара диска
                    const bar = document.getElementById('disk-progress-bar');
                    bar.style.width = data.disk_percent + '%';
                    
                    let barColor = '#28a745'; // Зеленый
                    if (data.disk_percent > 70) barColor = '#ffc107'; // Желтый
                    if (data.disk_percent > 90) barColor = '#dc3545'; // Красный
                    bar.style.background = barColor;

                    // 2. Обновление таблицы онлайн-пользователей
                    document.getElementById('table-online-count').textContent = data.online_count;
                    const tableContainer = document.getElementById('online-table-container');
                    
                    if (data.online_users.length === 0) {
                        tableContainer.innerHTML = '<p style="color:#999;">Нет активных пользователей.</p>';
                    } else {
                        let html = '<table class="data"><thead><tr><th>Логин</th><th>Роль</th><th>IP-адрес</th><th>Вход</th><th>Был активен</th><th>Действия</th></tr></thead><tbody>';
                        
                        data.online_users.forEach(u => {
                            let badgeClass = u.Role === 'System_Admin' ? 'badge-sys' : (u.Role === 'Admin' ? 'badge-adm' : 'badge-usr');
                            
                            html += `<tr>
                                <td><b>${u.Login}</b></td>
                                <td><span class="badge ${badgeClass}">${u.Role}</span></td>
                                <td>${u.IP_Address}</td>
                                <td>${u.Login_Time}</td>
                                <td>${u.Seconds_Ago} сек назад</td>
                                <td>
                                    <a href="admin_kick.php?user_id=${u.ID_U}&session=${encodeURIComponent(u.Session_ID)}" 
                                       class="btn-kick"
                                       onclick="return confirm('Отключить пользователя «${u.Login}» от системы?')">
                                       ⚡ Отключить
                                    </a>
                                </td>
                            </tr>`;
                        });
                        
                        html += '</tbody></table>';
                        tableContainer.innerHTML = html;
                    }
                })
                .catch(err => console.error("Ошибка получения данных:", err));
        }

        // Запускаем сразу при загрузке страницы
        fetchStats();

        // И запускаем интервал каждые 3 секунды (3000 мс)
        setInterval(fetchStats, 3000);
    </script>
</body>
</html>