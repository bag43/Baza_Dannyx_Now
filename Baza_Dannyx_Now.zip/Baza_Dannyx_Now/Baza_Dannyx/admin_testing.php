<?php declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён.');
}

$logFile = __DIR__ . '/selenium_test_results.json';
$groups = [];
if (file_exists($logFile)) {
    $rawData = json_decode(file_get_contents($logFile), true) ?: [];
    foreach ($rawData as $item) {
        if (isset($item['group_id'])) {
            $groups[] = $item;
        }
    }
}

// ============ ПОЛУЧЕНИЕ ИНФОРМАЦИИ О ДИСКЕ ============
$diskPath = '/';
$diskTotal = @disk_total_space($diskPath);
$diskFree  = @disk_free_space($diskPath);
$diskUsed  = $diskTotal - $diskFree;
$diskPercent = ($diskTotal > 0) ? round(($diskUsed / $diskTotal) * 100, 1) : 0;

// ============ ПОЛУЧЕНИЕ РАЗМЕРА БАЗЫ ДАННЫХ ============
$dbSizeQuery = $pdo->query("
    SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb
    FROM information_schema.tables
    WHERE table_schema = DATABASE()
");
$dbSizeMB = $dbSizeQuery->fetchColumn() ?: 0;

function formatBytes(float|int|false $bytes, int $precision = 2): string {
    if ($bytes === false || $bytes === null) return '—';
    $units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}

$diskTotalF = formatBytes($diskTotal);
$diskFreeF  = formatBytes($diskFree);
$diskUsedF  = formatBytes($diskUsed);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Тестирование и отладка</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin-testing.css">
</head>
<body>
    <div class="container">
        <a href="admin.php" style="color: #007bff; text-decoration: none; margin-bottom: 15px; display: inline-block;">← Назад в панель</a>
        <h1>🧪 Тестирование и отладка</h1>

        <div id="globalMessage" class="msg"></div>

        <!-- ИНСТРУМЕНТ 1: ТЕСТИРОВАНИЕ АВТОРИЗАЦИИ -->
        <div class="card">
            <h2>🔐 Инструмент 1: Тестирование авторизации</h2>
            <form id="authForm">
                <div class="form-group">
                    <label>Что тестируем?</label>
                    <select name="target_url" id="target_url">
                        <option value="http://localhost:3000/index.php">Мой сайт</option>
                        <option value="http://localhost/phpmyadmin/">phpMyAdmin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Список аккаунтов (формат: <code>логин:пароль</code>):</label>
                    <textarea name="accounts" required placeholder="sys_admin_1:admin123&#10;admin_1:pass3"></textarea>
                </div>
                <button type="submit" class="btn-run" id="authBtn">▶️ Запустить тест авторизации</button>
            </form>
            <div class="loading" id="authLoading">⏳ Проверка аккаунтов... Подождите.</div>
        </div>

        <!-- ИНСТРУМЕНТ 2: ПРОВЕРКА СВОБОДНОГО МЕСТА -->
        <div class="card">
            <h2>💽 Инструмент 2: Проверка свободного места</h2>
            <div class="disk-widget" id="disk-space-widget" style="margin-bottom: 20px; background: #f8f9fa; padding: 15px; border-radius: 8px;">
                <div class="disk-stats">
                    <p><b>Всего на диске:</b> <span id="disk-total"><?= $diskTotalF ?></span></p>
                    <p><b>Занято на диске:</b> <span id="disk-used"><?= $diskUsedF ?> (<?= $diskPercent ?>%)</span></p>
                    <p><b>Свободно на диске:</b> <span id="disk-free" style="color: green; font-weight: bold;"><?= $diskFreeF ?></span></p>
                    <p><b>Размер базы данных:</b> <span id="db-size" style="color: #007bff; font-weight: bold;"><?= $dbSizeMB ?> МБ</span></p>
                </div>
                <div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?= $diskPercent ?>%; background: <?= $diskPercent > 90 ? '#dc3545' : ($diskPercent > 70 ? '#ffc107' : '#28a745') ?>;"></div>
                    </div>
                </div>
            </div>
            <form id="diskForm">
                <button type="submit" class="btn-disk" id="diskBtn">🧪 Запустить Selenium-проверку виджета</button>
            </form>
            <div class="loading" id="diskLoading">⏳ Selenium проверяет виджет... Подождите.</div>
        </div>

        <!-- ИНСТРУМЕНТ 3: ТЕСТ СКОРОСТИ -->
        <div class="card">
            <h2>🚀 Инструмент 3: Скорость соединения (Selenium)</h2>
            <p style="color: #666;">Selenium скачает тестовый файл весом 50 МБ и замерит время загрузки, чтобы вычислить скорость в МБ/с.</p>
            <form id="speedForm">
                <button type="submit" class="btn-speed" id="speedBtn">⚡ Запустить тест скорости</button>
            </form>
            <div class="loading" id="speedLoading">⏳ Selenium скачивает 50 МБ данных... Подождите.</div>
        </div>

        <!-- ИСТОРИЯ -->
        <h2>📊 История запусков</h2>
        <?php if (empty($groups)): ?>
            <div class="card" style="text-align: center; color: #999;">Нет результатов.</div>
        <?php else: ?>
            <?php foreach ($groups as $group): ?>
                <div class="group-card">
                    <div class="group-header">
                        <div>
                            <h3 class="group-title">Тест от <?= htmlspecialchars($group['timestamp'], ENT_QUOTES, 'UTF-8') ?></h3>
                            <div class="group-meta">
                                Всего: <b><?= $group['total'] ?? 0 ?></b> | 
                                Успешно: <b style="color: green;"><?= $group['success'] ?? 0 ?></b> | 
                                Провалено: <b style="color: red;"><?= ($group['total'] ?? 0) - ($group['success'] ?? 0) ?></b>
                            </div>
                        </div>
                        <a href="admin_testing_download.php?group_id=<?= urlencode($group['group_id']) ?>" class="btn-download">⬇️ Скачать группу (JSON)</a>
                    </div>
                    <table class="data">
                        <thead>
                            <tr><th>Логин / Тест</th><th>Статус</th><th>Сообщение</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($group['results'] as $res): ?>
                            <tr>
                                <td><b><?= htmlspecialchars($res['login'], ENT_QUOTES, 'UTF-8') ?></b></td>
                                <td><span class="badge <?= $res['status'] === 'SUCCESS' ? 'badge-success' : 'badge-fail' ?>"><?= htmlspecialchars($res['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
                                <td><?= htmlspecialchars($res['message'], ENT_QUOTES, 'UTF-8') ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <script>
        function sendTest(formElement, btnElement, loadingElement, extraData = {}) {
            const msgDiv = document.getElementById('globalMessage');
            const formData = new FormData(formElement);
            for (const key in extraData) formData.append(key, extraData[key]);
            
            btnElement.disabled = true;
            const originalText = btnElement.textContent;
            btnElement.textContent = '⏳ Выполняется...';
            loadingElement.classList.add('active');
            msgDiv.style.display = 'none';
            
            fetch('admin_testing_run.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                loadingElement.classList.remove('active');
                btnElement.disabled = false;
                btnElement.textContent = originalText;
                msgDiv.style.display = 'block';
                msgDiv.className = 'msg ' + (data.success ? '' : 'error');
                msgDiv.innerHTML = '<b>Результат:</b> ' + data.message;
                if (data.success) setTimeout(() => window.location.reload(), 1500);
            })
            .catch(err => {
                loadingElement.classList.remove('active');
                btnElement.disabled = false;
                btnElement.textContent = originalText;
                msgDiv.style.display = 'block';
                msgDiv.className = 'msg error';
                msgDiv.textContent = 'Ошибка сети.';
            });
        }

        document.getElementById('authForm').addEventListener('submit', function(e) { e.preventDefault(); sendTest(this, document.getElementById('authBtn'), document.getElementById('authLoading'), { action: 'auth' }); });
        document.getElementById('diskForm').addEventListener('submit', function(e) { e.preventDefault(); sendTest(this, document.getElementById('diskBtn'), document.getElementById('diskLoading'), { action: 'disk' }); });
        document.getElementById('speedForm').addEventListener('submit', function(e) { e.preventDefault(); sendTest(this, document.getElementById('speedBtn'), document.getElementById('speedLoading'), { action: 'speed' }); });
    </script>
</body>
</html>