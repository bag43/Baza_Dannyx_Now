 <?php

declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();

$pkColumn = null;
foreach ($columns as $c) {
    if ($c['Key'] === 'PRI') {
        $pkColumn = $c['Field'];
        break;
    }
}

$rows = $pdo->query("SELECT * FROM `$tableName` LIMIT 500")->fetchAll();
$total = $pdo->query("SELECT COUNT(*) FROM `$tableName`")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Данные таблицы: <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/db-data.css">
</head>
<body>
    <div class="container">
        <a href="db_tools.php" class="back">← К списку таблиц</a>
        <h1>📊 Данные таблицы: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code></h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="top-bar">
            <div class="info" style="margin:0; flex:1;">
                Всего записей: <b><?= $total ?></b>. Показано первых <b><?= count($rows) ?></b>.
                <?php if (!$pkColumn): ?>
                    <br>⚠️ <b>Внимание:</b> у таблицы нет PRIMARY KEY, редактирование может быть неточным.
                <?php endif; ?>
            </div>
            <a href="db_row_edit.php?table=<?= urlencode($tableName) ?>" class="btn-add">➕ Добавить строку</a>
        </div>
        
        <div class="card">
            <?php if (empty($rows)): ?>
                <p style="text-align:center; color:#999;">Таблица пуста. Нажмите «Добавить строку», чтобы создать первую запись.</p>
            <?php else: ?>
                <table class="data">
                    <thead>
                        <tr>
                            <?php foreach ($columns as $c): ?>
                                <th><?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?></th>
                            <?php endforeach; ?>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($columns as $c): 
                                    $val = $row[$c['Field']] ?? null;
                                    $isPk = ($c['Field'] === $pkColumn);
                                ?>
                                    <td class="<?= $val === null ? 'null' : '' ?> <?= $isPk ? 'pk' : '' ?>">
                                        <?= $val === null ? 'NULL' : htmlspecialchars(mb_substr((string) $val, 0, 100), ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                <?php endforeach; ?>
                                <td>
                                    <?php if ($pkColumn): ?>
                                        <a href="db_row_edit.php?table=<?= urlencode($tableName) ?>&id=<?= urlencode((string) $row[$pkColumn]) ?>" 
                                           class="btn-edit-sm">✏️ Изменить</a>
                                        <a href="db_row_actions.php?action=delete&table=<?= urlencode($tableName) ?>&id=<?= urlencode((string) $row[$pkColumn]) ?>" 
                                           class="btn-del-sm"
                                           onclick="return confirm('Удалить эту строку?')">🗑 Удалить</a>
                                    <?php else: ?>
                                        <span style="color:#aaa; font-size:11px;">нет PK</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>