 <?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$tableName = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table'] ?? '');
if (!$tableName) {
    die('Не указана таблица');
}

$check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
$check->execute([$tableName]);
if (!$check->fetchColumn()) {
    die('Таблица не найдена');
}

$columns = $pdo->query("DESCRIBE `$tableName`")->fetchAll();

$pkColumn = null;
foreach ($columns as $c) {
    if ($c['Key'] === 'PRI') {
        $pkColumn = $c['Field'];
        break;
    }
}

$rowId = $_GET['id'] ?? null;
$isEdit = ($rowId !== null && $rowId !== '');
$row = [];

if ($isEdit) {
    if (!$pkColumn) {
        die('У таблицы нет PRIMARY KEY, редактирование невозможно');
    }
    $stmt = $pdo->prepare("SELECT * FROM `$tableName` WHERE `$pkColumn` = ? LIMIT 1");
    $stmt->execute([$rowId]);
    $row = $stmt->fetch();
    if (!$row) {
        die('Строка не найдена');
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

function fieldInput(array $col, mixed $value, bool $isPk, bool $isEdit): string
{
    $name = htmlspecialchars($col['Field'], ENT_QUOTES, 'UTF-8');
    $type = strtolower($col['Type']);
    $val = htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
    $required = ($col['Null'] === 'NO' && $col['Default'] === null && !$isPk) ? 'required' : '';
    $readonly = ($isPk && $isEdit) ? 'readonly' : '';
    $extra = ($isPk && $isEdit) ? 'background:#eee;' : '';
    
    if (preg_match("/^enum\((.*)\)$/i", $type, $m)) {
        $options = str_getcsv($m[1], ',', "'");
        $html = "<select name=\"$name\" style=\"width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;\" $required>";
        foreach ($options as $opt) {
            $opt = trim($opt);
            $sel = ($opt === (string) $value) ? 'selected' : '';
            $html .= "<option value=\"" . htmlspecialchars($opt, ENT_QUOTES, 'UTF-8') . "\" $sel>" . htmlspecialchars($opt, ENT_QUOTES, 'UTF-8') . "</option>";
        }
        $html .= "</select>";
        return $html;
    }
    
    if (str_contains($type, 'text')) {
        return "<textarea name=\"$name\" rows=\"4\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>$val</textarea>";
    }
    
    if (preg_match('/^(int|tinyint|smallint|mediumint|bigint|decimal|float|double)/', $type)) {
        $step = (str_contains($type, 'decimal') || str_contains($type, 'float') || str_contains($type, 'double')) ? '0.01' : '1';
        return "<input type=\"number\" step=\"$step\" name=\"$name\" value=\"$val\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px; $extra\" $required $readonly>";
    }
    
    if (str_contains($type, 'datetime') || str_contains($type, 'timestamp')) {
        $dt = $value ? date('Y-m-d\TH:i', strtotime((string) $value)) : '';
        return "<input type=\"datetime-local\" name=\"$name\" value=\"$dt\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>";
    }
    if (str_contains($type, 'date')) {
        $dt = $value ? date('Y-m-d', strtotime((string) $value)) : '';
        return "<input type=\"date\" name=\"$name\" value=\"$dt\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px;\" $required>";
    }
    
    return "<input type=\"text\" name=\"$name\" value=\"$val\" style=\"width:100%; padding:8px; box-sizing:border-box; border:1px solid #ccc; border-radius:4px; $extra\" $required $readonly>";
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Редактирование' : 'Добавление' ?> строки в <?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/db-row-edit.css">
</head>
<body>
    <div class="container">
        <a href="db_data.php?table=<?= urlencode($tableName) ?>" class="back">← К данным таблицы</a>
        <h1><?= $isEdit ? '✏️ Редактирование строки' : '➕ Новая строка' ?>: <code><?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?></code></h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        
        <div class="card">
            <form method="POST" action="db_row_actions.php">
                <input type="hidden" name="action" value="<?= $isEdit ? 'update' : 'insert' ?>">
                <input type="hidden" name="table" value="<?= htmlspecialchars($tableName, ENT_QUOTES, 'UTF-8') ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="pk_column" value="<?= htmlspecialchars((string) $pkColumn, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="pk_value" value="<?= htmlspecialchars((string) $rowId, ENT_QUOTES, 'UTF-8') ?>">
                <?php endif; ?>
                
                <?php foreach ($columns as $c): 
                    $isPk = ($c['Field'] === $pkColumn);
                    if (!$isEdit && str_contains($c['Extra'], 'auto_increment')) {
                        continue;
                    }
                ?>
                    <div class="form-group">
                        <label>
                            <?= htmlspecialchars($c['Field'], ENT_QUOTES, 'UTF-8') ?>
                            <span class="type-hint">(<?= htmlspecialchars($c['Type'], ENT_QUOTES, 'UTF-8') ?>)</span>
                            <?php if ($isPk): ?><span class="pk-badge">PK</span><?php endif; ?>
                            <?php if ($c['Null'] === 'YES'): ?><span class="null-badge">NULL</span><?php endif; ?>
                        </label>
                        <?= fieldInput($c, $row[$c['Field']] ?? null, $isPk, $isEdit) ?>
                    </div>
                <?php endforeach; ?>
                
                <button type="submit" class="submit-btn"><?= $isEdit ? '💾 Сохранить изменения' : '➕ Добавить строку' ?></button>
                <a href="db_data.php?table=<?= urlencode($tableName) ?>" class="cancel-btn">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>