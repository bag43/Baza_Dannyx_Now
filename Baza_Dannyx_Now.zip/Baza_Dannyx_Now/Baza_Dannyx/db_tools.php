<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || $_SESSION['user_role'] !== 'System_Admin') {
    die('Доступ запрещён. Только для системного администратора.');
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$protected = ['users', 'roles', 'user_profiles', 'notifications', 'audit_logs', 'ban_logs'];

$tables = $pdo->query("
    SELECT table_name 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE()
    ORDER BY table_name
")->fetchAll(PDO::FETCH_COLUMN);

$tablesInfo = [];
foreach ($tables as $t) {
    $colStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM information_schema.columns 
        WHERE table_schema = DATABASE() 
        AND table_name = ?
    ");
    $colStmt->execute([$t]);
    $colCount = (int) $colStmt->fetchColumn();
    
    $rowCount = (int) $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
    
    $tablesInfo[] = ['name' => $t, 'cols' => $colCount, 'rows' => $rowCount];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление таблицами БД</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/db-tools.css">
</head>
<body>
    <div class="container">
        <a href="admin.php" class="back">← Назад в панель администратора</a>
        <h1>🛠️ Управление таблицами БД</h1>
        
        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>">
                <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>
        
        <button class="btn-create" onclick="openCreateModal()">➕ Создать новую таблицу</button>
        
        <table class="tables">
            <thead>
                <tr>
                    <th>Имя таблицы</th>
                    <th>Столбцов</th>
                    <th>Строк</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tablesInfo as $t): 
                    $isProtected = in_array($t['name'], $protected, true);
                ?>
                <tr>
                    <td>
                        <b><?= htmlspecialchars($t['name'], ENT_QUOTES, 'UTF-8') ?></b>
                        <?= $isProtected ? ' 🔒' : '' ?>
                    </td>
                    <td><?= $t['cols'] ?></td>
                    <td><?= $t['rows'] ?></td>
                    <td>
                        <a href="db_data.php?table=<?= urlencode($t['name']) ?>" class="btn-view" style="background:#28a745;">📊 Данные</a>
                        <a href="db_edit.php?table=<?= urlencode($t['name']) ?>" class="btn-edit">✏️ Структура</a>
                        <?php if (!$isProtected): ?>
                            <a href="db_actions.php?action=drop&table=<?= urlencode($t['name']) ?>" 
                               class="btn-del" 
                               onclick="return confirm('Удалить таблицу «<?= htmlspecialchars($t['name'], ENT_QUOTES, 'UTF-8') ?>»? Это действие необратимо!')">🗑 Удалить</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <div id="createModal" class="modal-overlay">
        <div class="modal-content">
            <span class="close-btn" onclick="closeCreateModal()">&times;</span>
            <h2 style="margin-top:0;">➕ Создать новую таблицу</h2>
            
            <form method="POST" action="db_actions.php">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label>Имя таблицы:</label>
                    <input type="text" name="table_name" required pattern="[a-zA-Z0-9_]+" placeholder="например: products (только латиница, цифры, _)">
                </div>
                
                <div class="form-group">
                    <label>Столбцы таблицы:</label>
                    <div class="hint">
                        💡 <b>Длина/значения:</b> для VARCHAR — число (например <code>100</code>); 
                        для DECIMAL — <code>10,2</code>; для ENUM — <code>'да','нет','может быть'</code>.
                    </div>
                    <div id="columnsContainer"></div>
                    <button type="button" class="btn-add-col" onclick="addColumn()">➕ Добавить столбец</button>
                </div>
                
                <button type="submit" class="submit-btn">Создать таблицу</button>
            </form>
        </div>
    </div>
    
    <script>
        let colUid = 0;
        
        function openCreateModal() {
            document.getElementById('createModal').classList.add('active');
            document.getElementById('columnsContainer').innerHTML = '';
            colUid = 0;
            addColumn();
        }
        
        function closeCreateModal() {
            document.getElementById('createModal').classList.remove('active');
        }
        
        function addColumn() {
            const uid = colUid++;
            const container = document.getElementById('columnsContainer');
            const html = `
                <div class="column-row">
                    <input type="hidden" name="col_uid[]" value="${uid}">
                    <input type="text" name="col_name[${uid}]" placeholder="Имя столбца" required>
                    <select name="col_type[${uid}]">
                        <option value="INT">INT</option>
                        <option value="VARCHAR" selected>VARCHAR</option>
                        <option value="TEXT">TEXT</option>
                        <option value="DATETIME">DATETIME</option>
                        <option value="DATE">DATE</option>
                        <option value="DECIMAL">DECIMAL</option>
                        <option value="TINYINT">TINYINT</option>
                        <option value="ENUM">ENUM</option>
                    </select>
                    <input type="text" name="col_length[${uid}]" placeholder="Длина">
                    <label title="Может быть NULL">
                        <input type="checkbox" name="col_nullable[${uid}]" value="1"> NULL
                    </label>
                    <input type="text" name="col_default[${uid}]" placeholder="По умолч.">
                    <label title="Auto Increment">
                        <input type="checkbox" name="col_ai[${uid}]" value="1"> AI
                    </label>
                    <label title="Primary Key">
                        <input type="radio" name="col_pk" value="${uid}"> PK
                    </label>
                    <button type="button" class="btn-remove" onclick="this.parentNode.remove()">✖</button>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
        }
        
        document.getElementById('createModal').addEventListener('click', function(e) {
            if (e.target === this) closeCreateModal();
        });
    </script>
</body>
</html>