<?php
declare(strict_types=1);

require 'db.php';

if (isset($_SESSION['user_login'])) {
    header('Location: dashboard.php');
    exit;
}

$kicked = isset($_GET['kicked']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <head>
    <meta charset="UTF-8">
    <title>Главная страница</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <?php if ($kicked): ?>
        <div class="kicked-notice">
            ⚠️ Администратор завершил вашу сессию. Войдите заново.
        </div>
    <?php endif; ?>

    <button class="main-btn" onclick="openModal()">Войти в систему</button>

    <div class="modal-overlay" id="loginModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <h2 style="text-align:center; margin-top:0;">Вход</h2>
            <div id="loginMessage" class="message"></div>

            <form id="loginForm">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" name="login" required>
                </div>
                <div class="form-group">
                    <label>Пароль:</label>
                    <input type="password" name="password" required>
                </div>
                <?php include 'captcha.php'; ?>
                <button type="submit" class="submit-btn">Войти</button>
            </form>
            <div class="register-link">
                Нет аккаунта? <a href="register.php">Зарегистрироваться</a>
            </div>
        </div>
    </div>

    <script>
        function openModal() { document.getElementById('loginModal').classList.add('active'); }
        function closeModal() { document.getElementById('loginModal').classList.remove('active'); }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const msgDiv = document.getElementById('loginMessage');
            
            fetch('process.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    msgDiv.className = 'message ' + (data.success ? 'success' : 'error');
                    msgDiv.textContent = data.message;
                    if (data.success) {
                        setTimeout(() => { window.location.href = 'dashboard.php'; }, 1500);
                    }
                })
                .catch(() => {
                    msgDiv.className = 'message error';
                    msgDiv.textContent = 'Ошибка соединения с сервером.';
                });
        });
    </script>
</body>
</html>