<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

if (isset($_GET['read'])) {
    $nid = (int) $_GET['read'];
    $pdo->prepare("UPDATE notifications SET Is_Read = 1 WHERE Notification_ID = ? AND User_ID = ?")
        ->execute([$nid, $userId]);
    header('Location: messages.php');
    exit;
}

if (isset($_GET['delete'])) {
    $nid = (int) $_GET['delete'];
    $pdo->prepare("UPDATE notifications SET Deleted_By_User = 1 WHERE Notification_ID = ? AND User_ID = ?")
        ->execute([$nid, $userId]);
    header('Location: messages.php');
    exit;
}

if (isset($_GET['read_all'])) {
    $pdo->prepare("UPDATE notifications SET Is_Read = 1 WHERE User_ID = ? AND Deleted_By_User = 0")
        ->execute([$userId]);
    header('Location: messages.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT 
        n.Notification_ID, n.Subject, n.Message, n.Is_Read, n.Is_System, n.Created_at,
        s.Login AS Sender_Login, s.Role AS Sender_Role
    FROM notifications n
    LEFT JOIN users s ON s.ID_U = n.Sender_ID
    WHERE n.User_ID = ? AND n.Deleted_By_User = 0
    ORDER BY n.Created_at DESC
");
$stmt->execute([$userId]);
$messages = $stmt->fetchAll();

$unread = count(array_filter($messages, fn(array $m): bool => $m['Is_Read'] === '0'));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои сообщения</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/messages.css">
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back">← В личный кабинет</a>
        
        <div class="top-bar">
            <h1>✉️ Мои сообщения <?= $unread > 0 ? "<span style='color:#dc3545;'>($unread новых)</span>" : '' ?></h1>
            <?php if ($unread > 0): ?>
                <a href="?read_all=1" class="btn-read-all">✅ Прочитать все</a>
            <?php endif; ?>
        </div>
        
        <?php if (empty($messages)): ?>
            <div class="empty">
                <p style="font-size:40px; margin:10px;">📭</p>
                <p>У вас нет сообщений.</p>
            </div>
        <?php else: ?>
            <?php foreach ($messages as $m): ?>
                <div class="msg-card <?= $m['Is_Read'] === '0' ? 'unread' : '' ?> <?= $m['Is_System'] === '1' ? 'system' : '' ?>">
                    <div class="msg-header">
                        <div>
                            <h3 class="msg-subject">
                                <?php if ($m['Is_Read'] === '0'): ?>
                                    <span class="badge badge-unread">НОВОЕ</span>
                                <?php endif; ?>
                                <?= htmlspecialchars($m['Subject'] ?? 'Без темы', ENT_QUOTES, 'UTF-8') ?>
                            </h3>
                            <div class="msg-meta">
                                <?php if ($m['Is_System'] === '1'): ?>
                                    <span class="badge badge-sys">СИСТЕМА</span>
                                <?php else: ?>
                                    От: <b><?= htmlspecialchars($m['Sender_Login'] ?? 'Администратор', ENT_QUOTES, 'UTF-8') ?></b>
                                    <?php if (($m['Sender_Role'] ?? '') === 'System_Admin'): ?>
                                        <span class="badge badge-sys">Sys_Admin</span>
                                    <?php elseif (($m['Sender_Role'] ?? '') === 'Admin'): ?>
                                        <span class="badge badge-adm">Admin</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                                · <?= htmlspecialchars($m['Created_at'], ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="msg-body"><?= htmlspecialchars($m['Message'], ENT_QUOTES, 'UTF-8') ?></div>
                    
                    <div class="msg-actions">
                        <?php if ($m['Is_Read'] === '0'): ?>
                            <a href="?read=<?= $m['Notification_ID'] ?>" class="btn-sm btn-read">✅ Пометить прочитанным</a>
                        <?php endif; ?>
                        <a href="?delete=<?= $m['Notification_ID'] ?>" class="btn-sm btn-del"
                           onclick="return confirm('Удалить это сообщение?')">🗑 Удалить</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>