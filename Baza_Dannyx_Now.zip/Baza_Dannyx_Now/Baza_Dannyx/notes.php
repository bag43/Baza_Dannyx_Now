<?php
require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$role   = $_SESSION['user_role'] ?? 'User';
$flash  = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ============ ЗАПРОС: все заметки (сис-админ) или свои (обычный) ============
if ($role === 'System_Admin') {
    $stmt = $pdo->query("
        SELECT n.*, u.Login AS Author, u.Role AS Author_Role
        FROM notes n
        JOIN users u ON u.ID_U = n.Id_user
        ORDER BY n.Id ASC
    ");
} else {
    $stmt = $pdo->prepare("
        SELECT n.*, u.Login AS Author, u.Role AS Author_Role
        FROM notes n
        JOIN users u ON u.ID_U = n.Id_user
        WHERE n.Id_user = ?
        ORDER BY n.Id ASC
    ");
    $stmt->execute([$userId]);
}
$notes = $stmt->fetchAll();

// ============ СТАТИСТИКА ============
$totalNotes = count($notes);
$totalChars = array_sum(array_map(fn($n) => mb_strlen($n['Content']), $notes));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заметки</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/notes.css">
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back">← В личный кабинет</a>

        <div class="top-bar">
            <h1>📝 <?= $role === 'System_Admin' ? 'Все заметки пользователей' : 'Мои заметки' ?></h1>
            <div class="top-actions">
                <a href="api_notes.php?download=1&filename=notes" class="btn btn-download">⬇️ Скачать notes.json</a>
                <a href="notes_edit.php" class="btn btn-add">➕ Новая заметка</a>
            </div>
        </div>

        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg']) ?></div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat-card">
                <div class="label">📋 Всего заметок</div>
                <div class="value"><?= $totalNotes ?></div>
            </div>
            <div class="stat-card" style="border-left-color: #28a745;">
                <div class="label">📝 Символов в тексте</div>
                <div class="value"><?= number_format($totalChars, 0, '.', ' ') ?></div>
            </div>
        </div>

        <?php if (empty($notes)): ?>
            <div class="empty">
                <div class="icon">📭</div>
                <h2>Заметок пока нет</h2>
                <p>Нажмите «➕ Новая заметка», чтобы создать первую.</p>
            </div>
        <?php else: ?>
            <?php foreach ($notes as $n):
                $isMine = ($n['Id_user'] == $userId);
                $canEdit = $isMine || $role === 'System_Admin';
            ?>
                <div class="note-card <?= !$isMine ? 'foreign' : '' ?>">
                    <div class="note-header">
                        <div>
                            <h3 class="note-title"><?= htmlspecialchars($n['Title']) ?></h3>
                            <div class="note-meta">
                                ID: <b><?= str_pad((string)$n['Id'], 5, '0', STR_PAD_LEFT) ?></b>
                                · Автор: <b><?= htmlspecialchars($n['Author']) ?></b>
                                <?php if ($isMine): ?>
                                    <span class="badge badge-own">Моя</span>
                                <?php else: ?>
                                    <?php
                                        $cls = $n['Author_Role'] === 'System_Admin' ? 'badge-sys' :
                                              ($n['Author_Role'] === 'Admin' ? 'badge-adm' : 'badge-usr');
                                    ?>
                                    <span class="badge <?= $cls ?>"><?= $n['Author_Role'] ?></span>
                                <?php endif; ?>
                                · <?= date('d.m.Y', strtotime($n['created_at'])) ?>
                            </div>
                        </div>
                    </div>

                    <div class="note-content"><?= htmlspecialchars($n['Content']) ?></div>

                    <?php if ($canEdit): ?>
                    <div class="note-actions">
                        <a href="notes_edit.php?id=<?= $n['Id'] ?>" class="btn-sm btn-edit">✏️ Редактировать</a>
                        <a href="notes_actions.php?action=delete&id=<?= $n['Id'] ?>"
                           class="btn-sm btn-del"
                           onclick="return confirm('Удалить заметку «<?= htmlspecialchars($n['Title']) ?>»?')">
                           🗑 Удалить
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>