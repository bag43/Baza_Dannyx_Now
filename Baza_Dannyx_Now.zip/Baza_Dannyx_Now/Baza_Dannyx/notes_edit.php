<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$role   = $_SESSION['user_role'] ?? 'User';
$isEdit = isset($_GET['id']) && $_GET['id'] !== '';

$note = ['Title' => '', 'Content' => ''];

if ($isEdit) {
    $noteId = (int) $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM notes WHERE Id = ?");
    $stmt->execute([$noteId]);
    $note = $stmt->fetch();

    if (!$note) {
        $_SESSION['flash'] = ['msg' => 'Заметка не найдена', 'error' => true];
        header('Location: notes.php');
        exit;
    }

    if ($note['Id_user'] != $userId && $role !== 'System_Admin') {
        die('Доступ запрещён. Вы можете редактировать только свои заметки.');
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Редактирование' : 'Новая' ?> заметка</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/notes-edit.css">
</head>
<body>
    <div class="container">
        <a href="notes.php" class="back">← К заметкам</a>
        <h1><?= $isEdit ? '✏️ Редактирование заметки' : '➕ Новая заметка' ?></h1>

        <?php if ($isEdit && $note['Id_user'] != $userId && $role === 'System_Admin'): 
            $authorStmt = $pdo->prepare("SELECT Login FROM users WHERE ID_U = ?");
            $authorStmt->execute([$note['Id_user']]);
            $author = $authorStmt->fetchColumn();
        ?>
            <div class="author-notice">
                ⚠️ Вы редактируете заметку пользователя <b><?= htmlspecialchars((string)$author, ENT_QUOTES, 'UTF-8') ?></b> как системный администратор.
            </div>
        <?php endif; ?>

        <?php if ($flash): ?>
            <div class="msg <?= !empty($flash['error']) ? 'error' : '' ?>"><?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="notes_actions.php">
                <input type="hidden" name="action" value="<?= $isEdit ? 'update' : 'insert' ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="id" value="<?= $note['Id'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label>Заголовок:</label>
                    <input type="text" name="title" required maxlength="255"
                           value="<?= htmlspecialchars($note['Title'], ENT_QUOTES, 'UTF-8') ?>"
                           placeholder="Например: Список задач на день">
                    <div class="hint">Максимум 255 символов.</div>
                </div>

                <div class="form-group">
                    <label>Содержание:</label>
                    <textarea name="content" required maxlength="10000"
                              placeholder="Введите текст заметки..."><?= htmlspecialchars($note['Content'], ENT_QUOTES, 'UTF-8') ?></textarea>
                    <div class="hint">Максимум 10 000 символов.</div>
                </div>

                <button type="submit" class="btn-save">💾 <?= $isEdit ? 'Сохранить изменения' : 'Создать заметку' ?></button>
                <a href="notes.php" class="btn-cancel">Отмена</a>
            </form>
        </div>
    </div>
</body>
</html>