<?php
declare(strict_types=1);

require 'db.php';

if (!isset($_SESSION['user_login']) || !in_array($_SESSION['user_role'], ['Admin', 'System_Admin'], true)) {
    header('Location: dashboard.php');
    exit;
}

$sql = "SELECT 
            u.ID_U, u.Login, u.Phone_Number, u.Ban, u.Role, 
            u.Failed_Attempts, u.Last_Password_Change,
            p.Last_Name, p.First_Name, p.Middle_Name
        FROM users u
        LEFT JOIN user_profiles p ON u.ID_U = p.User_ID
        ORDER BY u.ID_U";
$stmt = $pdo->query($sql);
$users = $stmt->fetchAll();

$isSystemAdmin = ($_SESSION['user_role'] === 'System_Admin');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
     <meta charset="UTF-8">
    <title>Панель администратора</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="header">
        <h1>⚙️ Панель администратора</h1>
        <div>
            <span class="role-badge role-<?= htmlspecialchars($_SESSION['user_role'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($_SESSION['user_role'], ENT_QUOTES, 'UTF-8') ?></span>
            <a href="dashboard.php" class="btn btn-tools" style="margin-left:10px;">← В кабинет</a>
            <a href="logout.php" class="btn btn-ban">Выйти</a>
        </div>
    </div>

    <?php if ($isSystemAdmin): ?>
    <div class="top-buttons">
        <a href="db_tools.php" class="btn btn-tools">🛠️ Управление таблицами БД</a>
    </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Логин</th>
                <th>ФИО</th>
                <th>Телефон</th>
                <th>Роль</th>
                <th>Статус</th>
                <th>Ошибки</th>
                <th>Смена пароля</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['ID_U'] ?></td>
                <td><?= htmlspecialchars($u['Login'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <?php 
                        $fio = trim(($u['Last_Name'] ?? '') . ' ' . ($u['First_Name'] ?? '') . ' ' . ($u['Middle_Name'] ?? ''));
                        echo $fio ? htmlspecialchars($fio, ENT_QUOTES, 'UTF-8') : '<i style="color:#aaa;">не заполнено</i>';
                    ?>
                </td>
                <td><?= htmlspecialchars($u['Phone_Number'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <form method="POST" action="admin_actions.php" style="display:inline;">
                        <input type="hidden" name="action" value="change_role">
                        <input type="hidden" name="user_id" value="<?= $u['ID_U'] ?>">
                        <select name="role" class="role-select" onchange="this.form.submit()">
                            <option value="User" <?= $u['Role'] === 'User' ? 'selected' : '' ?>>User</option>
                            <option value="Admin" <?= $u['Role'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
                            <?php if ($isSystemAdmin): ?>
                                <option value="System_Admin" <?= $u['Role'] === 'System_Admin' ? 'selected' : '' ?>>System_Admin</option>
                            <?php endif; ?>
                        </select>
                    </form>
                </td>
                <td>
                    <?= $u['Ban'] === '1' 
                        ? '<span class="status-banned">🚫 Забанен</span>' 
                        : '<span class="status-active">✅ Активен</span>' ?>
                </td>
                <td><?= $u['Failed_Attempts'] ?></td>
                <td><?= htmlspecialchars($u['Last_Password_Change'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <?php if ($u['Ban'] === '0'): ?>
                        <a href="admin_actions.php?action=ban&user_id=<?= $u['ID_U'] ?>" class="btn btn-ban" onclick="return confirm('Забанить?')">Забанить</a>
                    <?php else: ?>
                        <a href="admin_actions.php?action=unban&user_id=<?= $u['ID_U'] ?>" class="btn btn-unban">Разбанить</a>
                    <?php endif; ?>
                    
                    <?php if ($isSystemAdmin): ?>
                        <a href="admin_actions.php?action=delete&user_id=<?= $u['ID_U'] ?>" class="btn btn-ban" onclick="return confirm('Удалить пользователя?')">Удалить</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>