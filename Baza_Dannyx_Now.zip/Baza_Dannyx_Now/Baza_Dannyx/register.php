<?php
declare(strict_types=1);

require 'db.php';

if (isset($_SESSION['user_login'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/register.css">
</head>
<body>

    <div class="form-container">
        <h2>Регистрация</h2>
        <div id="registerMessage" class="message"></div>

        <form id="registerForm">
            <input type="hidden" name="action" value="register">
            
            <div class="row">
                <div class="form-group">
                    <label>Фамилия:</label>
                    <input type="text" name="last_name" required>
                </div>
                <div class="form-group">
                    <label>Имя:</label>
                    <input type="text" name="first_name" required>
                </div>
            </div>

            <div class="form-group">
                <label>Email (Почта):</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Логин:</label>
                <input type="text" name="login" required>
            </div>
            
            <div class="form-group">
                <label>Пароль:</label>
                <input type="password" name="password" id="pass1" required>
            </div>

            <!-- НОВОЕ ПОЛЕ: Повтор пароля -->
            <div class="form-group">
                <label>Повторите пароль:</label>
                <input type="password" name="confirm_password" id="pass2" required>
            </div>

            <div class="form-group">
                <label>Номер телефона:</label>
                <input type="text" name="phone" required>
            </div>
            <?php include 'captcha.php'; ?>
            <button type="submit" class="submit-btn">Зарегистрироваться</button>
        </form>
        <a href="index.php" class="back-link">Вернуться на главную</a>
    </div>

    <script>
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const pass1 = document.getElementById('pass1').value;
            const pass2 = document.getElementById('pass2').value;
            const msgDiv = document.getElementById('registerMessage');
            
            // Быстрая проверка совпадения паролей на клиенте
            if (pass1 !== pass2) {
                msgDiv.className = 'message error';
                msgDiv.textContent = 'Ошибка: Пароли не совпадают!';
                return; // Останавливаем отправку
            }

            const formData = new FormData(this);
            const btn = this.querySelector('.submit-btn');
            
            btn.disabled = true;
            btn.textContent = 'Регистрация...';
            msgDiv.className = 'message';
            msgDiv.textContent = '';
            
            fetch('process.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    btn.disabled = false;
                    btn.textContent = 'Зарегистрироваться';
                    msgDiv.className = 'message ' + (data.success ? 'success' : 'error');
                    msgDiv.textContent = data.message;
                    if (data.success) {
                        setTimeout(() => { window.location.href = 'index.php'; }, 2000);
                    }
                })
                .catch(() => {
                    btn.disabled = false;
                    btn.textContent = 'Зарегистрироваться';
                    msgDiv.className = 'message error';
                    msgDiv.textContent = 'Ошибка соединения с сервером.';
                });
        });
    </script>
</body>
</html>